package com.dhaka.battlezone;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

/** Procedurally generated sound effects (no audio files needed). */
public class Sfx {
    public static final int SHOT = 0, SHOT_HEAVY = 1, HIT = 2, PICK = 3, RELOAD = 4, EXPLODE = 5, HURT = 6, DING = 7;
    static SoundPool pool;
    static int[] ids = new int[8];
    static boolean ok = false;

    public static void init(Context c) {
        try {
            pool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
            ids[SHOT] = load(c, "shot", noise(0.16f, 38f, 0.55f));
            ids[SHOT_HEAVY] = load(c, "shot2", noise(0.40f, 14f, 0.8f));
            ids[HIT] = load(c, "hit", tone(1500f, 0.06f, 30f));
            ids[PICK] = load(c, "pick", tone(900f, 0.09f, 18f));
            ids[RELOAD] = load(c, "reload", noise(0.05f, 60f, 0.2f));
            ids[EXPLODE] = load(c, "boom", noise(0.9f, 5f, 0.93f));
            ids[HURT] = load(c, "hurt", tone(110f, 0.2f, 9f));
            ids[DING] = load(c, "ding", tone(1900f, 0.12f, 14f));
            ok = true;
        } catch (Throwable t) {
            ok = false;
        }
    }

    public static void play(int id, float vol) {
        if (!ok || !Cfg.sound) return;
        try {
            float v = Math.max(0f, Math.min(1f, vol)) * Cfg.volume;
            if (v > 0.01f) pool.play(ids[id], v, v, 1, 0, 1f);
        } catch (Throwable t) { }
    }

    static int load(Context c, String name, short[] pcm) throws Exception {
        File f = new File(c.getCacheDir(), name + ".wav");
        FileOutputStream o = new FileOutputStream(f);
        int rate = 22050, dataLen = pcm.length * 2;
        byte[] h = new byte[44];
        put(h, 0, "RIFF"); le32(h, 4, 36 + dataLen); put(h, 8, "WAVE"); put(h, 12, "fmt ");
        le32(h, 16, 16); h[20] = 1; h[22] = 1; le32(h, 24, rate); le32(h, 28, rate * 2);
        h[32] = 2; h[34] = 16; put(h, 36, "data"); le32(h, 40, dataLen);
        o.write(h);
        byte[] b = new byte[dataLen];
        for (int i = 0; i < pcm.length; i++) { b[2 * i] = (byte) (pcm[i] & 255); b[2 * i + 1] = (byte) ((pcm[i] >> 8) & 255); }
        o.write(b);
        o.close();
        return pool.load(f.getAbsolutePath(), 1);
    }

    static void put(byte[] h, int o, String s) { for (int i = 0; i < s.length(); i++) h[o + i] = (byte) s.charAt(i); }
    static void le32(byte[] h, int o, int v) { h[o] = (byte) v; h[o + 1] = (byte) (v >> 8); h[o + 2] = (byte) (v >> 16); h[o + 3] = (byte) (v >> 24); }

    static short[] noise(float secs, float decay, float smooth) {
        int n = (int) (22050 * secs);
        short[] s = new short[n];
        Random r = new Random(5);
        float y = 0;
        for (int i = 0; i < n; i++) {
            float t = i / 22050f;
            float w = r.nextFloat() * 2 - 1;
            y = y * smooth + w * (1 - smooth);
            s[i] = (short) (y * Math.exp(-t * decay) * 30000 * (smooth > 0.5f ? 2.2f : 1f));
        }
        return s;
    }

    static short[] tone(float hz, float secs, float decay) {
        int n = (int) (22050 * secs);
        short[] s = new short[n];
        for (int i = 0; i < n; i++) {
            float t = i / 22050f;
            s[i] = (short) (Math.sin(2 * Math.PI * hz * t) * Math.exp(-t * decay) * 22000);
        }
        return s;
    }
}
