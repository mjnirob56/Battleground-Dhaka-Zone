package com.dhaka.battlezone;

/** Weapons and item definitions. */
public class W {
    public static class Gun {
        public String name;
        public int cls;        // 0 pistol 1 smg 2 rifle 3 marksman/sniper 4 shotgun 5 lmg 6 melee
        public int ammo;       // 0 light 1 rifle 2 heavy 3 shell
        public float dmg, rpm, reload, speed, spread, recoil, zoom, len;
        public int mag, pellets, mode; // mode 0 semi 1 auto 2 burst
        public float cr, cg, cb;
        public boolean primary() { return cls != 0 && cls != 6; }
    }

    static Gun mk(String n, int cls, int ammo, float dmg, float rpm, int mag, float reload, float speed,
                  float spread, float recoil, int pellets, int mode, float zoom, float len, int col) {
        Gun g = new Gun();
        g.name = n; g.cls = cls; g.ammo = ammo; g.dmg = dmg; g.rpm = rpm; g.mag = mag; g.reload = reload;
        g.speed = speed; g.spread = spread; g.recoil = recoil; g.pellets = pellets; g.mode = mode;
        g.zoom = zoom; g.len = len;
        g.cr = Cfg.pr(col); g.cg = Cfg.pg(col); g.cb = Cfg.pb(col);
        return g;
    }

    // order matters: indices are used as item ids
    public static final Gun[] G = {
        mk("P9 Pistol",        0, 0, 24, 420, 12, 1.5f, 380, 1.2f, 1.2f, 1, 0, 1.2f, 0.28f, 0x303030),
        mk("R45 Magnum",       0, 2, 62, 150,  6, 2.4f, 450, 0.8f, 3.2f, 1, 0, 1.2f, 0.34f, 0x6D6D6D),
        mk("Micro SMG",        1, 0, 18, 900, 20, 1.9f, 360, 2.2f, 1.0f, 1, 1, 1.2f, 0.42f, 0x282828),
        mk("Vector SMG",       1, 0, 20,1000, 19, 2.0f, 380, 1.9f, 1.0f, 1, 1, 1.2f, 0.50f, 0x3A3A3A),
        mk("UMP-9",            1, 0, 28, 650, 25, 2.3f, 400, 1.6f, 1.3f, 1, 1, 1.2f, 0.58f, 0x4A4A44),
        mk("AR-47",            2, 1, 38, 600, 30, 2.6f, 700, 1.0f, 2.4f, 1, 1, 1.25f, 0.92f, 0x5B3A1E),
        mk("AR-4",             2, 1, 31, 700, 30, 2.2f, 780, 0.8f, 1.6f, 1, 1, 1.25f, 0.90f, 0x2C2C30),
        mk("AR-16 Burst",      2, 1, 34, 700, 30, 2.5f, 800, 0.8f, 1.5f, 1, 2, 1.25f, 0.90f, 0x3C4A3C),
        mk("DM-14 Marksman",   3, 1, 46, 300, 15, 2.8f, 850, 0.4f, 2.2f, 1, 0, 2.0f, 1.00f, 0x4A3A2A),
        mk("BS-98 Bolt",       3, 2,100,  50,  5, 3.4f, 950, 0.1f, 6.0f, 1, 0, 4.0f, 1.20f, 0x2A3A2A),
        mk("HS-50 Heavy",      3, 2,135,  45,  5, 4.0f, 980, 0.1f, 7.0f, 1, 0, 6.0f, 1.30f, 0x2A2A2A),
        mk("PS-12 Pump",       4, 3, 14,  70,  5, 3.0f, 300, 4.5f, 5.0f, 9, 0, 1.1f, 0.95f, 0x5A4A3A),
        mk("AS-12 Auto",       4, 3, 10, 240,  8, 3.2f, 300, 4.0f, 3.0f, 8, 1, 1.1f, 0.95f, 0x333333),
        mk("L-28 LMG",         5, 1, 36, 750, 75, 5.5f, 740, 1.4f, 2.2f, 1, 1, 1.2f, 1.00f, 0x3A3A2A),
    };
    public static final int N = G.length;

    public static final Gun TAWA = mk("Tawa (Frying Pan)", 6, 0, 45, 90, 0, 0, 0, 0, 0, 1, 0, 1f, 0.5f, 0x222222);

    public static final String[] AMMO = {"9mm", "Rifle", "Heavy", "Shells"};
    public static final String[] HEAL = {"Bandage", "First Aid", "Medkit", "Energy Drink", "Painkiller"};
    public static final float[] HEAL_TIME = {3f, 6f, 8f, 4f, 6f};
    public static final float[] SCOPE_ZOOM = {1f, 2f, 3f, 4f, 6f};
    public static final float[] ARMOR_ABS = {0f, 0.30f, 0.40f, 0.55f};
    public static final float[] ARMOR_HP = {0f, 80f, 150f, 230f};

    // pickup kinds
    public static final int K_GUN = 0, K_AMMO = 1, K_HEAL = 2, K_ARMOR = 3, K_HELMET = 4, K_GREN = 5, K_SCOPE = 6;

    public static String itemName(int kind, int id, int count) {
        switch (kind) {
            case K_GUN: return G[id].name;
            case K_AMMO: return AMMO[id] + " ammo x" + count;
            case K_HEAL: return HEAL[id] + (count > 1 ? " x" + count : "");
            case K_ARMOR: return "Vest Lv." + id;
            case K_HELMET: return "Helmet Lv." + id;
            case K_GREN: return "Frag Grenade x" + count;
            case K_SCOPE: return "Scope " + (int) SCOPE_ZOOM[id] + "x";
        }
        return "?";
    }
}
