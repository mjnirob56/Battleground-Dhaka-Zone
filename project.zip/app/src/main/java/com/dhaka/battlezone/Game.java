package com.dhaka.battlezone;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

/** Game rules, simulation, bots. Everything here runs on the GL thread. */
public class Game {
    public static final int MENU = 0, PLAY = 1, RESULT = 2;
    public static volatile int state = MENU;
    public static volatile boolean loading = false, paused = false;
    public static volatile int pendingMode = -1, pendingMap = 0;
    public static Runnable onFinish;

    public static int mode, mapId;
    public static World world, menuWorld;
    public static final ArrayList<Fighter> fs = new ArrayList<>();
    public static final ArrayList<Bullet> bullets = new ArrayList<>();
    public static final ArrayList<Pickup> pickups = new ArrayList<>();
    public static final ArrayList<Gren> grens = new ArrayList<>();
    public static final ArrayList<Part> parts = new ArrayList<>();
    public static Fighter me, preview;
    public static Bitmap minimap, faceBmp;
    public static final CopyOnWriteArrayList<Object[]> feed = new CopyOnWriteArrayList<>();
    public static final CopyOnWriteArrayList<float[]> dmgDirs = new CopyOnWriteArrayList<>();
    public static final ArrayList<Tag> tags = new ArrayList<>();
    public static volatile String toast = "";
    public static volatile float toastT = 0;
    public static volatile String nearPick = "";
    public static volatile float hitMarkerT = 0;
    public static volatile boolean hitHead = false;
    public static volatile float matchTime;
    public static float aspect = 1.8f;

    // camera
    public static float camX, camY, camZ, camYaw, camPitch, fov = 72f;

    // match
    static float time, planeX, planeZ, planeY = 140f;
    public static boolean planeOn;
    public static float zx, zz, zr, zTx, zTz, zTr, zSx, zSz, zSr, zTimer;
    public static int zPhase;
    public static boolean zShrink;
    public static int scoreA, scoreB;
    public static float tdmTime;
    public static int myKills, resRank, resTaka, resKills, resTime, resDamage, resMode;
    public static boolean resWin;
    static final float[] ZW = {90, 40, 35, 30, 25, 20}, ZS = {45, 35, 30, 25, 20, 15};
    static final float[] ZR = {300, 200, 120, 70, 35, 6}, ZD = {1.5f, 2.5f, 4, 6, 9, 12};
    static final float PI = 3.14159265f;
    static final Random rnd = new Random();
    static final String[] NAMES = {"Rahim", "Karim", "Jamal", "Nasir", "Sohel", "Rubel", "Tanvir", "Mizan", "Arif", "Faruk", "Shanto",
        "Imran", "Hasan", "Babu", "Kamrul", "Monir", "Sagor", "Rony", "Joy", "Emon", "Masud", "Salman", "Alamin", "Zahid",
        "Tuhin", "Nayeem", "Shuvo", "Riyad", "Kabir", "Dipu", "Liton", "Sumon"};

    static float sin(float a) { return (float) Math.sin(a); }
    static float cos(float a) { return (float) Math.cos(a); }
    static float sqrt(float a) { return (float) Math.sqrt(a); }

    // ============================================================ setup
    public static void ensureMenu() {
        if (menuWorld == null) menuWorld = MapBuilder.tdm(1);
        if (preview == null) {
            preview = new Fighter();
            preview.st = 3;
            preview.slot[0] = W.G[6];
            preview.cur = 0;
            preview.x = 80; preview.z = 50; preview.byaw = 0.6f;
        }
        if (state == MENU) world = menuWorld;
    }

    static void costume(Fighter f, boolean mine) {
        if (mine) {
            f.top = Cfg.top; f.topCol = Cfg.topColor; f.bottom = Cfg.bottom; f.bottomCol = Cfg.bottomColor;
            f.head = Cfg.head; f.headCol = Cfg.headColor; f.shoeCol = Cfg.shoeColor;
        } else {
            f.top = rnd.nextInt(5); f.topCol = rnd.nextInt(10); f.bottom = rnd.nextInt(4); f.bottomCol = rnd.nextInt(10);
            f.head = rnd.nextInt(5); f.headCol = rnd.nextInt(10); f.shoeCol = rnd.nextInt(10);
        }
    }

    public static void startMatch(int m, int map) {
        mode = m; mapId = map;
        world = m == 0 ? MapBuilder.dhaka() : MapBuilder.tdm(map);
        minimap = world.renderMinimap(512);
        fs.clear(); bullets.clear(); pickups.clear(); grens.clear(); parts.clear(); feed.clear(); dmgDirs.clear();
        time = 0; matchTime = 0; myKills = 0; scoreA = scoreB = 0; tdmTime = 360f;
        paused = false; toast = ""; toastT = 0;
        Input.clear();
        me = new Fighter();
        me.isMe = true; me.name = Cfg.playerName; me.team = 0;
        costume(me, true);
        fs.add(me);
        if (m == 0) {
            for (int i = 1; i < 30; i++) {
                Fighter b = new Fighter();
                b.name = NAMES[(i - 1) % NAMES.length]; b.team = i;
                costume(b, false);
                fs.add(b);
            }
            planeZ = 140 + rnd.nextFloat() * 360;
            planeX = -40; planeOn = true;
            for (Fighter f : fs) {
                f.st = 0; f.x = planeX; f.z = planeZ; f.y = planeY;
                if (!f.isMe) {
                    float[] lp = world.loot.get(rnd.nextInt(world.loot.size()));
                    f.lx = lp[0] + (rnd.nextFloat() - 0.5f) * 10; f.lz = lp[1] + (rnd.nextFloat() - 0.5f) * 10;
                    f.jumpAtX = Math.max(10, Math.min(640, f.lx - 70 + (rnd.nextFloat() - 0.5f) * 60));
                    f.wx = -1;
                }
            }
            me.yaw = PI / 2; me.pitch = -0.25f;
            spawnLoot();
            zx = zz = 320; zr = 470; zPhase = 0; zShrink = false; zTimer = ZW[0];
            pickNextZone();
            toast("Tap JUMP when you are over your landing zone", 5);
        } else {
            for (int i = 1; i < 10; i++) {
                Fighter b = new Fighter();
                b.name = NAMES[(i + 5) % NAMES.length]; b.team = i < 5 ? 0 : 1;
                costume(b, false);
                fs.add(b);
            }
            for (Fighter f : fs) {
                if (!f.isMe && f.team == 0) { f.top = 2; f.topCol = 1; }
                if (f.team == 1) { f.top = 0; f.topCol = 0; }
                if (f.isMe && f.team == 0) { /* keep own costume */ }
                respawn(f);
            }
            planeOn = false;
            zr = 99999;
            toast("First to 30 kills wins!", 3);
        }
        state = PLAY;
        loading = false;
    }

    static void toast(String s, float t) { toast = s; toastT = t; }

    // ============================================================ loot
    static int[][] GUNTAB = {{0, 1, 2, 3, 11}, {2, 3, 4, 5, 6, 7, 11, 12}, {5, 6, 7, 8, 9, 10, 12, 13, 4}};

    static float spawnY = 1.2f;

    static void spawnPickup(int kind, int id, int count, float x, float z) {
        Pickup p = new Pickup();
        p.kind = kind; p.id = id; p.count = count; p.x = x; p.z = z;
        p.y = Math.max(0, world.groundAt(x, z, 0.3f, spawnY));
        pickups.add(p);
    }

    static void spawnLoot() {
        for (float[] lp : world.loot) {
            int tier = (int) lp[2];
            int n = tier == 2 ? 3 : (rnd.nextFloat() < 0.5f ? 2 : 1);
            for (int k = 0; k < n; k++) {
                float x = lp[0] + (rnd.nextFloat() - 0.5f) * 1.6f * k, z = lp[1] + (rnd.nextFloat() - 0.5f) * 1.6f * k;
                float r = rnd.nextFloat();
                if (r < 0.40f) {
                    int[] tab = GUNTAB[tier];
                    int id = tab[rnd.nextInt(tab.length)];
                    spawnPickup(W.K_GUN, id, W.G[id].mag / 2 + rnd.nextInt(W.G[id].mag / 2 + 1), x, z);
                    if (rnd.nextFloat() < 0.7f) spawnPickup(W.K_AMMO, W.G[id].ammo, ammoCount(W.G[id].ammo), x + 0.8f, z);
                } else if (r < 0.58f) {
                    int a = rnd.nextInt(4);
                    spawnPickup(W.K_AMMO, a, ammoCount(a), x, z);
                } else if (r < 0.76f) {
                    int[][] ht = {{0, 3, 0}, {0, 1, 3}, {1, 2, 4}};
                    spawnPickup(W.K_HEAL, ht[tier][rnd.nextInt(3)], 1 + rnd.nextInt(2), x, z);
                } else if (r < 0.86f) {
                    int lvl = Math.min(3, 1 + rnd.nextInt(1 + tier + 1) );
                    if (rnd.nextBoolean()) spawnPickup(W.K_ARMOR, lvl, 1, x, z); else spawnPickup(W.K_HELMET, lvl, 1, x, z);
                } else if (r < 0.93f) {
                    spawnPickup(W.K_GREN, 0, 1 + rnd.nextInt(2), x, z);
                } else {
                    spawnPickup(W.K_SCOPE, 1 + rnd.nextInt(tier == 2 ? 4 : 2), 1, x, z);
                }
            }
        }
    }

    static int ammoCount(int type) { return type == 0 ? 40 : (type == 1 ? 45 : (type == 2 ? 10 : 10)); }

    static int gunIndex(W.Gun g) { for (int i = 0; i < W.N; i++) if (W.G[i] == g) return i; return 0; }

    static float rating(W.Gun g) { return g.dmg * g.pellets * g.rpm / 60f * (g.cls == 3 ? 1.1f : 1f); }

    static boolean takePickup(Fighter f, Pickup p, boolean manual) {
        switch (p.kind) {
            case W.K_GUN: {
                W.Gun g = W.G[p.id];
                int s;
                if (!g.primary()) s = 2;
                else if (f.slot[0] == null) s = 0;
                else if (f.slot[1] == null) s = 1;
                else s = f.cur < 2 ? f.cur : 0;
                if (f.slot[s] != null) {
                    spawnPickup(W.K_GUN, gunIndex(f.slot[s]), f.mag[s], f.x + 0.6f, f.z + 0.6f);
                }
                f.slot[s] = g; f.mag[s] = p.count; f.cur = s; f.equipT = 0.5f; f.reloadT = 0;
                break;
            }
            case W.K_AMMO: f.reserve[p.id] += p.count; break;
            case W.K_HEAL: f.heals[p.id] += p.count; break;
            case W.K_ARMOR:
                if (p.id > f.armor || f.armorDur <= 0 || manual) { f.armor = p.id; f.armorDur = W.ARMOR_HP[p.id]; } else return false;
                break;
            case W.K_HELMET:
                if (p.id > f.helmet || f.helmDur <= 0 || manual) { f.helmet = p.id; f.helmDur = W.ARMOR_HP[p.id] * 0.6f; } else return false;
                break;
            case W.K_GREN: if (f.gren >= 6) return false; f.gren += p.count; break;
            case W.K_SCOPE: if (p.id <= f.scope && !manual) return false; f.scope = Math.max(f.scope, p.id); break;
        }
        p.alive = false;
        if (f.isMe) Sfx.play(Sfx.PICK, 0.6f);
        return true;
    }

    static Pickup nearestPickup(Fighter f, float range) {
        Pickup best = null; float bd = range * range;
        for (int i = 0; i < pickups.size(); i++) {
            Pickup p = pickups.get(i);
            if (!p.alive) continue;
            float dx = p.x - f.x, dz = p.z - f.z, d = dx * dx + dz * dz;
            if (d < bd && Math.abs(p.y - f.y) < 2.5f) { bd = d; best = p; }
        }
        return best;
    }

    static void dropLoot(Fighter v) {
        spawnY = v.y + 0.7f;
        dropLoot2(v);
        spawnY = 1.2f;
    }

    static void dropLoot2(Fighter v) {
        for (int s = 0; s < 3; s++) if (v.slot[s] != null) spawnPickup(W.K_GUN, gunIndex(v.slot[s]), v.mag[s], v.x + (rnd.nextFloat() - 0.5f) * 1.5f, v.z + (rnd.nextFloat() - 0.5f) * 1.5f);
        for (int a = 0; a < 4; a++) if (v.reserve[a] > 0) spawnPickup(W.K_AMMO, a, v.reserve[a], v.x + (rnd.nextFloat() - 0.5f) * 1.5f, v.z + (rnd.nextFloat() - 0.5f) * 1.5f);
        for (int h = 0; h < 5; h++) if (v.heals[h] > 0) spawnPickup(W.K_HEAL, h, v.heals[h], v.x + (rnd.nextFloat() - 0.5f) * 1.5f, v.z + (rnd.nextFloat() - 0.5f) * 1.5f);
        if (v.armor > 0 && v.armorDur > 0) spawnPickup(W.K_ARMOR, v.armor, 1, v.x + 0.5f, v.z - 0.5f);
        if (v.helmet > 0 && v.helmDur > 0) spawnPickup(W.K_HELMET, v.helmet, 1, v.x - 0.5f, v.z + 0.5f);
        if (v.gren > 0) spawnPickup(W.K_GREN, 0, v.gren, v.x, v.z + 0.8f);
    }

    // ============================================================ TDM respawn / loadout
    static final int[] LOADOUT = {6, 5, 3, 11, 8};

    static void respawn(Fighter f) {
        ArrayList<float[]> pts = new ArrayList<>();
        for (float[] s : world.spawns) if ((int) s[2] == f.team) pts.add(s);
        float[] p = pts.get(rnd.nextInt(pts.size()));
        f.x = p[0] + (rnd.nextFloat() - 0.5f) * 3; f.z = p[1] + (rnd.nextFloat() - 0.5f) * 3; f.y = 0;
        f.yaw = f.team == 0 ? (mapId == 2 ? PI : PI / 2) : (mapId == 2 ? 0 : -PI / 2);
        if (mapId == 2) f.yaw = f.team == 0 ? PI : 0;
        f.pitch = 0; f.byaw = f.yaw;
        f.alive = true; f.hp = 100; f.boost = 0; f.st = 3; f.vy = 0; f.stance = 0; f.ads = false;
        f.protectT = 2.5f; f.reloadT = 0; f.useT = 0; f.useKind = -1; f.burst = 0; f.target = null; f.wx = -1;
        int prim = f.isMe ? LOADOUT[Cfg.tdmLoadout % LOADOUT.length] : LOADOUT[rnd.nextInt(LOADOUT.length)];
        f.slot[0] = W.G[prim]; f.mag[0] = W.G[prim].mag;
        f.slot[1] = null; f.slot[2] = W.G[0]; f.mag[2] = W.G[0].mag;
        f.cur = 0; f.equipT = 0.4f;
        f.reserve[0] = 90; f.reserve[1] = 150; f.reserve[2] = 20; f.reserve[3] = 30;
        f.heals[0] = 3; f.heals[2] = 1; f.gren = 2; f.armor = 2; f.armorDur = W.ARMOR_HP[2]; f.helmet = 1; f.helmDur = 50;
        f.scope = 0;
    }

    // ============================================================ zone
    static void pickNextZone() {
        int p = Math.min(zPhase, 5);
        zTr = ZR[p];
        float maxOff = Math.max(0, zr - zTr) * 0.85f;
        float a = rnd.nextFloat() * 2 * PI, d = rnd.nextFloat() * maxOff;
        zTx = Math.max(zTr * 0.5f, Math.min(640 - zTr * 0.5f, zx + cos(a) * d));
        zTz = Math.max(zTr * 0.5f, Math.min(600 - zTr * 0.5f, zz + sin(a) * d));
    }

    static void updateZone(float dt) {
        zTimer -= dt;
        if (!zShrink) {
            if (zTimer <= 0) {
                zShrink = true; zTimer = ZS[Math.min(zPhase, 5)];
                zSx = zx; zSz = zz; zSr = zr;
                toast("The zone is closing!", 3);
            }
        } else {
            float t = 1f - Math.max(0, zTimer) / ZS[Math.min(zPhase, 5)];
            zx = zSx + (zTx - zSx) * t; zz = zSz + (zTz - zSz) * t; zr = zSr + (zTr - zSr) * t;
            if (zTimer <= 0) {
                zShrink = false;
                if (zPhase < 5) zPhase++;
                zTimer = ZW[Math.min(zPhase, 5)];
                zSx = zx;
                pickNextZone();
                if (zPhase < 5) toast("Next zone marked on the map", 3);
            }
        }
    }

    public static boolean inZone(float x, float z, float margin) {
        float dx = x - zx, dz = z - zz;
        return dx * dx + dz * dz < (zr - margin) * (zr - margin);
    }

    // ============================================================ main update
    public static void update(float dt) {
        if (state != PLAY || paused) return;
        if (dt > 0.05f) dt = 0.05f;
        time += dt; matchTime = time;
        if (toastT > 0) toastT -= dt;
        if (hitMarkerT > 0) hitMarkerT -= dt;
        for (int i = feed.size() - 1; i >= 0; i--) { Object[] o = feed.get(i); if (time - (Float) o[1] > 7f) feed.remove(o); }
        for (int i = dmgDirs.size() - 1; i >= 0; i--) { float[] o = dmgDirs.get(i); if (time - o[2] > 2f) dmgDirs.remove(o); }

        if (mode == 0) {
            if (planeOn) {
                planeX += 40 * dt;
                if (planeX > 650) {
                    planeOn = false;
                    if (me.st == 0) jump(me);
                }
                if (me.st == 0) { me.x = planeX; me.z = planeZ; me.y = planeY; }
            }
            updateZone(dt);
        } else {
            tdmTime -= dt;
            if (tdmTime <= 0 || scoreA >= 30 || scoreB >= 30) { finish(scoreA >= scoreB); return; }
        }

        updatePlayer(dt);
        for (int i = 0; i < fs.size(); i++) {
            Fighter f = fs.get(i);
            if (!f.alive) {
                if (mode == 1 && f.respawnT > 0) { f.respawnT -= dt; if (f.respawnT <= 0) respawn(f); }
                continue;
            }
            f.surviveT += dt;
            timers(f, dt);
            if (!f.isMe) botUpdate(f, dt);
            if (mode == 0 && f.st == 3 && !inZone(f.x, f.z, 0)) damage(f, ZD[Math.min(zPhase, 5)] * dt, false, null, "the blue zone");
        }
        updateBullets(dt);
        updateGrens(dt);
        updateTraffic(dt);
        for (int i = pickups.size() - 1; i >= 0; i--) if (!pickups.get(i).alive) pickups.remove(i);
        for (int i = parts.size() - 1; i >= 0; i--) {
            Part p = parts.get(i);
            p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy -= 9f * dt;
            if (p.life <= 0) parts.remove(i);
        }
        updateCamera(dt);
        updateTags();
        if (mode == 0 && me.alive && aliveCount() <= 1) finish(true);
    }

    static int aliveCount() { int n = 0; for (Fighter f : fs) if (f.alive) n++; return n; }

    // ============================================================ finishing
    static void finish(boolean win) {
        if (state != PLAY) return;
        resMode = mode; resWin = win; resKills = me.kills; resTime = (int) time; resDamage = (int) me.dmgDealt;
        if (mode == 0) {
            resRank = win ? 1 : me.rank;
            resTaka = 20 + (31 - resRank) * 3 + me.kills * 15 + (win ? 250 : 0);
            if (resRank < Cfg.bestRank) Cfg.bestRank = resRank;
        } else {
            resRank = win ? 1 : 2;
            resTaka = 40 + me.kills * 8 + (win ? 100 : 0);
        }
        Cfg.taka += resTaka; Cfg.matches++; Cfg.kills += me.kills;
        if (win) Cfg.wins++;
        if (!win && mode == 0) Cfg.deaths++;
        Cfg.save();
        state = RESULT;
        Input.clear();
        if (onFinish != null) onFinish.run();
    }

    // ============================================================ per-fighter timers
    static void timers(Fighter f, float dt) {
        f.cool -= dt; f.flash -= dt; f.equipT -= dt; f.protectT -= dt;
        if (f.reloadT > 0) { f.reloadT -= dt; if (f.reloadT <= 0) finishReload(f); }
        if (f.useT > 0) { f.useT -= dt; if (f.useT <= 0) finishUse(f); }
        if (f.boost > 0) { f.boost = Math.max(0, f.boost - 1.2f * dt); f.hp = Math.min(100, f.hp + 0.9f * dt); }
        if (f.burst > 0) {
            f.burstT -= dt;
            if (f.burstT <= 0 && f.mag[f.cur] > 0 && f.cur != 3) {
                fireShot(f, f.last[0], f.last[1], f.last[2], f.last[3], f.last[4], f.last[5]);
                f.burst--; f.burstT = 0.075f;
                if (f.burst == 0) f.cool = 0.32f;
            } else if (f.mag[f.cur] <= 0) f.burst = 0;
        }
        if (f.recoilAcc > 0 && !(f.isMe && (Input.fire || Input.fire2))) {
            float rec = Math.min(f.recoilAcc, 0.35f * dt);
            f.recoilAcc -= rec;
            if (f.isMe) f.pitch -= rec;
        }
    }

    static void startReload(Fighter f) {
        W.Gun g = f.gun();
        if (g.cls == 6 || f.reloadT > 0 || f.equipT > 0) return;
        if (f.mag[f.cur] >= g.mag || f.reserve[g.ammo] <= 0) return;
        f.reloadT = g.reload; f.ads = false;
        if (f.isMe) Sfx.play(Sfx.RELOAD, 0.7f);
    }

    static void finishReload(Fighter f) {
        W.Gun g = f.gun();
        if (g.cls == 6) return;
        int need = g.mag - f.mag[f.cur];
        int take = Math.min(need, f.reserve[g.ammo]);
        f.mag[f.cur] += take; f.reserve[g.ammo] -= take;
    }

    static void startUse(Fighter f, int kind) {
        if (f.useT > 0 || f.heals[kind] <= 0 || f.reloadT > 0) return;
        if (kind <= 1 && f.hp >= 75) { if (f.isMe) toast("Health is already high", 1.5f); return; }
        if (kind == 2 && f.hp >= 100) return;
        if (kind >= 3 && f.boost >= 100) return;
        f.useKind = kind; f.useT = W.HEAL_TIME[kind]; f.ads = false;
    }

    static void finishUse(Fighter f) {
        int k = f.useKind;
        if (k < 0 || f.heals[k] <= 0) return;
        f.heals[k]--;
        if (k == 0) f.hp = Math.min(75, f.hp + 12);
        else if (k == 1) f.hp = Math.max(f.hp, Math.min(75, f.hp + 60));
        else if (k == 2) f.hp = 100;
        else if (k == 3) f.boost = Math.min(100, f.boost + 40);
        else f.boost = Math.min(100, f.boost + 60);
        f.useKind = -1;
        if (f.isMe) Sfx.play(Sfx.PICK, 0.6f);
    }

    static void jump(Fighter f) {
        if (f.st != 0) return;
        f.st = 1; f.chuteAlt = 85; f.vy = 0;
        if (f.isMe) toast("Free fall! Tap JUMP again to open the parachute", 3);
    }

    // ============================================================ player
    static float adsZoom(Fighter f) {
        W.Gun g = f.gun();
        float z = g.zoom;
        if (f.scope > 0 && g.cls != 6 && g.cls != 0) z = Math.max(z, W.SCOPE_ZOOM[f.scope]);
        return z;
    }

    static void updatePlayer(float dt) {
        Fighter f = me;
        if (!f.alive) return;
        float[] lk = Input.takeLook();
        float sens = 0.0032f * Cfg.sens;
        if (f.ads) sens = 0.0032f * Cfg.sens * Cfg.sensAds / (float) Math.pow(adsZoom(f), 0.6);
        f.yaw += lk[0] * sens;
        f.pitch -= lk[1] * sens * (Cfg.invertY ? -1f : 1f);
        f.pitch = Math.max(-1.45f, Math.min(1.3f, f.pitch));

        if (f.st == 0) {                         // in plane
            if (Input.evJump) { Input.evJump = false; jump(f); }
            clearEvents(); return;
        }
        float fx = sin(f.yaw), fz = -cos(f.yaw), rx = cos(f.yaw), rz = sin(f.yaw);
        float mx = Input.moveX, my = Input.moveY;
        if (f.st == 1 || f.st == 2) {
            if (Input.evJump) { Input.evJump = false; if (f.st == 1) f.st = 2; }
            float wx = fx * my + rx * mx, wz = fz * my + rz * mx;
            airStep(f, wx, wz, dt);
            f.byaw = f.yaw;
            clearEvents(); return;
        }
        // ground events
        if (Input.evSlot >= 0) {
            int s = Input.evSlot; Input.evSlot = -1;
            if ((s == 3 || f.slot[s] != null) && s != f.cur) { f.cur = s; f.equipT = 0.5f; f.reloadT = 0; f.ads = false; f.burst = 0; }
        }
        if (Input.evReload) { Input.evReload = false; startReload(f); }
        if (Input.evCrouch) { Input.evCrouch = false; f.stance = f.stance == 1 ? 0 : 1; }
        if (Input.evProne) { Input.evProne = false; f.stance = f.stance == 2 ? 0 : 2; }
        if (Input.evJump) {
            Input.evJump = false;
            if (f.vy == 0 && f.stance != 2) { f.vy = 5.6f; f.stance = 0; }
            else if (f.stance == 2) f.stance = 0;
        }
        if (Input.evAds) { Input.evAds = false; if (f.cur != 3 && f.reloadT <= 0) f.ads = !f.ads; }
        if (Input.evGren) { Input.evGren = false; throwGren(f); }
        if (Input.evPick) { Input.evPick = false; Pickup p = nearestPickup(f, 2.6f); if (p != null) takePickup(f, p, true); }
        if (Input.evHeal >= 0) { int h = Input.evHeal; Input.evHeal = -1; startUse(f, h); }

        boolean firing = Input.fire || Input.fire2;
        // aim assist
        if (Cfg.aimAssist > 0 && (firing || f.ads) && f.cur != 3) aimAssist(f, dt);

        float mag = Math.min(1f, sqrt(mx * mx + my * my));
        f.sprint = mag > 0.92f && my > 0.5f && !f.ads && !firing && f.stance == 0 && f.useT <= 0;
        float sp = f.sprint ? 6.6f : 4.2f;
        if (f.stance == 1) sp = 2.4f; else if (f.stance == 2) sp = 1.3f;
        if (f.ads) sp *= 0.65f;
        if (f.useT > 0) sp *= 0.7f;
        if (f.inWater) sp *= 0.55f;
        if (f.boost > 20) sp *= 1.06f;
        float vx = (fx * my + rx * mx), vz = (fz * my + rz * mx);
        float vl = sqrt(vx * vx + vz * vz);
        if (vl > 1f) { vx /= vl; vz /= vl; }
        float oldx = f.x, oldz = f.z;
        walk(f, vx * sp, vz * sp, dt);
        f.speedNow = sqrt((f.x - oldx) * (f.x - oldx) + (f.z - oldz) * (f.z - oldz)) / Math.max(dt, 0.001f);
        f.walk += f.speedNow * dt * 1.6f;
        // body yaw
        if (firing || f.ads || Cfg.fpp) f.byaw = f.yaw;
        else if (f.speedNow > 0.5f) f.byaw = turn(f.byaw, (float) Math.atan2(vx, -vz), 10f * dt);
        else f.byaw = turn(f.byaw, f.yaw, 3f * dt);

        // auto pickup
        for (int i = 0; i < pickups.size(); i++) {
            Pickup p = pickups.get(i);
            if (!p.alive || p.kind == W.K_GUN) continue;
            float dx = p.x - f.x, dz = p.z - f.z;
            if (dx * dx + dz * dz < 1.6f && Math.abs(p.y - f.y) < 2f) takePickup(f, p, false);
        }
        Pickup np = nearestPickup(f, 2.6f);
        nearPick = np == null ? "" : W.itemName(np.kind, np.id, np.kind == W.K_GUN ? 1 : np.count);

        // vehicles hurt
        vehicleHits(f, dt);

        // shooting
        boolean edge = firing && !wasFiring;
        wasFiring = firing;
        if (firing && f.cur != 3 || (firing && f.cur == 3)) playerFire(f, edge);
        else if (!firing && f.cur != 3) { }
        if (f.mag[f.cur] <= 0 && f.cur != 3 && f.reserve[f.gun().ammo] > 0 && f.cool <= 0 && f.reloadT <= 0 && f.equipT <= 0 && firing) startReload(f);
    }

    static boolean wasFiring = false;

    static void clearEvents() {
        Input.evReload = Input.evCrouch = Input.evProne = Input.evGren = Input.evPick = Input.evAds = false;
        Input.evSlot = -1; Input.evHeal = -1;
    }

    static float turn(float a, float target, float maxStep) {
        float d = target - a;
        while (d > PI) d -= 2 * PI;
        while (d < -PI) d += 2 * PI;
        if (Math.abs(d) <= maxStep) return target;
        return a + (d > 0 ? maxStep : -maxStep);
    }

    static void aimAssist(Fighter f, float dt) {
        float eyeY = f.y + eye(f);
        float cone = (3f + Cfg.aimAssist * 0.10f) * PI / 180f;
        Fighter best = null; float ba = cone; float tyaw = 0, tpit = 0;
        for (Fighter e : fs) {
            if (!e.alive || e == f || e.team == f.team || e.st < 3 || e.protectT > 0) continue;
            float dx = e.x - f.x, dz = e.z - f.z, dy = e.y + e.height() * 0.7f - eyeY;
            float d = sqrt(dx * dx + dz * dz);
            if (d > 110 || d < 1) continue;
            float yaw = (float) Math.atan2(dx, -dz), pit = (float) Math.atan2(dy, d);
            float dyaw = Math.abs(turnDiff(f.yaw, yaw)), dpit = Math.abs(pit - f.pitch);
            float ang = sqrt(dyaw * dyaw + dpit * dpit);
            if (ang < ba && world.ray(f.x, eyeY, f.z, e.x, e.y + e.height() * 0.7f, e.z) > 0.98f) { ba = ang; best = e; tyaw = yaw; tpit = pit; }
        }
        if (best == null) return;
        float k = Math.min(1f, (Cfg.aimAssist / 100f) * 5f * dt);
        f.yaw += turnDiff(f.yaw, tyaw) * k;
        f.pitch += (tpit - f.pitch) * k * 0.8f;
    }

    static float turnDiff(float a, float b) {
        float d = b - a;
        while (d > PI) d -= 2 * PI;
        while (d < -PI) d += 2 * PI;
        return d;
    }

    static float eye(Fighter f) { return f.stance == 0 ? 1.65f : (f.stance == 1 ? 1.15f : 0.5f); }

    static void playerFire(Fighter f, boolean edge) {
        float cdx = sin(f.yaw) * cos(f.pitch), cdy = sin(f.pitch), cdz = -cos(f.yaw) * cos(f.pitch);
        if (f.cur == 3) { tryFire(f, true, edge, f.x, f.y + 1.4f, f.z, cdx, 0, cdz); return; }
        float ox, oy, oz;
        if (Cfg.fpp) { ox = camX; oy = camY; oz = camZ; }
        else {
            float rx = cos(f.yaw), rz = sin(f.yaw);
            ox = f.x + rx * 0.3f + sin(f.yaw) * 0.5f; oy = f.y + eye(f) - 0.15f; oz = f.z + rz * 0.3f - cos(f.yaw) * 0.5f;
        }
        // where is the crosshair pointing?
        float ex = camX + cdx * 250, ey = camY + cdy * 250, ez = camZ + cdz * 250;
        float t = world.ray(camX, camY, camZ, ex, ey, ez);
        float px = camX + (ex - camX) * t, py = camY + (ey - camY) * t, pz = camZ + (ez - camZ) * t;
        float dx = px - ox, dy = py - oy, dz = pz - oz;
        float d = sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 3f) { dx = cdx; dy = cdy; dz = cdz; d = 1; }
        tryFire(f, true, edge, ox, oy, oz, dx / d, dy / d, dz / d);
    }

    // ============================================================ movement
    static void airStep(Fighter f, float wx, float wz, float dt) {
        float hs = f.st == 1 ? 22f : 13f;
        float l = sqrt(wx * wx + wz * wz);
        if (l > 1f) { wx /= l; wz /= l; }
        f.x += wx * hs * dt; f.z += wz * hs * dt;
        f.x = Math.max(-30, Math.min(world.size + 30, f.x)); f.z = Math.max(-30, Math.min(world.size + 30, f.z));
        f.vy = f.st == 1 ? -35f : -7f;
        f.y += f.vy * dt;
        if (f.st == 1 && f.y <= f.chuteAlt) f.st = 2;
        float gh = world.groundAt(f.x, f.z, 0.35f, f.y);
        if (f.y <= gh) {
            f.y = gh; f.vy = 0; f.st = 3; f.stance = 0;
            if (f.isMe) toast("", 0);
        }
    }

    static void walk(Fighter f, float vx, float vz, float dt) {
        float r = f.radius(), h = f.height();
        float nx = f.x + vx * dt;
        if (!world.blocked(nx, f.z, r, f.y, h) && !vehBlocked(nx, f.z, r, f.y)) f.x = nx;
        float nz = f.z + vz * dt;
        if (!world.blocked(f.x, nz, r, f.y, h) && !vehBlocked(f.x, nz, r, f.y)) f.z = nz;
        f.x = Math.max(1, Math.min(world.size - 1, f.x));
        f.z = Math.max(1, Math.min(world.size - 1, f.z));
        float gh = world.groundAt(f.x, f.z, r, f.y);
        f.inWater = world.water(f.x, f.z);
        if (f.y > gh + 0.02f || f.vy > 0) {
            f.vy -= 18f * dt;
            f.y += f.vy * dt;
            if (f.y <= gh && f.vy <= 0) {
                if (f.vy < -11f && f.alive) damage(f, (-f.vy - 11f) * 7f, false, null, "a fall");
                f.y = gh; f.vy = 0;
            }
        } else { f.y = gh; f.vy = 0; }
    }

    static boolean vehBlocked(float x, float z, float r, float y) {
        ArrayList<Vehicle> tr = world.traffic;
        for (int i = 0; i < tr.size(); i++) {
            Vehicle v = tr.get(i);
            if (y > v.h - 0.2f) continue;
            float cx = v.x(), cz = v.z();
            float px = Math.max(cx - v.hx, Math.min(cx + v.hx, x)), pz = Math.max(cz - v.hz, Math.min(cz + v.hz, z));
            float dx = x - px, dz = z - pz;
            if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }

    static void vehicleHits(Fighter f, float dt) {
        f.vehCd -= dt;
        if (f.vehCd > 0) return;
        ArrayList<Vehicle> tr = world.traffic;
        for (int i = 0; i < tr.size(); i++) {
            Vehicle v = tr.get(i);
            float cx = v.x(), cz = v.z();
            float px = Math.max(cx - v.hx - 0.3f, Math.min(cx + v.hx + 0.3f, f.x)), pz = Math.max(cz - v.hz - 0.3f, Math.min(cz + v.hz + 0.3f, f.z));
            float dx = f.x - px, dz = f.z - pz;
            if (dx * dx + dz * dz < 0.2f && f.y < v.h) {
                f.vehCd = 1.2f;
                damage(f, 14f + v.speed * 1.5f, false, null, "a vehicle");
                // push aside
                float ux = f.x - cx, uz = f.z - cz, ul = Math.max(0.1f, sqrt(ux * ux + uz * uz));
                f.x += ux / ul * 1.2f; f.z += uz / ul * 1.2f;
                return;
            }
        }
    }

    static void updateTraffic(float dt) {
        for (Vehicle v : world.traffic) {
            v.pos += v.dir * v.speed * dt;
            if (v.pos > v.maxP) v.pos = v.minP;
            if (v.pos < v.minP) v.pos = v.maxP;
        }
        if (world.hasTrain) {
            world.trainPos += world.trainDir * 14f * dt;
            if (world.trainPos > world.trainMax) { world.trainPos = world.trainMax; world.trainDir = -1; }
            if (world.trainPos < world.trainMin) { world.trainPos = world.trainMin; world.trainDir = 1; }
        }
    }

    // ============================================================ shooting
    static void tryFire(Fighter f, boolean trigger, boolean edge, float ox, float oy, float oz, float dx, float dy, float dz) {
        if (f.equipT > 0 || f.reloadT > 0 || f.useT > 0 || f.cool > 0 || f.st != 3 || f.burst > 0) return;
        W.Gun g = f.gun();
        if (g.cls == 6) { if (trigger) { meleeHit(f); f.cool = 60f / g.rpm; } return; }
        if (f.mag[f.cur] <= 0) { if (edge && f.reserve[g.ammo] > 0) startReload(f); return; }
        if (g.mode == 0 && !edge) return;
        if (g.mode == 2 && !edge) return;
        f.last[0] = ox; f.last[1] = oy; f.last[2] = oz; f.last[3] = dx; f.last[4] = dy; f.last[5] = dz;
        fireShot(f, ox, oy, oz, dx, dy, dz);
        if (g.mode == 2) { f.burst = 2; f.burstT = 0.075f; }
        else f.cool = 60f / g.rpm;
    }

    static void fireShot(Fighter f, float ox, float oy, float oz, float dx, float dy, float dz) {
        W.Gun g = f.gun();
        f.mag[f.cur]--;
        float spread = g.spread;
        if (f.speedNow > 1f) spread *= 1.6f;
        if (f.ads) spread *= 0.55f;
        if (f.stance == 1) spread *= 0.8f; else if (f.stance == 2) spread *= 0.6f;
        // perpendicular basis
        float ux, uy, uz;
        if (Math.abs(dy) > 0.95f) { ux = 1; uy = 0; uz = 0; }
        else { ux = dz; uy = 0; uz = -dx; float l = sqrt(ux * ux + uz * uz); ux /= l; uz /= l; }
        float vx = dy * uz - dz * uy, vy = dz * ux - dx * uz, vz = dx * uy - dy * ux;
        for (int p = 0; p < g.pellets; p++) {
            float ang = rnd.nextFloat() * 2 * PI, rad = sqrt(rnd.nextFloat()) * spread * PI / 180f;
            float a = cos(ang) * rad, b = sin(ang) * rad;
            float bx = dx + ux * a + vx * b, by = dy + uy * a + vy * b, bz = dz + uz * a + vz * b;
            float l = sqrt(bx * bx + by * by + bz * bz);
            Bullet bl = new Bullet();
            bl.x = ox; bl.y = oy; bl.z = oz;
            bl.vx = bx / l * g.speed; bl.vy = by / l * g.speed; bl.vz = bz / l * g.speed;
            bl.dmg = g.dmg; bl.owner = f; bl.life = 1.6f; bl.gun = g.name; bl.cls = g.cls; bl.heavy = g.cls >= 3;
            bullets.add(bl);
        }
        f.flash = 0.06f;
        // recoil
        if (f.isMe) {
            float kick = g.recoil * 0.0038f * (f.ads ? 0.75f : 1f);
            f.pitch += kick; f.recoilAcc += kick;
            f.yaw += (rnd.nextFloat() - 0.5f) * g.recoil * 0.0026f;
        }
        // sound + noise
        float dm = me == null ? 100 : sqrt((me.x - f.x) * (me.x - f.x) + (me.z - f.z) * (me.z - f.z));
        Sfx.play(g.cls >= 3 ? Sfx.SHOT_HEAVY : Sfx.SHOT, f.isMe ? 0.9f : Math.max(0f, 1f - dm / 160f));
        for (Fighter e : fs) {
            if (e == f || !e.alive || e.isMe) continue;
            float ex = e.x - f.x, ez = e.z - f.z;
            if (ex * ex + ez * ez < 90f * 90f) { e.hearX = f.x; e.hearZ = f.z; e.hearT = time; }
        }
    }

    static void meleeHit(Fighter f) {
        float fx = sin(f.yaw), fz = -cos(f.yaw);
        W.Gun g = W.TAWA;
        for (Fighter e : fs) {
            if (!e.alive || e == f || e.team == f.team || e.st < 3) continue;
            float dx = e.x - f.x, dz = e.z - f.z, d = sqrt(dx * dx + dz * dz);
            if (d < 2.4f && d > 0.01f && (dx * fx + dz * fz) / d > 0.5f) {
                damage(e, g.dmg, false, f, g.name);
                Sfx.play(Sfx.HIT, 0.8f);
                break;
            }
        }
    }

    static void throwGren(Fighter f) {
        if (f.gren <= 0 || f.cool > 0 || f.st != 3) return;
        f.gren--; f.cool = 0.8f;
        Gren g = new Gren();
        float cp = cos(f.pitch + 0.25f);
        g.x = f.x; g.y = f.y + 1.5f; g.z = f.z;
        g.vx = sin(f.yaw) * cp * 15f; g.vy = sin(f.pitch + 0.25f) * 15f + 2f; g.vz = -cos(f.yaw) * cp * 15f;
        g.fuse = 3.2f; g.owner = f;
        grens.add(g);
    }

    static float hitY;

    static float segCyl(float ax, float ay, float az, float bx, float by, float bz, float cx, float cy0, float cz, float r, float cy1) {
        float dx = bx - ax, dz = bz - az, dy = by - ay;
        float fx = ax - cx, fz = az - cz;
        float a = dx * dx + dz * dz, c = fx * fx + fz * fz - r * r;
        float t;
        if (a < 1e-8f) { if (c > 0) return 2f; t = 0; }
        else {
            float b = 2 * (fx * dx + fz * dz);
            float disc = b * b - 4 * a * c;
            if (disc < 0) return 2f;
            float sq = sqrt(disc);
            t = (-b - sq) / (2 * a);
            if (c < 0) t = 0;
            if (t < 0 || t > 1) return 2f;
        }
        float y = ay + dy * t;
        if (y < cy0 || y > cy1) return 2f;
        hitY = y;
        return t;
    }

    static void updateBullets(float dt) {
        for (int i = bullets.size() - 1; i >= 0; i--) {
            Bullet b = bullets.get(i);
            float nx = b.x + b.vx * dt, ny = b.y + b.vy * dt, nz = b.z + b.vz * dt;
            float tw = world.ray(b.x, b.y, b.z, nx, ny, nz);
            float tf = 2f; Fighter hit = null; boolean head = false;
            for (int k = 0; k < fs.size(); k++) {
                Fighter f = fs.get(k);
                if (!f.alive || f == b.owner || f.st < 3 || f.team == b.owner.team) continue;
                float t = segCyl(b.x, b.y, b.z, nx, ny, nz, f.x, f.y, f.z, f.radius(), f.y + f.height());
                if (t < tf) { tf = t; hit = f; head = hitY > f.y + f.height() * 0.8f; }
            }
            float seg = sqrt((nx - b.x) * (nx - b.x) + (ny - b.y) * (ny - b.y) + (nz - b.z) * (nz - b.z));
            if (hit != null && tf <= tw) {
                float d = b.dist + seg * tf;
                float fall = b.cls == 4 ? Math.max(0.12f, 1f - d / 38f) : (b.cls == 1 ? Math.max(0.6f, 1f - d / 160f) : (b.cls == 0 ? Math.max(0.5f, 1f - d / 120f) : 1f));
                float dm = b.dmg * fall * (head ? 2.3f : 1f);
                blood(b.x + (nx - b.x) * tf, hitY, b.z + (nz - b.z) * tf);
                damage(hit, dm, head, b.owner, b.gun);
                bullets.remove(i);
                continue;
            }
            if (tw < 1f) {
                spark(b.x + (nx - b.x) * tw, b.y + (ny - b.y) * tw, b.z + (nz - b.z) * tw);
                bullets.remove(i);
                continue;
            }
            b.x = nx; b.y = ny; b.z = nz; b.vy -= 9.8f * dt; b.life -= dt; b.dist += seg;
            if (b.life <= 0 || b.y < -3) bullets.remove(i);
        }
    }

    static void spark(float x, float y, float z) {
        for (int i = 0; i < 4; i++) addPart(x, y, z, 0.9f, 0.85f, 0.6f, 0.25f, 0.06f, 3f, false);
    }

    static void blood(float x, float y, float z) {
        for (int i = 0; i < 5; i++) addPart(x, y, z, 0.7f, 0.05f, 0.05f, 0.4f, 0.08f, 2.5f, false);
    }

    static void addPart(float x, float y, float z, float r, float g, float b, float life, float size, float spd, boolean glow) {
        Part p = new Part();
        p.x = x; p.y = y; p.z = z; p.r = r; p.g = g; p.b = b; p.life = life; p.size = size; p.glow = glow;
        p.vx = (rnd.nextFloat() - 0.5f) * spd; p.vy = rnd.nextFloat() * spd * 0.8f; p.vz = (rnd.nextFloat() - 0.5f) * spd;
        if (parts.size() < 400) parts.add(p);
    }

    static void updateGrens(float dt) {
        for (int i = grens.size() - 1; i >= 0; i--) {
            Gren g = grens.get(i);
            g.fuse -= dt;
            g.vy -= 14f * dt;
            float nx = g.x + g.vx * dt;
            if (world.blocked(nx, g.z, 0.15f, g.y - 0.1f, 0.3f)) g.vx = -g.vx * 0.4f; else g.x = nx;
            float nz = g.z + g.vz * dt;
            if (world.blocked(g.x, nz, 0.15f, g.y - 0.1f, 0.3f)) g.vz = -g.vz * 0.4f; else g.z = nz;
            g.y += g.vy * dt;
            float gh = world.groundAt(g.x, g.z, 0.15f, g.y + 0.3f);
            if (g.y <= gh + 0.12f) { g.y = gh + 0.12f; g.vy = Math.abs(g.vy) > 1.5f ? -g.vy * 0.35f : 0; g.vx *= 0.75f; g.vz *= 0.75f; }
            if (g.fuse <= 0) { explode(g); grens.remove(i); }
        }
    }

    static void explode(Gren g) {
        for (int i = 0; i < 25; i++) addPart(g.x, g.y + 0.3f, g.z, 1f, 0.6f + rnd.nextFloat() * 0.3f, 0.1f, 0.6f, 0.35f, 9f, true);
        for (int i = 0; i < 10; i++) addPart(g.x, g.y + 0.3f, g.z, 0.25f, 0.25f, 0.25f, 1.0f, 0.5f, 5f, false);
        float dm = me == null ? 100 : sqrt((me.x - g.x) * (me.x - g.x) + (me.z - g.z) * (me.z - g.z));
        Sfx.play(Sfx.EXPLODE, Math.max(0f, 1f - dm / 200f));
        for (Fighter f : fs) {
            if (!f.alive || f.st < 3) continue;
            float dx = f.x - g.x, dy = f.y + 1f - g.y, dz = f.z - g.z, d = sqrt(dx * dx + dy * dy + dz * dz);
            if (d > 10f) continue;
            if (world.ray(g.x, g.y + 0.4f, g.z, f.x, f.y + 1f, f.z) < 0.97f) continue;
            float dmg = 160f * (1f - d / 10f);
            if (dmg > 5f) damage(f, dmg, false, f == g.owner ? null : g.owner, "Frag Grenade");
        }
    }

    // ============================================================ damage / death
    static void damage(Fighter v, float dmg, boolean head, Fighter by, String cause) {
        if (!v.alive || v.protectT > 0) return;
        if (by == null) {
            // environment damage ignores armor
        } else if (head) {
            if (v.helmet > 0 && v.helmDur > 0) { float a = dmg * W.ARMOR_ABS[v.helmet]; v.helmDur -= a; dmg -= a; if (v.helmDur <= 0) v.helmet = 0; }
        } else if (v.armor > 0 && v.armorDur > 0) {
            float a = dmg * W.ARMOR_ABS[v.armor]; v.armorDur -= a; dmg -= a; if (v.armorDur <= 0) v.armor = 0;
        }
        if (by == null && dmg < 1.5f) { v.hp -= dmg; if (v.hp <= 0) kill(v, null, cause); return; }
        v.hp -= dmg;
        if (by != null && by != v) by.dmgDealt += dmg;
        if (v.isMe) {
            Sfx.play(Sfx.HURT, 0.8f);
            if (by != null) dmgDirs.add(new float[]{by.x, by.z, time});
        }
        if (by != null && by.isMe && by != v) { hitMarkerT = 0.25f; hitHead = head; Sfx.play(Sfx.DING, 0.7f); }
        if (!v.isMe && by != null && by != v) {
            float dx = by.x - v.x, dz = by.z - v.z;
            if (v.target == null && dx * dx + dz * dz < 130f * 130f) { v.target = by; v.react = 0.35f; v.seenT = 0; }
        }
        if (v.hp <= 0) kill(v, by, cause);
    }

    static void kill(Fighter v, Fighter by, String cause) {
        v.alive = false; v.hp = 0; v.ads = false; v.burst = 0;
        if (mode == 0) v.rank = aliveCount() + 1;
        dropLoot(v);
        if (by != null && by != v) {
            by.kills++;
            if (by.isMe) { myKills++; toast("You eliminated " + v.name + " with " + cause, 3f); }
            feed.add(new Object[]{by.name + "  [" + cause + "]  " + v.name, time});
        } else feed.add(new Object[]{v.name + " died: " + cause, time});
        if (mode == 1) {
            if (by != null && by != v) { if (by.team == 0) scoreA++; else scoreB++; }
            else { if (v.team == 0) scoreB++; else scoreA++; }
            v.respawnT = 3.5f;
            if (v.isMe) toast("Respawning...", 3.4f);
        } else if (v.isMe) {
            finish(false);
        }
    }

    // ============================================================ camera
    static void updateCamera(float dt) {
        Fighter f = me;
        if (!f.alive) { return; }
        float zoom = f.ads ? adsZoom(f) : 1f;
        float tf = Math.max(8f, 72f / zoom);
        if (f.st == 1 || f.st == 2) tf = 80f;
        fov += (tf - fov) * Math.min(1f, 12f * dt);
        float dx = sin(f.yaw) * cos(f.pitch), dy = sin(f.pitch), dz = -cos(f.yaw) * cos(f.pitch);
        camYaw = f.yaw; camPitch = f.pitch;
        if (f.st == 0) {
            camX = f.x - dx * 45; camY = f.y - dy * 45 + 8; camZ = f.z - dz * 45;
            return;
        }
        float ex = f.x, ey = f.y + eye(f), ez = f.z;
        if (Cfg.fpp && f.st == 3) { camX = ex + dx * 0.2f; camY = ey; camZ = ez + dz * 0.2f; return; }
        float rx = cos(f.yaw), rz = sin(f.yaw);
        float sh = f.ads ? 0.35f : 0.55f;
        float px = ex + rx * sh, py = ey + 0.1f, pz = ez + rz * sh;
        float dist = f.st == 3 ? (f.ads ? 1.8f : 3.4f) : 7f;
        float cx = px - dx * dist, cy = py - dy * dist, cz = pz - dz * dist;
        float t = world.ray(px, py, pz, cx, cy, cz);
        if (t < 1f) { t = Math.max(0.05f, t * 0.88f); cx = px + (cx - px) * t; cy = py + (cy - py) * t; cz = pz + (cz - pz) * t; }
        camX = cx; camY = Math.max(0.2f, cy); camZ = cz;
    }

    static void updateTags() {
        tags.clear();
        if (!me.alive || me.st == 0) return;
        float dx = sin(camYaw) * cos(camPitch), dy = sin(camPitch), dz = -cos(camYaw) * cos(camPitch);
        float rx = cos(camYaw), rz = sin(camYaw);
        // up = right x forward... compute
        float ux = rz * dy * 0 + (-dy * sin(camYaw)), uy = cos(camPitch), uz = dy * cos(camYaw);
        float th = (float) Math.tan(fov * PI / 360f);
        for (Fighter f : fs) {
            if (f == me || !f.alive || f.st < 3) continue;
            float lim = mode == 1 ? 70f : 0f;
            if (mode == 0) continue;
            float vx = f.x - camX, vy = f.y + f.height() + 0.35f - camY, vz = f.z - camZ;
            float d = sqrt(vx * vx + vy * vy + vz * vz);
            if (d > lim) continue;
            float zf = vx * dx + vy * dy + vz * dz;
            if (zf < 0.5f) continue;
            float xr = vx * rx + vz * rz;
            float yu = vx * ux + vy * uy + vz * uz;
            Tag t = new Tag();
            t.sx = 0.5f + (xr / (zf * th * aspect)) * 0.5f;
            t.sy = 0.5f - (yu / (zf * th)) * 0.5f;
            t.name = f.name; t.hp = f.hp; t.enemy = f.team != me.team;
            if (t.sx > 0 && t.sx < 1 && t.sy > 0 && t.sy < 1) tags.add(t);
        }
    }

    // ============================================================ bots
    static float prefRange(W.Gun g) {
        switch (g.cls) { case 0: return 22; case 1: return 26; case 2: return 42; case 3: return 75; case 4: return 8; case 5: return 48; default: return 1.4f; }
    }

    static void botUpdate(Fighter b, float dt) {
        if (b.st == 0) {
            b.x = planeX; b.z = planeZ; b.y = planeY;
            if (planeX >= b.jumpAtX) { b.st = 1; b.chuteAlt = 55 + rnd.nextFloat() * 35; }
            return;
        }
        if (b.st == 1 || b.st == 2) {
            float dx = b.lx - b.x, dz = b.lz - b.z, d = Math.max(1f, sqrt(dx * dx + dz * dz));
            airStep(b, dx / d * Math.min(1f, d / 20f), dz / d * Math.min(1f, d / 20f), dt);
            b.byaw = (float) Math.atan2(dx, -dz); b.yaw = b.byaw;
            return;
        }
        b.thinkT -= dt;
        if (b.thinkT <= 0) { b.thinkT = 0.25f + rnd.nextFloat() * 0.2f; botThink(b); }
        botAct(b, dt);
        vehicleHits(b, dt);
    }

    static float botErr() { return Cfg.botLevel == 0 ? 7f : (Cfg.botLevel == 1 ? 4.2f : 2.3f); }
    static float botReact() { return Cfg.botLevel == 0 ? 0.9f : (Cfg.botLevel == 1 ? 0.55f : 0.28f); }

    static void botThink(Fighter b) {
        float sight = 70 + Cfg.botLevel * 22;
        Fighter best = null; float bd = 1e9f;
        for (Fighter e : fs) {
            if (e == b || !e.alive || e.st < 3 || e.team == b.team || e.protectT > 0) continue;
            float dx = e.x - b.x, dz = e.z - b.z, d = sqrt(dx * dx + dz * dz);
            if (d < sight && d < bd && world.ray(b.x, b.y + 1.6f, b.z, e.x, e.y + 1.3f, e.z) > 0.98f) { bd = d; best = e; }
        }
        if (best != null) {
            if (b.target != best) { b.target = best; b.react = botReact(); }
            b.seenT = 0;
        } else {
            b.seenT += 0.3f;
            if (b.seenT > 3f) b.target = null;
        }
        // switch to a usable weapon
        if (b.cur != 3) {
            W.Gun g = b.gun();
            if (b.mag[b.cur] <= 0 && b.reserve[g.ammo] <= 0) {
                int alt = 3;
                for (int s = 0; s < 3; s++) if (b.slot[s] != null && (b.mag[s] > 0 || b.reserve[b.slot[s].ammo] > 0)) alt = s;
                b.cur = alt; b.equipT = 0.4f;
            } else if (b.mag[b.cur] < g.mag / 3 && b.target == null) startReload(b);
        } else {
            for (int s = 0; s < 3; s++) if (b.slot[s] != null && (b.mag[s] > 0 || b.reserve[b.slot[s].ammo] > 0)) { b.cur = s; b.equipT = 0.4f; break; }
        }
        if (b.target != null && b.mag[b.cur] <= 0 && b.cur != 3 && b.reserve[b.gun().ammo] > 0) startReload(b);
        b.urgent = false;
        if (mode == 0 && !inZone(b.x, b.z, 8)) { b.wx = zx; b.wz = zz; b.urgent = true; b.loot = null; return; }
        if (b.target != null) return;
        // heal when safe
        if (b.hp < 55 && b.useT <= 0) {
            if (b.heals[2] > 0) startUse(b, 2); else if (b.heals[1] > 0) startUse(b, 1); else if (b.heals[0] > 0) startUse(b, 0);
        } else if (b.boost < 30 && b.useT <= 0 && b.heals[3] + b.heals[4] > 0) startUse(b, b.heals[4] > 0 ? 4 : 3);
        // hear gunfire
        if (time - b.hearT < 4f && b.loot == null) { b.wx = b.hearX; b.wz = b.hearZ; }
        if (mode == 0) {
            if (b.loot != null && !b.loot.alive) b.loot = null;
            if (b.loot == null) {
                float bs = 0; Pickup bp = null;
                for (int i = 0; i < pickups.size(); i++) {
                    Pickup p = pickups.get(i);
                    if (!p.alive) continue;
                    float dx = p.x - b.x, dz = p.z - b.z, d2 = dx * dx + dz * dz;
                    if (d2 > 110f * 110f || Math.abs(p.y - b.y) > 4f) continue;
                    float s = lootScore(b, p) - sqrt(d2) * 0.45f;
                    if (s > bs) { bs = s; bp = p; }
                }
                b.loot = bp;
            }
            if (b.loot != null) { b.wx = b.loot.x; b.wz = b.loot.z; return; }
        }
        float dx = b.wx - b.x, dz = b.wz - b.z;
        if (b.wx < 0 || dx * dx + dz * dz < 9f) newRoam(b);
    }

    static float lootScore(Fighter b, Pickup p) {
        switch (p.kind) {
            case W.K_GUN: {
                W.Gun g = W.G[p.id];
                if (!g.primary()) return b.slot[2] == null ? 40 : 0;
                if (b.slot[0] == null && b.slot[1] == null) return 130;
                float cur = Math.max(b.slot[0] == null ? 0 : rating(b.slot[0]), b.slot[1] == null ? 0 : rating(b.slot[1]));
                if (b.slot[0] == null || b.slot[1] == null) return 80;
                return rating(g) > cur * 1.2f ? 70 : 0;
            }
            case W.K_AMMO: {
                for (int s = 0; s < 3; s++) if (b.slot[s] != null && b.slot[s].ammo == p.id && b.reserve[p.id] < 80) return 55;
                return 0;
            }
            case W.K_HEAL: return b.heals[p.id] < 3 ? 30 : 0;
            case W.K_ARMOR: return p.id > b.armor ? 75 : 0;
            case W.K_HELMET: return p.id > b.helmet ? 65 : 0;
            case W.K_GREN: return b.gren < 2 ? 18 : 0;
            default: return 6;
        }
    }

    static void newRoam(Fighter b) {
        if (mode == 0) {
            float a = rnd.nextFloat() * 2 * PI, r = rnd.nextFloat() * Math.max(10f, zr * 0.8f);
            b.wx = Math.max(10, Math.min(630, zx + cos(a) * r)); b.wz = Math.max(10, Math.min(520, zz + sin(a) * r));
        } else {
            b.wx = 10 + rnd.nextFloat() * 140; b.wz = 10 + rnd.nextFloat() * 140;
        }
    }

    static void botAct(Fighter b, float dt) {
        float vx = 0, vz = 0, sp = 4.4f;
        W.Gun g = b.gun();
        Fighter t = b.target;
        boolean combat = t != null && t.alive && t.st == 3 && b.seenT < 1.6f;
        if (combat) {
            float dx = t.x - b.x, dz = t.z - b.z, d = Math.max(0.1f, sqrt(dx * dx + dz * dz));
            float desired = (float) Math.atan2(dx, -dz);
            b.yaw = turn(b.yaw, desired, (3.5f + Cfg.botLevel * 2f) * dt);
            b.byaw = b.yaw;
            float pr = prefRange(g);
            float fx = dx / d, fz = dz / d;
            if (d > pr * 1.3f) { vx = fx; vz = fz; }
            else if (d < pr * 0.55f && g.cls != 6) { vx = -fx; vz = -fz; sp = 3.5f; }
            else {
                b.strafeT -= dt;
                if (b.strafeT <= 0) { b.strafeDir = -b.strafeDir; b.strafeT = 0.8f + rnd.nextFloat() * 1.4f; }
                vx = -fz * b.strafeDir * 0.8f; vz = fx * b.strafeDir * 0.8f; sp = 3.2f;
            }
            b.react -= dt;
            float range = g.cls == 4 ? 20 : (g.cls == 6 ? 2.2f : (g.cls == 1 || g.cls == 0 ? 55 : 130));
            if (b.react <= 0 && d < range && b.equipT <= 0 && b.reloadT <= 0 && b.useT <= 0) {
                if (b.burstOff > 0) b.burstOff -= dt;
                else {
                    b.burstOn -= dt;
                    float ox = b.x, oy = b.y + 1.5f, oz = b.z;
                    float tx = t.x, ty = t.y + t.height() * 0.65f, tz = t.z;
                    if (t.stance == 0 && rnd.nextFloat() < 0.04f * Cfg.botLevel) ty = t.y + t.height() * 0.92f;
                    float ex = tx - ox, ey = ty - oy, ez = tz - oz, el = Math.max(0.1f, sqrt(ex * ex + ey * ey + ez * ez));
                    ex /= el; ey /= el; ez /= el;
                    float err = botErr() * (1f + d / 90f) * PI / 180f;
                    ex += (rnd.nextFloat() - 0.5f) * 2 * err; ey += (rnd.nextFloat() - 0.5f) * 2 * err * 0.7f; ez += (rnd.nextFloat() - 0.5f) * 2 * err;
                    float l = Math.max(0.1f, sqrt(ex * ex + ey * ey + ez * ez));
                    tryFire(b, true, true, ox, oy, oz, ex / l, ey / l, ez / l);
                    if (b.burstOn <= 0) { b.burstOff = 0.3f + rnd.nextFloat() * 0.7f; b.burstOn = 0.4f + rnd.nextFloat() * 1.0f; if (g.mode == 0) b.burstOff *= 0.3f; }
                }
            }
            // throw grenade at medium range
            if (b.gren > 0 && d > 12 && d < 35 && b.cool <= 0 && rnd.nextFloat() < 0.004f) { b.pitch = 0.25f; throwGren(b); }
        } else {
            float dx = b.wx - b.x, dz = b.wz - b.z, d = sqrt(dx * dx + dz * dz);
            if (d > 0.5f) { vx = dx / d; vz = dz / d; }
            if (b.urgent) sp = 6.4f; else if (b.loot != null) sp = 5.2f;
            if (d > 0.5f) { b.yaw = turn(b.yaw, (float) Math.atan2(vx, -vz), 6f * dt); b.byaw = b.yaw; }
            // pick up
            if (b.loot != null && b.loot.alive && d < 1.7f) {
                Pickup p = b.loot;
                if (p.kind == W.K_GUN) { if (lootScore(b, p) > 0) takePickup(b, p, false); else p.alive = false; }
                else takePickup(b, p, false);
                b.loot = null; b.thinkT = 0;
            } else if (b.loot == null) {
                // grab anything we walk over
                Pickup np = nearestPickup(b, 1.3f);
                if (np != null && np.kind != W.K_GUN) takePickup(b, np, false);
            }
        }
        // avoid being stuck
        if (b.avoidT > 0) {
            b.avoidT -= dt;
            float c = cos(b.avoidAng), s = sin(b.avoidAng);
            float nvx = vx * c - vz * s, nvz = vx * s + vz * c;
            vx = nvx; vz = nvz;
        }
        float ox = b.x, oz = b.z;
        if (b.useT > 0) sp *= 0.6f;
        if (b.reloadT > 0) sp *= 0.85f;
        if (b.inWater) sp *= 0.55f;
        walk(b, vx * sp, vz * sp, dt);
        b.speedNow = sqrt((b.x - ox) * (b.x - ox) + (b.z - oz) * (b.z - oz)) / Math.max(dt, 0.001f);
        b.walk += b.speedNow * dt * 1.6f;
        b.stuckT += dt;
        if (b.stuckT > 0.7f) {
            float mv = sqrt((b.x - b.lastX) * (b.x - b.lastX) + (b.z - b.lastZ) * (b.z - b.lastZ));
            if ((vx != 0 || vz != 0) && mv < 0.7f) {
                b.avoidT = 1.0f + rnd.nextFloat(); b.avoidAng = (rnd.nextBoolean() ? 1 : -1) * (1.0f + rnd.nextFloat() * 1.2f);
                if (rnd.nextFloat() < 0.4f) { newRoam(b); b.loot = null; }
                if (b.vy == 0) b.vy = 5.4f;
            }
            b.lastX = b.x; b.lastZ = b.z; b.stuckT = 0;
        }
    }
}
