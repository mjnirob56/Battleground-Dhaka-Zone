package com.dhaka.battlezone;

/** Tiny English / Bangla string table. */
public class Lang {
    static final String[][] T = {
        {"play", "PLAY", "খেলুন"},
        {"wardrobe", "WARDROBE", "পোশাক"},
        {"stats", "CAREER", "পরিসংখ্যান"},
        {"settings", "SETTINGS", "সেটিংস"},
        {"quit", "EXIT", "বের হোন"},
        {"back", "BACK", "ফিরে যান"},
        {"br", "BATTLE ROYALE - DHAKA (30)", "ব্যাটল রয়্যাল - ঢাকা (৩০)"},
        {"tdm1", "TDM - GULISTAN 5v5", "টিম ডেথম্যাচ - গুলিস্তান ৫v৫"},
        {"tdm2", "TDM - MIRPUR 5v5", "টিম ডেথম্যাচ - মিরপুর ৫v৫"},
        {"tdm3", "TDM - LALBAGH 5v5", "টিম ডেথম্যাচ - লালবাগ ৫v৫"},
        {"loadout", "TDM Loadout", "টিডিএম অস্ত্র"},
        {"resume", "RESUME", "চালিয়ে যান"},
        {"leave", "LEAVE MATCH", "ম্যাচ ছাড়ুন"},
        {"lobby", "LOBBY", "লবি"},
        {"again", "PLAY AGAIN", "আবার খেলুন"},
        {"win", "BIRIYANI DINNER!", "বিরিয়ানি ডিনার!"},
        {"lose", "BETTER LUCK NEXT TIME", "আবার চেষ্টা করুন"},
        {"rank", "Rank", "র‍্যাঙ্ক"},
        {"kills", "Kills", "কিল"},
        {"taka", "Taka", "টাকা"},
        {"damage", "Damage", "ড্যামেজ"},
        {"time", "Survived", "টিকে ছিলেন"},
        {"top", "Top", "উপরের পোশাক"},
        {"bottom", "Bottom", "নিচের পোশাক"},
        {"head", "Headwear", "মাথার পোশাক"},
        {"color", "Colours", "রং"},
        {"sens", "Camera sensitivity", "ক্যামেরা সেন্সিটিভিটি"},
        {"sensads", "ADS sensitivity", "এডিএস সেন্সিটিভিটি"},
        {"assist", "Aim assist", "এইম অ্যাসিস্ট"},
        {"hud", "HUD size", "এইচইউডি সাইজ"},
        {"volume", "Volume", "ভলিউম"},
        {"fpp", "First person view", "ফার্স্ট পারসন ভিউ"},
        {"sound", "Sound", "সাউন্ড"},
        {"quality", "Graphics", "গ্রাফিক্স"},
        {"fps", "Frame rate", "ফ্রেম রেট"},
        {"bots", "Bot level", "বট লেভেল"},
        {"lang", "Language", "ভাষা"},
        {"invert", "Invert look Y", "লুক Y উল্টানো"},
        {"leftfire", "Left fire button", "বাম ফায়ার বাটন"},
        {"loading", "Loading Dhaka...", "ঢাকা লোড হচ্ছে..."},
        {"matches", "Matches", "ম্যাচ"},
        {"wins", "Wins", "জয়"},
        {"deaths", "Deaths", "মৃত্যু"},
        {"best", "Best rank", "সেরা র‍্যাঙ্ক"},
        {"hs", "Headshots", "হেডশট"},
        {"owned", "OWNED", "আছে"},
    };

    public static String t(String k) {
        for (String[] r : T) if (r[0].equals(k)) return r[Cfg.lang == 1 ? 2 : 1];
        return k;
    }
}
