package com.dhaka.battlezone;

/** Entity classes used by the game. */
class Fighter {
    boolean isMe, alive = true;
    int team;
    String name = "Bot";
    float x, y, z, vy, yaw, pitch;
    int st;                 // 0 plane, 1 freefall, 2 parachute, 3 ground
    int stance;             // 0 stand, 1 crouch, 2 prone
    float hp = 100, boost, armorDur, helmDur;
    int armor, helmet;
    W.Gun[] slot = new W.Gun[3];
    int[] mag = new int[3];
    int cur = 3;            // 0,1 primary, 2 sidearm, 3 melee
    int[] reserve = new int[4];
    int[] heals = new int[5];
    int gren, scope;
    float cool, reloadT, equipT, useT;
    int useKind = -1, burst;
    float burstT, flash, walk;
    boolean sprint, ads, inWater, wantFire;
    int kills;
    float dmgDealt, surviveT, respawnT, protectT, vehCd, byaw, recoilAcc, speedNow;
    float[] last = new float[6];
    int rank;
    // costume
    int top, topCol, bottom, bottomCol, head, headCol, shoeCol;
    // AI
    float thinkT, react, wx, wz, mvx, mvz, seenT, lastX, lastZ, stuckT, avoidT, avoidAng, strafeT;
    int strafeDir = 1;
    float burstOn, burstOff, hearX, hearZ, hearT, jumpAtX, lx, lz, chuteAlt, aimDelay, healWant;
    boolean urgent;
    Fighter target;
    Pickup loot;

    W.Gun gun() { return cur == 3 ? W.TAWA : slot[cur]; }
    float height() { return stance == 0 ? 1.8f : (stance == 1 ? 1.3f : 0.6f); }
    float radius() { return stance == 2 ? 0.45f : 0.35f; }
}

class Bullet {
    float x, y, z, vx, vy, vz, dmg, life;
    Fighter owner;
    String gun;
    boolean heavy;
    float dist;
    int cls;
}

class Pickup {
    int kind, id, count;
    float x, y, z;
    boolean alive = true;
    int tier;
}

class Gren {
    float x, y, z, vx, vy, vz, fuse;
    Fighter owner;
}

class Part {
    float x, y, z, vx, vy, vz, life, size, r, g, b;
    boolean glow;
}

class Vehicle {
    int type;               // 0 CNG, 1 rickshaw, 2 bus, 3 car, 4 truck
    int axis;               // 0 moves along X, 1 along Z
    float dir = 1, speed, lane, pos, minP, maxP;
    float hx, hz, h;        // half extents (world axes) and height
    float cr, cg, cb;
    float x() { return axis == 0 ? pos : lane; }
    float z() { return axis == 0 ? lane : pos; }
}

class Tag {
    float sx, sy, hp;
    String name;
    boolean enemy;
}
