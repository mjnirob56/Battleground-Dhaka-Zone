package com.dhaka.battlezone;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    public static MainActivity instance;
    GLSurfaceView gl;
    HudView hud;
    FrameLayout root, layer;
    Menus menus;
    final Handler h = new Handler(Looper.getMainLooper());
    boolean waitingStart = false;
    boolean errShown = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Cfg.load(this);
        Sfx.init(this);
        Game.faceBmp = BitmapFactory.decodeResource(getResources(), R.drawable.face);
        root = new FrameLayout(this);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        gl.setRenderer(new Renderer());
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        applyQuality();
        root.addView(gl, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        hud = new HudView(this);
        hud.setVisibility(View.GONE);
        root.addView(hud, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        layer = new FrameLayout(this);
        root.addView(layer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        menus = new Menus(this, layer);
        setContentView(root);
        Game.onFinish = new Runnable() {
            public void run() { runOnUiThread(new Runnable() { public void run() { menus.result(); } }); }
        };
        menus.home();
        h.postDelayed(poll, 100);
    }

    final Runnable poll = new Runnable() {
        public void run() {
            if (waitingStart && !Game.loading) {
                waitingStart = false;
                if (Game.state == Game.PLAY) {
                    layer.removeAllViews();
                    layer.setBackgroundColor(0);
                    layer.setClickable(false);
                    setHud(true);
                } else menus.home();
            }
            if (Game.glError != null && !errShown) {
                errShown = true;
                new AlertDialog.Builder(MainActivity.this).setTitle("Graphics error - please screenshot this")
                    .setMessage(Game.glError).setPositiveButton("OK", null).show();
            }
            h.postDelayed(this, 100);
        }
    };

    /** Lower render resolution on Low / Medium quality: big speed-up on weaker phones. */
    void applyQuality() {
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float sc = Cfg.quality == 0 ? 0.6f : (Cfg.quality == 1 ? 0.8f : 1.0f);
            int w = Math.max(dm.widthPixels, dm.heightPixels), h = Math.min(dm.widthPixels, dm.heightPixels);
            gl.getHolder().setFixedSize((int) (w * sc), (int) (h * sc));
        } catch (Throwable t) { }
    }

    void setHud(boolean on) {
        hud.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) hud.postInvalidate();
    }

    void startGame(int mode, int map) {
        Input.clear();
        layer.setBackgroundColor(0);
        Game.loading = true;
        waitingStart = true;
        Game.state = Game.MENU;
        menus.loading();
        Game.pendingMap = map;
        Game.pendingMode = mode;
    }

    void showPause() {
        if (Game.state != Game.PLAY) return;
        Game.paused = true;
        Input.clear();
        menus.pause();
    }

    void resumeGame() {
        layer.removeAllViews();
        layer.setBackgroundColor(0);
        layer.setClickable(false);
        Input.clear();
        Game.paused = false;
        setHud(true);
    }

    void leaveMatch() {
        Game.paused = false;
        Game.state = Game.MENU;
        Game.world = Game.menuWorld;
        Input.clear();
        layer.setBackgroundColor(0);
        menus.home();
    }

    void toLobby() {
        Game.state = Game.MENU;
        Game.world = Game.menuWorld;
        layer.setBackgroundColor(0);
        menus.home();
    }

    @Override
    public void onBackPressed() {
        if (Game.state == Game.PLAY) {
            if (Game.paused) resumeGame(); else showPause();
        } else if (waitingStart) {
            return;
        } else if (layer.getChildCount() > 0) {
            menus.home();
        } else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gl.onPause();
        if (Game.state == Game.PLAY && !Game.paused) showPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gl.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) onResume2();
    }

    void onResume2() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
}
