package com.dhaka.battlezone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;
import java.util.Random;

/** Static level geometry: render mesh (chunked), collision boxes (grid), minimap, spawn/loot points. */
public class World {
    public static class Box { public float x0, y0, z0, x1, y1, z1; }

    public static final float CS = 16f;
    public static final float CH = 128f;
    public static final float STEP = 0.55f;

    public int kind;           // 0 = Dhaka battle royale, 1 Gulistan, 2 Mirpur, 3 Lalbagh
    public float size;
    public final ArrayList<Box> solids = new ArrayList<>();
    @SuppressWarnings("unchecked")
    ArrayList<Box>[] grid;
    int gn;

    public float[][] cv;       // vertex data per chunk (last index = always drawn)
    public int[] cvn;
    public int chunksN;
    public int[] vbo;          // GL buffer ids, owned by renderer

    public final ArrayList<float[]> loot = new ArrayList<>();    // x, z, tier
    public final ArrayList<float[]> spawns = new ArrayList<>();  // x, z, team
    public final ArrayList<float[]> rects = new ArrayList<>();
    public final ArrayList<Integer> rcol = new ArrayList<>();
    public final ArrayList<Vehicle> traffic = new ArrayList<>();
    public int baseColor = 0xFF8C8672;
    public float trainPos, trainDir = 1, trainX, trainY = 11f, trainMin, trainMax;
    public boolean hasTrain;
    public Random rnd;
    public float[] sv = new float[12 * 6 * 64]; public int svn;     // shop signs / billboards (textured quads)
    public float[] shv = new float[12 * 6 * 64]; public int shvn;   // soft ground shadows
    public int signVbo, shadowVbo;

    @SuppressWarnings("unchecked")
    public World(int kind, float size) {
        this.kind = kind;
        this.size = size;
        gn = (int) (size / CS) + 2;
        grid = new ArrayList[gn * gn];
        chunksN = (int) Math.ceil(size / CH) + 1;
        cv = new float[chunksN * chunksN + 1][];
        cvn = new int[chunksN * chunksN + 1];
        rnd = new Random(1971 + kind);
    }

    public float rf(double a, double b) { return (float) (a + rnd.nextFloat() * (b - a)); }

    // ------------------------------------------------------------------ geometry
    int ci(float v) {
        int c = (int) (v / CS);
        if (c < 0) c = 0;
        if (c >= gn) c = gn - 1;
        return c;
    }

    int chunkOf(float x0, float z0, float x1, float z1) {
        if (x1 - x0 > 100 || z1 - z0 > 100) return chunksN * chunksN;
        int cx = (int) (((x0 + x1) * 0.5f) / CH), cz = (int) (((z0 + z1) * 0.5f) / CH);
        if (cx < 0) cx = 0; if (cx >= chunksN) cx = chunksN - 1;
        if (cz < 0) cz = 0; if (cz >= chunksN) cz = chunksN - 1;
        return cz * chunksN + cx;
    }

    void vert(int ch, float x, float y, float z, float nx, float ny, float nz, float r, float g, float b, float m) {
        float[] a = cv[ch];
        int n = cvn[ch];
        if (a == null) { a = new float[12 * 36 * 32]; cv[ch] = a; }
        if (n + 12 > a.length) { a = java.util.Arrays.copyOf(a, a.length * 2); cv[ch] = a; }
        a[n++] = x; a[n++] = y; a[n++] = z;
        a[n++] = nx; a[n++] = ny; a[n++] = nz;
        a[n++] = r; a[n++] = g; a[n++] = b;
        a[n++] = m; a[n++] = 0; a[n++] = 0;
        cvn[ch] = n;
    }

    void quad(int ch, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz,
              float dx, float dy, float dz, float nx, float ny, float nz, float r, float g, float b, float m) {
        vert(ch, ax, ay, az, nx, ny, nz, r, g, b, m);
        vert(ch, bx, by, bz, nx, ny, nz, r, g, b, m);
        vert(ch, cx, cy, cz, nx, ny, nz, r, g, b, m);
        vert(ch, ax, ay, az, nx, ny, nz, r, g, b, m);
        vert(ch, cx, cy, cz, nx, ny, nz, r, g, b, m);
        vert(ch, dx, dy, dz, nx, ny, nz, r, g, b, m);
    }

    /** Add a box to the render mesh and (optionally) the collision grid. */
    public void box(double X0, double Y0, double Z0, double X1, double Y1, double Z1,
                    double R, double G, double B, int mat, boolean solid) {
        float x0 = (float) Math.min(X0, X1), x1 = (float) Math.max(X0, X1);
        float y0 = (float) Math.min(Y0, Y1), y1 = (float) Math.max(Y0, Y1);
        float z0 = (float) Math.min(Z0, Z1), z1 = (float) Math.max(Z0, Z1);
        float v = mat == 3 ? 1f : 0.95f + rnd.nextFloat() * 0.1f;
        float r = (float) R * v, g = (float) G * v, b = (float) B * v;
        float m = mat;
        int ch = chunkOf(x0, z0, x1, z1);
        quad(ch, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, 0, 1, 0, r, g, b, m);
        quad(ch, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, 0, 0, 1, r, g, b, m);
        quad(ch, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0, 0, -1, r, g, b, m);
        quad(ch, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1, 0, 0, r, g, b, m);
        quad(ch, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, -1, 0, 0, r, g, b, m);
        if (y0 > 0.3f) quad(ch, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, r * .6f, g * .6f, b * .6f, m);
        if (solid) addSolid(x0, y0, z0, x1, y1, z1);
    }

    void addSolid(float x0, float y0, float z0, float x1, float y1, float z1) {
        Box bx = new Box();
        bx.x0 = x0; bx.y0 = y0; bx.z0 = z0; bx.x1 = x1; bx.y1 = y1; bx.z1 = z1;
        solids.add(bx);
        int cx0 = ci(x0), cx1 = ci(x1), cz0 = ci(z0), cz1 = ci(z1);
        for (int cz = cz0; cz <= cz1; cz++)
            for (int cx = cx0; cx <= cx1; cx++) {
                int k = cz * gn + cx;
                if (grid[k] == null) grid[k] = new ArrayList<>();
                grid[k].add(bx);
            }
    }

    /** Collision only (no visible geometry). */
    public void solidOnly(double X0, double Y0, double Z0, double X1, double Y1, double Z1) {
        addSolid((float) Math.min(X0, X1), (float) Math.min(Y0, Y1), (float) Math.min(Z0, Z1),
                (float) Math.max(X0, X1), (float) Math.max(Y0, Y1), (float) Math.max(Z0, Z1));
    }

    static float[] grow(float[] a, int need) {
        return need > a.length ? java.util.Arrays.copyOf(a, Math.max(need, a.length * 2)) : a;
    }

    void qv(boolean sign, float x, float y, float z, float nx, float ny, float nz, float m, float u, float v) {
        if (sign) {
            sv = grow(sv, svn + 12);
            float[] a = sv; int n = svn;
            a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = nx; a[n++] = ny; a[n++] = nz;
            a[n++] = 1; a[n++] = 1; a[n++] = 1; a[n++] = m; a[n++] = u; a[n++] = v;
            svn = n;
        } else {
            shv = grow(shv, shvn + 12);
            float[] a = shv; int n = shvn;
            a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = nx; a[n++] = ny; a[n++] = nz;
            a[n++] = 0; a[n++] = 0; a[n++] = 0; a[n++] = m; a[n++] = u; a[n++] = v;
            shvn = n;
        }
    }

    /** Soft drop-shadow on the ground for a building footprint of the given height. */
    public void shadow(double X0, double Z0, double X1, double Z1, double h) {
        float m = Math.min((float) h, 10f) * 0.5f;
        float x0 = (float) X0 - 0.9f - m * 0.9f, z0 = (float) Z0 - 0.9f - m * 0.8f, x1 = (float) X1 + 0.9f, z1 = (float) Z1 + 0.9f;
        float y = 0.095f;
        qv(false, x0, y, z0, 0, 1, 0, 6, 0, 0); qv(false, x1, y, z0, 0, 1, 0, 6, 1, 0); qv(false, x1, y, z1, 0, 1, 0, 6, 1, 1);
        qv(false, x0, y, z0, 0, 1, 0, 6, 0, 0); qv(false, x1, y, z1, 0, 1, 0, 6, 1, 1); qv(false, x0, y, z1, 0, 1, 0, 6, 0, 1);
    }

    /** Vertical sign quad. face 0:+Z 1:-Z 2:+X 3:-X ; a0..a1 along the wall ; fixed = wall coordinate. idx = atlas cell 0..15 */
    public void addSign(int face, double A0, double A1, double Y0, double Y1, double FIXED, int idx) {
        float a0 = (float) A0, a1 = (float) A1, y0 = (float) Y0, y1 = (float) Y1, fx = (float) FIXED;
        float cu = (idx % 4) * 0.25f, cv = (idx / 4) * 0.25f;
        float nx = 0, nz = 0;
        if (face == 0) nz = 1; else if (face == 1) nz = -1; else if (face == 2) nx = 1; else nx = -1;
        float[] us = new float[2];
        boolean rev = (face == 1 || face == 2);
        us[0] = rev ? cu + 0.25f : cu; us[1] = rev ? cu : cu + 0.25f;
        float vt = cv, vb = cv + 0.25f;
        float[][] p = new float[4][];
        if (face < 2) { p[0] = new float[]{a0, y0, fx}; p[1] = new float[]{a1, y0, fx}; p[2] = new float[]{a1, y1, fx}; p[3] = new float[]{a0, y1, fx}; }
        else { p[0] = new float[]{fx, y0, a0}; p[1] = new float[]{fx, y0, a1}; p[2] = new float[]{fx, y1, a1}; p[3] = new float[]{fx, y1, a0}; }
        float[][] uv = {{us[0], vb}, {us[1], vb}, {us[1], vt}, {us[0], vt}};
        int[] order = {0, 1, 2, 0, 2, 3};
        for (int k : order) qv(true, p[k][0], p[k][1], p[k][2], nx, 0, nz, 7, uv[k][0], uv[k][1]);
    }

    /** Low-poly leafy blob (trees, bushes). */
    public void blob(double cx, double cy, double cz, double rx, double ry, double rz, double r, double g, double b, int mat) {
        int seg = 7, rings = 4;
        int ch = chunkOf((float) (cx - rx), (float) (cz - rz), (float) (cx + rx), (float) (cz + rz));
        float jit = 0.9f + rnd.nextFloat() * 0.2f;
        float cr = (float) r * jit, cg = (float) g * jit, cb = (float) b * jit;
        for (int i = 0; i < rings; i++) {
            double t0 = Math.PI * i / rings, t1 = Math.PI * (i + 1) / rings;
            for (int j = 0; j < seg; j++) {
                double p0 = 2 * Math.PI * j / seg, p1 = 2 * Math.PI * (j + 1) / seg;
                float[][] q = {dirv(t0, p0), dirv(t0, p1), dirv(t1, p1), dirv(t1, p0)};
                int[] o = {0, 1, 2, 0, 2, 3};
                for (int k : o) {
                    float[] d = q[k];
                    vert(ch, (float) cx + d[0] * (float) rx, (float) cy + d[1] * (float) ry, (float) cz + d[2] * (float) rz, d[0], d[1], d[2], cr, cg, cb, mat);
                }
            }
        }
    }

    static float[] dirv(double th, double ph) {
        return new float[]{(float) (Math.sin(th) * Math.cos(ph)), (float) Math.cos(th), (float) (Math.sin(th) * Math.sin(ph))};
    }

    public void rect(double x0, double z0, double x1, double z1, int color) {
        rects.add(new float[]{(float) x0, (float) z0, (float) x1, (float) z1});
        rcol.add(color);
    }

    // ------------------------------------------------------------------ collision
    public boolean blocked(float x, float z, float r, float y, float h) {
        int cx0 = ci(x - r), cx1 = ci(x + r), cz0 = ci(z - r), cz1 = ci(z + r);
        for (int cz = cz0; cz <= cz1; cz++)
            for (int cx = cx0; cx <= cx1; cx++) {
                ArrayList<Box> l = grid[cz * gn + cx];
                if (l == null) continue;
                for (int k = 0; k < l.size(); k++) {
                    Box b = l.get(k);
                    if (b.y1 <= y + STEP || b.y0 >= y + h) continue;
                    float px = x < b.x0 ? b.x0 : (x > b.x1 ? b.x1 : x);
                    float pz = z < b.z0 ? b.z0 : (z > b.z1 ? b.z1 : z);
                    float dx = x - px, dz = z - pz;
                    if (dx * dx + dz * dz < r * r) return true;
                }
            }
        return false;
    }

    public float groundAt(float x, float z, float r, float y) {
        float best = 0f;
        int cx0 = ci(x - r), cx1 = ci(x + r), cz0 = ci(z - r), cz1 = ci(z + r);
        for (int cz = cz0; cz <= cz1; cz++)
            for (int cx = cx0; cx <= cx1; cx++) {
                ArrayList<Box> l = grid[cz * gn + cx];
                if (l == null) continue;
                for (int k = 0; k < l.size(); k++) {
                    Box b = l.get(k);
                    if (b.y1 > y + STEP || b.y1 <= best) continue;
                    float px = x < b.x0 ? b.x0 : (x > b.x1 ? b.x1 : x);
                    float pz = z < b.z0 ? b.z0 : (z > b.z1 ? b.z1 : z);
                    float dx = x - px, dz = z - pz;
                    if (dx * dx + dz * dz < r * r) best = b.y1;
                }
            }
        return best;
    }

    /** First solid hit along segment, as fraction 0..1 (1 = no hit). */
    public float ray(float ax, float ay, float az, float bx, float by, float bz) {
        float best = 1f;
        if (by < 0 && ay >= 0) { float t = ay / (ay - by); if (t < best) best = t; }
        int cx0 = ci(Math.min(ax, bx)), cx1 = ci(Math.max(ax, bx)), cz0 = ci(Math.min(az, bz)), cz1 = ci(Math.max(az, bz));
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        for (int cz = cz0; cz <= cz1; cz++)
            for (int cx = cx0; cx <= cx1; cx++) {
                ArrayList<Box> l = grid[cz * gn + cx];
                if (l == null) continue;
                for (int k = 0; k < l.size(); k++) {
                    Box b = l.get(k);
                    float tmin = 0, tmax = best;
                    if (Math.abs(dx) < 1e-6f) { if (ax < b.x0 || ax > b.x1) continue; }
                    else {
                        float t1 = (b.x0 - ax) / dx, t2 = (b.x1 - ax) / dx;
                        if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
                        if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
                        if (tmin > tmax) continue;
                    }
                    if (Math.abs(dy) < 1e-6f) { if (ay < b.y0 || ay > b.y1) continue; }
                    else {
                        float t1 = (b.y0 - ay) / dy, t2 = (b.y1 - ay) / dy;
                        if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
                        if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
                        if (tmin > tmax) continue;
                    }
                    if (Math.abs(dz) < 1e-6f) { if (az < b.z0 || az > b.z1) continue; }
                    else {
                        float t1 = (b.z0 - az) / dz, t2 = (b.z1 - az) / dz;
                        if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
                        if (t1 > tmin) tmin = t1; if (t2 < tmax) tmax = t2;
                        if (tmin > tmax) continue;
                    }
                    if (tmin < best) best = tmin;
                }
            }
        return best;
    }

    // ------------------------------------------------------------------ water
    public float riverZ(float x) {
        return 548f + 20f * (float) Math.sin(x / 85f) + 8f * (float) Math.sin(x / 29f);
    }

    static boolean ell(float x, float z, float cx, float cz, float a, float b) {
        float dx = (x - cx) / a, dz = (z - cz) / b;
        return dx * dx + dz * dz < 1f;
    }

    public boolean water(float x, float z) {
        if (kind != 0) return false;
        return z > riverZ(x) || ell(x, z, 470, 190, 90, 38) || ell(x, z, 190, 190, 30, 16);
    }

    // ------------------------------------------------------------------ minimap
    public Bitmap renderMinimap(int px) {
        Bitmap bm = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        c.drawColor(baseColor);
        Paint p = new Paint();
        float s = px / size;
        for (int i = 0; i < rects.size(); i++) {
            float[] r = rects.get(i);
            p.setColor(rcol.get(i));
            c.drawRect(r[0] * s, r[1] * s, r[2] * s, r[3] * s, p);
        }
        return bm;
    }
}
