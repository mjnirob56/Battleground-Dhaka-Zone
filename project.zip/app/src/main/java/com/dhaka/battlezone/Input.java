package com.dhaka.battlezone;

/** Shared touch input state (written by the UI thread, read by the game thread). */
public class Input {
    public static volatile float moveX, moveY;
    public static volatile boolean fire, fire2;
    public static volatile boolean evJump, evReload, evCrouch, evProne, evGren, evPick, evAds;
    public static volatile int evSlot = -1, evHeal = -1;
    static float lookX, lookY;

    public static synchronized void addLook(float dx, float dy) { lookX += dx; lookY += dy; }

    public static synchronized float[] takeLook() {
        float[] r = {lookX, lookY};
        lookX = 0; lookY = 0;
        return r;
    }

    public static void clear() {
        moveX = 0; moveY = 0; fire = false; fire2 = false;
        evJump = evReload = evCrouch = evProne = evGren = evPick = evAds = false;
        evSlot = -1; evHeal = -1;
        takeLook();
    }
}
