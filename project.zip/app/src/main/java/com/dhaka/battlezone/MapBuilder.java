package com.dhaka.battlezone;

/** Procedural level generators: Dhaka battle royale map + three TDM arenas. */
final class MapBuilder {
    static final double[][] OLD = {{.82, .74, .60}, {.75, .62, .50}, {.70, .55, .45}, {.65, .72, .70}, {.85, .70, .65}, {.62, .55, .50}, {.80, .80, .72}};
    static final double[][] MID = {{.72, .72, .70}, {.60, .64, .70}, {.78, .75, .68}, {.55, .55, .58}, {.85, .85, .82}};
    static final double[][] RES = {{.90, .85, .70}, {.80, .88, .80}, {.88, .78, .78}, {.75, .82, .90}};
    static final double[] ASPH = {.20, .20, .21};

    private MapBuilder() { }

    // =============================================================== helpers
    static void wall(World w, double x0, double z0, double x1, double z1, double h, double[] c, boolean door, int out) {
        if (!door) { w.box(x0, 0, z0, x1, h, z1, c[0], c[1], c[2], 1, true); return; }
        boolean alongX = (x1 - x0) > (z1 - z0);
        double len = alongX ? (x1 - x0) : (z1 - z0);
        double dw = 1.4, mid = len * 0.5 + w.rf(-len * 0.2, len * 0.2);
        int idx = w.rnd.nextInt(16);
        if (alongX) {
            w.box(x0, 0, z0, x0 + mid - dw, h, z1, c[0], c[1], c[2], 1, true);
            w.box(x0 + mid + dw, 0, z0, x1, h, z1, c[0], c[1], c[2], 1, true);
            w.box(x0 + mid - dw, 2.5, z0, x0 + mid + dw, h, z1, c[0], c[1], c[2], 1, true);
            if (h >= 5) w.addSign(out, x0 + mid - 1.7, x0 + mid + 1.7, 2.65, 3.55, out == 0 ? z1 + 0.03 : z0 - 0.03, idx);
        } else {
            w.box(x0, 0, z0, x1, h, z0 + mid - dw, c[0], c[1], c[2], 1, true);
            w.box(x0, 0, z0 + mid + dw, x1, h, z1, c[0], c[1], c[2], 1, true);
            w.box(x0, 2.5, z0 + mid - dw, x1, h, z0 + mid + dw, c[0], c[1], c[2], 1, true);
            if (h >= 5) w.addSign(out, z0 + mid - 1.7, z0 + mid + 1.7, 2.65, 3.55, out == 2 ? x1 + 0.03 : x0 - 0.03, idx);
        }
    }

    /** Enterable building. door: 0 south(+z) 1 north 2 east 3 west. */
    static void shell(World w, double x0, double z0, double x1, double z1, double h, double[] c, int door, int tier, int loots) {
        double t = 0.5;
        wall(w, x0, z0, x1, z0 + t, h, c, door == 1, 1);
        wall(w, x0, z1 - t, x1, z1, h, c, door == 0, 0);
        wall(w, x0, z0 + t, x0 + t, z1 - t, h, c, door == 3, 3);
        wall(w, x1 - t, z0 + t, x1, z1 - t, h, c, door == 2, 2);
        w.shadow(x0, z0, x1, z1, h);
        w.box(x0, h, z0, x1, h + 0.5, z1, c[0] * .6, c[1] * .6, c[2] * .6, 0, true);
        double cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
        if (w.rnd.nextFloat() < 0.6f && (x1 - x0) > 7 && (z1 - z0) > 7) w.box(cx - 0.5 + w.rf(-2, 2), 0, cz - 0.5 + w.rf(-2, 2), cx + 0.5, 1.0, cz + 0.5, .5, .38, .2, 0, true);
        for (int n = 0; n < loots; n++)
            w.loot.add(new float[]{(float) w.rf(x0 + 1.5, x1 - 1.5), (float) w.rf(z0 + 1.5, z1 - 1.5), tier});
        w.rect(x0, z0, x1, z1, 0xFFB9B4A6);
    }

    static void solidB(World w, double x0, double z0, double x1, double z1, double h, double[] c, int mat) {
        w.box(x0, 0, z0, x1, h, z1, c[0], c[1], c[2], mat, true);
        w.shadow(x0, z0, x1, z1, h);
        double cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
        if (h > 8 && mat == 1) {
            if (w.rnd.nextFloat() < 0.5f) {
                w.box(cx - 1, h, cz - 1, cx + 1, h + 1.7, cz + 1, .55, .55, .52, 0, false);
                w.box(cx - .9, h + 1.7, cz - .9, cx + .9, h + 1.95, cz + .9, .4, .4, .42, 0, false);
            }
            if (w.rnd.nextFloat() < 0.45f) {
                double lvl = 3.2 * (1 + w.rnd.nextInt(Math.max(1, (int) (h / 3.2) - 1)));
                double bx = x0 + 1.5 + w.rf(0, Math.max(0.1, (x1 - x0) - 6));
                w.box(bx, lvl, z1, bx + 3, lvl + 0.18, z1 + 1.1, .6, .58, .55, 0, false);
                w.box(bx, lvl + 0.18, z1 + 1.0, bx + 3, lvl + 1.1, z1 + 1.06, .35, .35, .38, 0, false);
            }
            if (w.rnd.nextFloat() < 0.35f) {
                double lvl = 3.2 * (1 + w.rnd.nextInt(Math.max(1, (int) (h / 3.2) - 1)));
                double bz = z0 + 1.5 + w.rf(0, Math.max(0.1, (z1 - z0) - 6));
                w.box(x0 - 1.1, lvl, bz, x0, lvl + 0.18, bz + 3, .6, .58, .55, 0, false);
                w.box(x0 - 1.06, lvl + 0.18, bz, x0 - 1.0, lvl + 1.1, bz + 3, .35, .35, .38, 0, false);
            }
        }
        if (w.rnd.nextFloat() < 0.6f && (x1 - x0) > 8) {
            double sx = cx + w.rf(-1, 1);
            w.addSign(0, sx - 2.2, sx + 2.2, 2.7, 3.7, z1 + 0.03, w.rnd.nextInt(16));
        }
        if (mat == 2 && h > 25) {
            w.addSign(0, cx - 5, cx + 5, h - 8, h - 3, z1 + 0.03, w.rnd.nextInt(16));
        }
        w.rect(x0, z0, x1, z1, mat == 2 ? 0xFF7C8A96 : 0xFF8E897E);
    }

    static void tree(World w, double x, double z) {
        w.box(x - .2, 0, z - .2, x + .2, 3.2, z + .2, .4, .28, .16, 0, true);
        double s = w.rf(1.6, 2.4);
        w.blob(x, 3.5 + s * 0.55, z, s * 1.1, s * 0.95, s * 1.1, .22 + w.rf(0, .1), .42 + w.rf(0, .12), .17, 10);
    }

    static void garbage(World w, double x, double z) {
        int n = 3 + w.rnd.nextInt(3);
        for (int i = 0; i < n; i++) {
            double a = w.rf(-1, 1), b = w.rf(-1, 1), s = w.rf(.3, .8);
            w.box(x + a, 0, z + b, x + a + s, w.rf(.2, .6), z + b + s, .3 + w.rf(0, .4), .3 + w.rf(0, .3), .25 + w.rf(0, .2), 0, false);
        }
    }

    static void pothole(World w, double x, double z) {
        double s = w.rf(.6, 1.3);
        w.box(x - s, 0.06, z - s, x + s, 0.08, z + s, .09, .09, .1, 0, false);
    }

    static void puddle(World w, double x, double z) {
        double a = w.rf(1, 2.5), b = w.rf(1, 2.5);
        w.box(x - a, 0.06, z - b, x + a, 0.085, z + b, .28, .33, .34, 3, false);
    }

    static void stall(World w, double x, double z) {
        w.box(x, 0, z, x + 2, 1, z + 1, .5, .35, .2, 0, true);
        double[] cols = {.9, .2, .2};
        w.box(x - .5, 2.2, z - .8, x + 2.5, 2.35, z + 1.8, .9 * w.rf(.6, 1), .3 + w.rf(0, .6), .2 + w.rf(0, .5), 0, false);
        w.box(x + .1, 0, z - .7, x + .4, 2.2, z - .4, .3, .3, .3, 0, false);
    }

    static void pole(World w, double x, double z) {
        w.box(x - .15, 0, z - .15, x + .15, 8, z + .15, .35, .3, .26, 0, true);
        w.box(x - .8, 7.3, z - .06, x + .8, 7.45, z + .06, .25, .25, .25, 0, false);
    }

    static void wireX(World w, double x0, double x1, double z) {
        w.box(x0, 7.4, z - .02, x1, 7.45, z + .02, .08, .08, .08, 0, false);
        w.box(x0, 7.25, z + .3, x1, 7.3, z + .34, .08, .08, .08, 0, false);
    }

    static void wireZ(World w, double x, double z0, double z1) {
        w.box(x - .02, 7.4, z0, x + .02, 7.45, z1, .08, .08, .08, 0, false);
        w.box(x + .3, 7.25, z0, x + .34, 7.3, z1, .08, .08, .08, 0, false);
    }

    /** Static vehicle baked into the level. axis 0 = faces along X, 1 = along Z. */
    static void vehicleStatic(World w, int type, double cx, double cz, int axis, int dir, float[] col) {
        int c, s; // rotation: x' = x*c + z*s ; z' = -x*s + z*c
        if (axis == 0) { c = dir > 0 ? 1 : -1; s = 0; } else { c = 0; s = dir > 0 ? -1 : 1; }
        float[][] parts = VehModel.PARTS[type];
        float[] out = new float[3];
        for (float[] p : parts) {
            double lx = p[0], lz = p[2];
            double wx = lx * c + lz * s, wz = -lx * s + lz * c;
            double hx = (Math.abs(p[3] * c) + Math.abs(p[5] * s)) / 2, hz = (Math.abs(p[3] * s) + Math.abs(p[5] * c)) / 2;
            VehModel.color((int) p[6], col[0], col[1], col[2], out);
            double y0 = p[1] - p[4] / 2, y1 = p[1] + p[4] / 2;
            w.box(cx + wx - hx, y0, cz + wz - hz, cx + wx + hx, y1, cz + wz + hz, out[0], out[1], out[2], 0, false);
        }
        double hx = axis == 0 ? VehModel.LEN[type] / 2 : VehModel.WID[type] / 2;
        double hz = axis == 0 ? VehModel.WID[type] / 2 : VehModel.LEN[type] / 2;
        w.solidOnly(cx - hx, 0, cz - hz, cx + hx, VehModel.HGT[type], cz + hz);
    }

    static void jam(World w, int axis, double line, double from, double count, int maxType) {
        double p = from;
        for (int i = 0; i < count; i++) {
            int type = w.rnd.nextInt(maxType + 1);
            double len = VehModel.LEN[type];
            double lane = line + (w.rnd.nextBoolean() ? 2.0 : -2.0);
            float[] col = VehModel.bodyColor(type, w.rnd);
            if (axis == 0) vehicleStatic(w, type, p + len / 2, lane, 0, w.rnd.nextBoolean() ? 1 : -1, col);
            else vehicleStatic(w, type, lane, p + len / 2, 1, w.rnd.nextBoolean() ? 1 : -1, col);
            p += len + w.rf(.4, 1.2);
        }
    }

    static void addTraffic(World w, int type, int axis, double lane, double pos, int dir, double minP, double maxP, double speedMul) {
        Vehicle v = new Vehicle();
        v.type = type; v.axis = axis; v.lane = (float) lane; v.pos = (float) pos; v.dir = dir;
        v.minP = (float) minP; v.maxP = (float) maxP;
        v.speed = (float) (VehModel.SPEED[type] * speedMul * w.rf(.85, 1.15));
        v.hx = (axis == 0 ? VehModel.LEN[type] : VehModel.WID[type]) / 2;
        v.hz = (axis == 0 ? VehModel.WID[type] : VehModel.LEN[type]) / 2;
        v.h = VehModel.HGT[type];
        float[] col = VehModel.bodyColor(type, w.rnd);
        v.cr = col[0]; v.cg = col[1]; v.cb = col[2];
        w.traffic.add(v);
    }

    static void fence(World w, double x0, double z0, double x1, double z1, double h, int gate) {
        double t = .4, g = 2.0;
        double cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
        double[] c = {.78, .72, .62};
        // north (z0), south (z1), west (x0), east (x1); gate: 0 south 1 north 2 east 3 west
        if (gate == 1) { w.box(x0, 0, z0, cx - g, h, z0 + t, c[0], c[1], c[2], 0, true); w.box(cx + g, 0, z0, x1, h, z0 + t, c[0], c[1], c[2], 0, true); }
        else w.box(x0, 0, z0, x1, h, z0 + t, c[0], c[1], c[2], 0, true);
        if (gate == 0) { w.box(x0, 0, z1 - t, cx - g, h, z1, c[0], c[1], c[2], 0, true); w.box(cx + g, 0, z1 - t, x1, h, z1, c[0], c[1], c[2], 0, true); }
        else w.box(x0, 0, z1 - t, x1, h, z1, c[0], c[1], c[2], 0, true);
        if (gate == 3) { w.box(x0, 0, z0 + t, x0 + t, h, cz - g, c[0], c[1], c[2], 0, true); w.box(x0, 0, cz + g, x0 + t, h, z1 - t, c[0], c[1], c[2], 0, true); }
        else w.box(x0, 0, z0 + t, x0 + t, h, z1 - t, c[0], c[1], c[2], 0, true);
        if (gate == 2) { w.box(x1 - t, 0, z0 + t, x1, h, cz - g, c[0], c[1], c[2], 0, true); w.box(x1 - t, 0, cz + g, x1, h, z1 - t, c[0], c[1], c[2], 0, true); }
        else w.box(x1 - t, 0, z0 + t, x1, h, z1 - t, c[0], c[1], c[2], 0, true);
    }

    static void green(World w, double x0, double z0, double x1, double z1) {
        w.box(x0, 0, z0, x1, 0.09, z1, .27, .46, .22, 9, false);
        w.rect(x0, z0, x1, z1, 0xFF4F8A3F);
    }

    static void waterEllipse(World w, double cx, double cz, double a, double b) {
        for (double z0 = cz - b; z0 < cz + b; z0 += 4) {
            double dz = (z0 + 2 - cz) / b;
            double hw = a * Math.sqrt(Math.max(0.0, 1 - dz * dz));
            if (hw < 1) continue;
            w.box(cx - hw, -0.3, z0, cx + hw, 0.08, z0 + 4, .17, .33, .37, 3, false);
            w.rect(cx - hw, z0, cx + hw, z0 + 4, 0xFF2B6C80);
        }
    }

    static void stairsX(World w, double xTop, double dirSign, double z0, double z1, double topH) {
        int n = (int) Math.ceil(topH / 0.46);
        double stepH = topH / n;
        for (int k = 0; k < n; k++) {
            double xa = xTop + dirSign * 0.9 * k, xb = xTop + dirSign * 0.9 * (k + 1);
            w.box(Math.min(xa, xb), 0, z0, Math.max(xa, xb), stepH * (n - k), z1, .66, .64, .6, 0, true);
        }
    }

    static void flyoverX(World w, double x0, double x1, double z, double halfW) {
        double top = 6.5;
        w.box(x0, top - 0.8, z - halfW, x1, top, z + halfW, .62, .62, .64, 0, true);
        w.box(x0, top, z - halfW, x1, top + 0.9, z - halfW + 0.35, .55, .55, .58, 0, true);
        w.box(x0, top, z + halfW - 0.35, x1, top + 0.9, z + halfW, .55, .55, .58, 0, true);
        for (double x = x0 + 12; x < x1 - 6; x += 24) w.box(x - .7, 0, z - .7, x + .7, top - 0.8, z + .7, .6, .6, .62, 0, true);
        stairsX(w, x0, -1, z - halfW + 1, z + halfW - 1, top);
        stairsX(w, x1, 1, z - halfW + 1, z + halfW - 1, top);
        w.rect(x0, z - halfW, x1, z + halfW, 0xFF9A9AA0);
    }

    // =============================================================== BR: Dhaka
    static World dhaka() {
        World w = new World(0, 640);
        w.baseColor = 0xFF8C8672;
        w.box(-120, -1, -120, 760, 0, 760, .50, .47, .40, 8, false);
        river(w);
        roads(w);
        blocks(w);
        landmarks(w);
        clutter(w);
        trafficSetup(w);
        mrt(w);
        return w;
    }

    static void river(World w) {
        double[] piers = {150, 214, 278, 342, 406};
        for (double x = -60; x < 700; x += 8) {
            double rz = w.riverZ((float) (x + 4));
            w.box(x, -0.5, rz, x + 8, 0.08, 760, .17, .33, .37, 3, false);
            w.rect(x, rz, x + 8, 720, 0xFF2B6C80);
            boolean gap = false;
            for (double p : piers) if (x + 8 > p && x < p + 5) gap = true;
            if (!gap) w.box(x, 0, rz - 1.0, x + 8, 0.9, rz - 0.3, .6, .58, .52, 0, true);
        }
        for (double p : piers) {
            double rz = w.riverZ((float) (p + 2));
            w.box(p, 0, rz - 1, p + 5, 0.35, rz + 24, .45, .33, .2, 0, true);
        }
        // launches (Sadarghat)
        for (int k = 0; k < 4; k++) {
            double x = 156 + k * 64, rz = w.riverZ((float) (x + 17));
            double z = rz + 5;
            w.box(x, 0, z, x + 34, 2.8, z + 13, .12, .2, .35, 0, true);
            w.box(x + 1, 2.8, z + .8, x + 33, 5.6, z + 12.2, .92, .92, .9, 1, true);
            w.box(x + 4, 5.6, z + 1.5, x + 29, 8.2, z + 11.5, .9, .9, .88, 1, true);
            w.box(x + 12, 8.2, z + 4, x + 16, 10.6, z + 9, .8, .2, .2, 0, true);
            w.loot.add(new float[]{(float) (x + 6), (float) (rz + 0.5f), 1});
        }
    }

    static void roads(World w) {
        for (int i = 0; i <= 10; i++) {
            double x = i * 64, rw = (i == 2 || i == 5 || i == 8) ? 14 : 8;
            w.box(x - rw / 2, 0, 0, x + rw / 2, 0.06, 520, ASPH[0], ASPH[1], ASPH[2], 4, false);
            w.rect(x - rw / 2, 0, x + rw / 2, 520, 0xFF3A3A3C);
            if (rw > 10) for (double z = 2; z < 518; z += 12) w.box(x - .12, 0.06, z, x + .12, 0.075, z + 5, .85, .85, .8, 0, false);
            w.box(x + rw / 2, 0, 0, x + rw / 2 + 1.8, 0.14, 520, .62, .6, .57, 11, false);
            w.box(x - rw / 2 - 1.8, 0, 0, x - rw / 2, 0.14, 520, .62, .6, .57, 11, false);
        }
        for (int j = 0; j <= 8; j++) {
            double z = j * 64, rw = (j == 3 || j == 6) ? 14 : 8;
            w.box(0, 0, z - rw / 2, 640, 0.06, z + rw / 2, ASPH[0], ASPH[1], ASPH[2], 4, false);
            w.rect(0, z - rw / 2, 640, z + rw / 2, 0xFF3A3A3C);
            if (rw > 10) for (double x = 2; x < 638; x += 12) w.box(x, 0.06, z - .12, x + 5, 0.075, z + .12, .85, .85, .8, 0, false);
            w.box(0, 0, z + rw / 2, 640, 0.14, z + rw / 2 + 1.8, .62, .6, .57, 11, false);
            w.box(0, 0, z - rw / 2 - 1.8, 640, 0.14, z - rw / 2, .62, .6, .57, 11, false);
        }
    }

    static void blocks(World w) {
        boolean[][] used = new boolean[10][8];
        used[0][0] = used[1][0] = used[0][1] = used[1][1] = true;   // Mirpur stadium
        used[1][6] = used[2][6] = true;                                // Lalbagh fort
        used[4][4] = true;                                             // Baitul Mukarram
        used[5][7] = true;                                             // Ahsan Manzil
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 8; j++) {
                if (used[i][j]) continue;
                float cx = i * 64 + 32, cz = j * 64 + 32;
                if (w.water(cx, cz)) continue;
                if ((i == 2 || i == 3) && (j == 2 || j == 3)) { park(w, i, j); continue; }
                if (i >= 6 && i <= 7 && j >= 4 && j <= 5) { tower(w, i, j); continue; }
                if (i >= 8 && j <= 1) { villa(w, i, j); continue; }
                if (i == 1 && (j == 2 || j == 3)) { campus(w, i, j); continue; }
                if ((i <= 3 && j >= 4) || (i >= 4 && j >= 6)) { old(w, i, j); continue; }
                if (j <= 1 && (i == 3 || i == 4 || i == 2)) { res(w, i, j); continue; }
                if (i == 0 && (j == 2 || j == 3)) { res(w, i, j); continue; }
                mid(w, i, j);
            }
        }
    }

    static void old(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        for (int a = 0; a < 3; a++)
            for (int b = 0; b < 3; b++) {
                double x0 = bx + a * 17, z0 = bz + b * 17;
                if (w.water((float) (x0 + 7), (float) (z0 + 7))) continue;
                if (w.rnd.nextFloat() < 0.08f) { garbage(w, x0 + 7, z0 + 7); continue; }
                double[] c = OLD[w.rnd.nextInt(OLD.length)];
                double wd = w.rf(11, 14), dp = w.rf(11, 14);
                double ox = x0 + w.rf(0, 14 - wd), oz = z0 + w.rf(0, 14 - dp);
                if (w.rnd.nextFloat() < 0.45f) shell(w, ox, oz, ox + wd, oz + dp, w.rf(6, 9), c, w.rnd.nextInt(4), 1, 2);
                else solidB(w, ox, oz, ox + wd, oz + dp, w.rf(10, 19), c, 1);
            }
    }

    static void mid(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++) {
                double x0 = bx + a * 26, z0 = bz + b * 26;
                if (w.water((float) (x0 + 11), (float) (z0 + 11))) continue;
                double[] c = MID[w.rnd.nextInt(MID.length)];
                double wd = w.rf(16, 21), dp = w.rf(16, 21);
                if (w.rnd.nextFloat() < 0.4f) shell(w, x0, z0, x0 + wd, z0 + dp, w.rf(7, 10), c, w.rnd.nextInt(4), 1, 3);
                else solidB(w, x0, z0, x0 + wd, z0 + dp, w.rf(14, 28), c, 1);
            }
    }

    static void res(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++) {
                double x0 = bx + a * 26, z0 = bz + b * 26;
                double[] c = RES[w.rnd.nextInt(RES.length)];
                if (w.rnd.nextFloat() < 0.75f) shell(w, x0 + 2, z0 + 2, x0 + 2 + w.rf(14, 18), z0 + 2 + w.rf(12, 16), w.rf(7, 10), c, w.rnd.nextInt(4), 1, 3);
                else solidB(w, x0 + 2, z0 + 2, x0 + 18, z0 + 18, w.rf(10, 14), c, 1);
                tree(w, x0 + 21, z0 + 3);
            }
    }

    static void tower(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        w.box(bx, 0, bz, bx + 48, 0.05, bz + 48, .6, .6, .58, 0, false);
        double[] glass = {.45, .58, .66};
        double[] glass2 = {.6, .62, .66};
        solidB(w, bx + 2, bz + 2, bx + 22, bz + 24, w.rf(32, 58), glass, 2);
        solidB(w, bx + 26, bz + 22, bx + 46, bz + 44, w.rf(30, 50), glass2, 2);
        double[] bank = {.86, .82, .74};
        shell(w, bx + 4, bz + 30, bx + 22, bz + 44, 7, bank, 0, 2, 5);
        tree(w, bx + 30, bz + 6); tree(w, bx + 40, bz + 8);
    }

    static void villa(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++) {
                double x0 = bx + a * 26, z0 = bz + b * 26;
                green(w, x0, z0, x0 + 22, z0 + 22);
                fence(w, x0, z0, x0 + 22, z0 + 22, 2.2, w.rnd.nextInt(4));
                double[] c = RES[w.rnd.nextInt(RES.length)];
                shell(w, x0 + 5, z0 + 6, x0 + 17, z0 + 16, 7.5, c, w.rnd.nextInt(4), 2, 4);
                tree(w, x0 + 3, z0 + 18); tree(w, x0 + 19, z0 + 3);
            }
    }

    static void park(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        green(w, bx, bz, bx + 48, bz + 48);
        w.box(bx + 22, 0.09, bz, bx + 26, 0.11, bz + 48, .75, .72, .65, 0, false);
        w.box(bx, 0.09, bz + 22, bx + 48, 0.11, bz + 26, .75, .72, .65, 0, false);
        for (int k = 0; k < 14; k++) {
            double x = bx + w.rf(2, 46), z = bz + w.rf(2, 46);
            if (w.water((float) x, (float) z)) continue;
            tree(w, x, z);
        }
        double px = bx + w.rf(4, 36), pz = bz + w.rf(4, 36);
        if (!w.water((float) px, (float) pz)) shell(w, px, pz, px + 7, pz + 7, 3.6, new double[]{.85, .8, .7}, w.rnd.nextInt(4), 1, 2);
    }

    static void campus(World w, int i, int j) {
        double bx = i * 64 + 8, bz = j * 64 + 8;
        green(w, bx, bz, bx + 48, bz + 48);
        double[] brick = {.66, .32, .26};
        shell(w, bx + 6, bz + 8, bx + 42, bz + 22, 11, brick, 0, 2, 6);
        shell(w, bx + 8, bz + 30, bx + 24, bz + 42, 8, brick, 1, 1, 3);
        for (int k = 0; k < 6; k++) tree(w, bx + w.rf(2, 46), bz + w.rf(26, 46));
    }

    // =============================================================== landmarks
    static void landmarks(World w) {
        stadium(w);
        lalbagh(w);
        // Baitul Mukarram
        double[] white = {.92, .92, .88};
        w.box(264, 0, 264, 312, 0.05, 312, .75, .75, .72, 0, false);
        shell(w, 266, 266, 306, 306, 16, white, 0, 2, 8);
        for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) w.box(274 + a * 11, 0, 274 + b * 11, 275.5 + a * 11, 16, 275.5 + b * 11, .85, .85, .82, 0, true);
        w.box(263, 0, 263, 266, 26, 266, .88, .88, .85, 0, true);
        w.box(306, 0, 263, 309, 26, 266, .88, .88, .85, 0, true);
        w.box(263, 0, 306, 266, 26, 309, .88, .88, .85, 0, true);
        w.box(306, 0, 306, 309, 26, 309, .88, .88, .85, 0, true);
        // Ahsan Manzil
        double[] pink = {.92, .56, .6};
        green(w, 322, 450, 382, 510);
        shell(w, 332, 462, 366, 480, 11, pink, 0, 2, 6);
        w.box(343, 11.5, 466, 355, 14.5, 476, .92, .56, .6, 0, false);
        w.box(345, 14.5, 468, 353, 17, 474, .95, .95, .92, 0, false);
        w.box(341, 0, 480, 357, 0.5, 484, .85, .82, .78, 0, true);
        for (int k = 0; k < 6; k++) tree(w, 324 + w.rf(0, 56), 486 + w.rf(0, 20));
        // Sadarghat terminal
        shell(w, 228, 488, 280, 506, 9, new double[]{.7, .78, .84}, 0, 2, 6);
        // Gulistan flyover
        flyoverX(w, 208, 432, 320, 5);
        // Hatirjheel lake + causeway, Ramna lake
        waterEllipse(w, 470, 190, 90, 38);
        w.box(468, 0, 150, 472, 0.3, 232, .6, .58, .52, 0, true);
        waterEllipse(w, 190, 190, 30, 16);
        // Shapla Chattar roundabout
        w.box(444, 0, 316, 452, 1.0, 324, .8, .8, .78, 0, true);
        w.box(447, 1, 319, 449, 6, 321, .85, .85, .85, 0, true);
    }

    static void stadium(World w) {
        double[] c = {.72, .72, .70};
        green(w, 30, 40, 100, 90);
        w.box(62, 0.09, 52, 68, 0.12, 78, .75, .7, .5, 0, false);
        // outer ring with 4 gates
        w.box(14, 0, 20, 60, 12, 24, c[0], c[1], c[2], 0, true); w.box(68, 0, 20, 114, 12, 24, c[0], c[1], c[2], 0, true);
        w.box(14, 0, 104, 60, 12, 108, c[0], c[1], c[2], 0, true); w.box(68, 0, 104, 114, 12, 108, c[0], c[1], c[2], 0, true);
        w.box(14, 0, 24, 18, 12, 60, c[0], c[1], c[2], 0, true); w.box(14, 0, 68, 18, 12, 104, c[0], c[1], c[2], 0, true);
        w.box(110, 0, 24, 114, 12, 60, c[0], c[1], c[2], 0, true); w.box(110, 0, 68, 114, 12, 104, c[0], c[1], c[2], 0, true);
        for (int k = 0; k < 5; k++) {
            w.box(20, 0, 24 + 2 * k, 108, 2.5 - 0.5 * k, 26 + 2 * k, .55, .55, .6, 0, true);
            w.box(20, 0, 104 - 2 * (k + 1), 108, 2.5 - 0.5 * k, 104 - 2 * k, .55, .55, .6, 0, true);
        }
        double[][] lights = {{10, 16}, {118, 16}, {10, 112}, {118, 112}};
        for (double[] l : lights) {
            w.box(l[0] - .5, 0, l[1] - .5, l[0] + .5, 30, l[1] + .5, .6, .6, .62, 0, true);
            w.box(l[0] - 3, 30, l[1] - 1, l[0] + 3, 32, l[1] + 1, .95, .95, .8, 0, false);
        }
        shell(w, 44, 58, 52, 64, 2.8, new double[]{.8, .8, .78}, 2, 2, 2);
        shell(w, 76, 66, 84, 72, 2.8, new double[]{.8, .8, .78}, 3, 2, 2);
        w.loot.add(new float[]{64, 44, 2}); w.loot.add(new float[]{64, 86, 2});
        w.loot.add(new float[]{34, 66, 2}); w.loot.add(new float[]{96, 62, 2});
        w.loot.add(new float[]{64, 30, 2}); w.loot.add(new float[]{64, 98, 2});
        w.rect(14, 20, 114, 108, 0xFF9C9C98);
        w.rect(30, 40, 100, 90, 0xFF4F8A3F);
    }

    static void lalbagh(World w) {
        double[] brick = {.70, .42, .32};
        double x0 = 70, x1 = 186, z0 = 388, z1 = 444;
        green(w, x0, z0, x1, z1);
        w.box(x0, 0, z0, 120, 5, z0 + 2, brick[0], brick[1], brick[2], 0, true); w.box(136, 0, z0, x1, 5, z0 + 2, brick[0], brick[1], brick[2], 0, true);
        w.box(x0, 0, z1 - 2, 120, 5, z1, brick[0], brick[1], brick[2], 0, true); w.box(136, 0, z1 - 2, x1, 5, z1, brick[0], brick[1], brick[2], 0, true);
        w.box(x0, 0, z0 + 2, x0 + 2, 5, z1 - 2, brick[0], brick[1], brick[2], 0, true);
        w.box(x1 - 2, 0, z0 + 2, x1, 5, 410, brick[0], brick[1], brick[2], 0, true);
        w.box(x1 - 2, 0, 420, x1, 5, z1 - 2, brick[0], brick[1], brick[2], 0, true);
        double[][] b = {{x0 - 2, z0 - 2}, {x1 - 4, z0 - 2}, {x0 - 2, z1 - 4}, {x1 - 4, z1 - 4}};
        for (double[] p : b) w.box(p[0], 0, p[1], p[0] + 6, 8, p[1] + 6, .66, .4, .3, 0, true);
        w.rect(x0, z0, x1, z1, 0xFF8A6A50);
        shell(w, 152, 396, 172, 408, 6.5, new double[]{.93, .9, .8}, 0, 2, 5);
        w.box(154, 7, 398, 159, 10, 403, .95, .95, .9, 0, false); w.box(160, 7, 398, 165, 10, 403, .95, .95, .9, 0, false);
        w.box(166, 7, 398, 171, 10, 403, .95, .95, .9, 0, false);
        shell(w, 100, 410, 114, 424, 7.5, new double[]{.95, .93, .88}, 1, 2, 4);
        w.box(103, 8, 413, 111, 11, 421, .95, .95, .9, 0, false);
        shell(w, 80, 394, 104, 404, 6, new double[]{.88, .75, .55}, 0, 2, 4);
        w.box(138, -0.2, 392, 141, 0.07, 440, .17, .33, .37, 3, false);
        for (int k = 0; k < 10; k++) tree(w, w.rf(76, 180), w.rf(414, 440));
        w.loot.add(new float[]{125, 415, 2}); w.loot.add(new float[]{160, 430, 2});
    }

    // =============================================================== clutter, traffic, MRT
    static void clutter(World w) {
        // dirty roads
        for (int k = 0; k < 170; k++) {
            boolean vert = w.rnd.nextBoolean();
            if (vert) {
                double x = 64 * w.rnd.nextInt(11) + w.rf(-3, 3), z = w.rf(5, 515);
                int r = w.rnd.nextInt(3);
                if (r == 0) garbage(w, x + 2.5, z); else if (r == 1) pothole(w, x, z); else puddle(w, x, z);
            } else {
                double z = 64 * w.rnd.nextInt(9) + w.rf(-3, 3), x = w.rf(5, 635);
                int r = w.rnd.nextInt(3);
                if (r == 0) garbage(w, x, z + 2.5); else if (r == 1) pothole(w, x, z); else puddle(w, x, z);
            }
        }
        for (int k = 0; k < 40; k++) {
            double x = 64 * w.rnd.nextInt(11) + 5.2, z = w.rf(10, 510);
            if (w.rnd.nextBoolean()) stall(w, x, z);
        }
        // overhead wires in the old city
        for (int i = 0; i <= 4; i++) for (double z = 260; z < 500; z += 20) { pole(w, i * 64 + 5, z); wireZ(w, i * 64 + 5, z, z + 20); }
        for (int j = 4; j <= 8; j++) for (double x = 0; x < 300; x += 20) { pole(w, x, j * 64 + 5); wireX(w, x, x + 20, j * 64 + 5); }
        // traffic jams on side streets
        int[] xi = {1, 3, 4, 6, 7, 9};
        int[] zj = {1, 2, 4, 5, 7};
        for (int k = 0; k < 26; k++) {
            if (w.rnd.nextBoolean()) jam(w, 0, zj[w.rnd.nextInt(zj.length)] * 64, w.rf(10, 520), 3 + w.rnd.nextInt(4), 3);
            else jam(w, 1, xi[w.rnd.nextInt(xi.length)] * 64, w.rf(10, 400), 3 + w.rnd.nextInt(4), 3);
        }
        // Gulistan crossing is always stuck
        jam(w, 0, 320, 214, 8, 2);
        jam(w, 1, 320, 264, 5, 2);
    }

    static void trafficSetup(World w) {
        int[] axs = {128, 320, 512};
        for (int a : axs)
            for (int dir = -1; dir <= 1; dir += 2)
                for (int ln = 0; ln < 2; ln++) {
                    double lane = a + (dir > 0 ? 1 : -1) * (2.2 + ln * 3.2);
                    int n = ln == 0 ? 4 : 3;
                    for (int k = 0; k < n; k++) addTraffic(w, pickType(w, ln), 1, lane, 520.0 / n * k + w.rf(0, 20), dir, 0, 520, ln == 0 ? 1 : 0.7);
                }
        int[] azs = {192, 384};
        for (int a : azs)
            for (int dir = -1; dir <= 1; dir += 2)
                for (int ln = 0; ln < 2; ln++) {
                    double lane = a - (dir > 0 ? 1 : -1) * (2.2 + ln * 3.2);
                    int n = ln == 0 ? 6 : 4;
                    for (int k = 0; k < n; k++) addTraffic(w, pickType(w, ln), 0, lane, 640.0 / n * k + w.rf(0, 20), dir, 0, 640, ln == 0 ? 1 : 0.7);
                }
    }

    static int pickType(World w, int lane) {
        float r = w.rnd.nextFloat();
        if (lane == 1) return r < 0.5f ? 1 : (r < 0.8f ? 0 : 3);
        return r < 0.28f ? 2 : (r < 0.55f ? 0 : (r < 0.9f ? 3 : 4));
    }

    static void mrt(World w) {
        double x = 384;
        w.box(x - 3, 10.2, 0, x + 3, 11, 330, .75, .76, .78, 0, true);
        for (double z = 10; z < 330; z += 22) w.box(x - .8, 0, z, x + .8, 10.2, z + 1.6, .65, .65, .68, 0, true);
        w.box(x - 5, 14, 180, x + 5, 14.5, 232, .6, .62, .66, 0, false);
        w.rect(x - 2, 0, x + 2, 330, 0xFFB0B8C8);
        w.hasTrain = true; w.trainX = (float) x; w.trainMin = 20; w.trainMax = 310; w.trainPos = 40; w.trainDir = 1;
    }

    // =============================================================== TDM arenas
    static World tdm(int k) {
        World w = new World(k, 160);
        w.baseColor = 0xFF8C8672;
        w.box(-60, -1, -60, 220, 0, 220, .50, .47, .40, 8, false);
        double[] bc = {.55, .5, .45};
        w.box(-2, 0, -2, 162, 5, 0, bc[0], bc[1], bc[2], 1, true); w.box(-2, 0, 160, 162, 5, 162, bc[0], bc[1], bc[2], 1, true);
        w.box(-2, 0, 0, 0, 5, 160, bc[0], bc[1], bc[2], 1, true); w.box(160, 0, 0, 162, 5, 160, bc[0], bc[1], bc[2], 1, true);
        if (k == 1) gulistan(w); else if (k == 2) mirpur(w); else lalbaghArena(w);
        // generic dirt
        for (int n = 0; n < 40; n++) {
            double x = w.rf(8, 152), z = w.rf(8, 152);
            int r = w.rnd.nextInt(3);
            if (r == 0) garbage(w, x, z); else if (r == 1) pothole(w, x, z); else puddle(w, x, z);
        }
        return w;
    }

    static void spawnLine(World w, int team, double x, double z, double dx, double dz) {
        for (int i = 0; i < 6; i++) w.spawns.add(new float[]{(float) (x + dx * i), (float) (z + dz * i), team});
    }

    static void gulistan(World w) {
        w.box(0, 0, 72, 160, 0.06, 88, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.box(73, 0, 0, 87, 0.06, 160, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.rect(0, 72, 160, 88, 0xFF3A3A3C); w.rect(73, 0, 87, 160, 0xFF3A3A3C);
        double[][] q = {{6, 6, 2, 0}, {94, 6, 3, 0}, {6, 94, 2, 1}, {94, 94, 3, 1}};
        for (double[] o : q) {
            for (int a = 0; a < 2; a++)
                for (int b = 0; b < 2; b++) {
                    double x0 = o[0] + a * 30, z0 = o[1] + b * 30;
                    double[] c = MID[w.rnd.nextInt(MID.length)];
                    if (w.rnd.nextFloat() < 0.55f) shell(w, x0, z0, x0 + w.rf(18, 24), z0 + w.rf(16, 22), w.rf(7, 9), c, (int) o[2] == 2 ? 2 : 3, 0, 0);
                    else solidB(w, x0, z0, x0 + 22, z0 + 20, w.rf(14, 24), c, 1);
                }
        }
        flyoverX(w, 42, 118, 80, 5);
        jam(w, 1, 80, 8, 4, 2); jam(w, 1, 80, 100, 4, 2);
        jam(w, 0, 80, 6, 3, 2); jam(w, 0, 80, 124, 3, 2);
        for (int n = 0; n < 8; n++) stall(w, w.rf(10, 150), w.rnd.nextBoolean() ? 70 : 89);
        for (double x = 4; x < 156; x += 20) { pole(w, x, 70); wireX(w, x, x + 20, 70); }
        spawnLine(w, 0, 8, 76, 0, 1.6); spawnLine(w, 1, 150, 76, 0, 1.6);
    }

    static void mirpur(World w) {
        double[] c = {.72, .72, .70};
        w.box(0, 0, 18, 160, 0.06, 28, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.box(0, 0, 132, 160, 0.06, 142, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.box(18, 0, 0, 28, 0.06, 160, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.box(132, 0, 0, 142, 0.06, 160, ASPH[0], ASPH[1], ASPH[2], 4, false);
        w.rect(0, 18, 160, 28, 0xFF3A3A3C); w.rect(0, 132, 160, 142, 0xFF3A3A3C);
        w.rect(18, 0, 28, 160, 0xFF3A3A3C); w.rect(132, 0, 142, 160, 0xFF3A3A3C);
        green(w, 46, 46, 114, 114);
        w.box(78, 0.09, 56, 82, 0.12, 104, .75, .7, .5, 0, false);
        double x0 = 40, x1 = 120;
        w.box(x0, 0, x0, 76, 10, x0 + 3, c[0], c[1], c[2], 0, true); w.box(84, 0, x0, x1, 10, x0 + 3, c[0], c[1], c[2], 0, true);
        w.box(x0, 0, x1 - 3, 76, 10, x1, c[0], c[1], c[2], 0, true); w.box(84, 0, x1 - 3, x1, 10, x1, c[0], c[1], c[2], 0, true);
        w.box(x0, 0, x0 + 3, x0 + 3, 10, 76, c[0], c[1], c[2], 0, true); w.box(x0, 0, 84, x0 + 3, 10, x1 - 3, c[0], c[1], c[2], 0, true);
        w.box(x1 - 3, 0, x0 + 3, x1, 10, 76, c[0], c[1], c[2], 0, true); w.box(x1 - 3, 0, 84, x1, 10, x1 - 3, c[0], c[1], c[2], 0, true);
        for (int k = 0; k < 3; k++) {
            w.box(46, 0, x0 + 3 + 2 * k, 114, 1.5 - 0.5 * k, x0 + 5 + 2 * k, .55, .55, .6, 0, true);
            w.box(46, 0, x1 - 5 - 2 * k, 114, 1.5 - 0.5 * k, x1 - 3 - 2 * k, .55, .55, .6, 0, true);
        }
        shell(w, 52, 70, 60, 90, 3.2, new double[]{.8, .8, .76}, 2, 0, 0);
        shell(w, 100, 70, 108, 90, 3.2, new double[]{.8, .8, .76}, 3, 0, 0);
        w.box(70, 0, 76, 72, 1, 78, .5, .4, .3, 0, true); w.box(88, 0, 82, 90, 1, 84, .5, .4, .3, 0, true);
        w.rect(x0, x0, x1, x1, 0xFF9C9C98); w.rect(46, 46, 114, 114, 0xFF4F8A3F);
        double[][] cor = {{4, 4}, {118, 4}, {4, 118}, {118, 118}};
        for (double[] o : cor) {
            double[] cc = MID[w.rnd.nextInt(MID.length)];
            if (w.rnd.nextBoolean()) shell(w, o[0], o[1], o[0] + 22, o[1] + 20, 8, cc, w.rnd.nextInt(4), 0, 0);
            else solidB(w, o[0], o[1], o[0] + 22, o[1] + 20, 18, cc, 1);
        }
        jam(w, 0, 23, 30, 4, 2); jam(w, 0, 137, 90, 4, 2); jam(w, 1, 23, 40, 4, 2); jam(w, 1, 137, 90, 4, 2);
        for (int n = 0; n < 12; n++) tree(w, w.rf(30, 130), w.rnd.nextBoolean() ? w.rf(30, 38) : w.rf(122, 130));
        for (int n = 0; n < 6; n++) stall(w, w.rf(30, 130), w.rnd.nextBoolean() ? 29 : 131);
        spawnLine(w, 0, 56, 8, 8, 0); spawnLine(w, 1, 56, 150, 8, 0);
    }

    static void lalbaghArena(World w) {
        double[] brick = {.70, .42, .32};
        double x0 = 20, x1 = 140, z0 = 40, z1 = 120;
        w.box(0, 0, 74, 160, 0.06, 86, .35, .3, .26, 4, false); w.rect(0, 74, 160, 86, 0xFF5C5248);
        green(w, x0, z0, x1, z1);
        double gl = 76, gr = 84;
        w.box(x0, 0, z0, gl, 5, z0 + 2, brick[0], brick[1], brick[2], 0, true); w.box(gr, 0, z0, x1, 5, z0 + 2, brick[0], brick[1], brick[2], 0, true);
        w.box(x0, 0, z1 - 2, gl, 5, z1, brick[0], brick[1], brick[2], 0, true); w.box(gr, 0, z1 - 2, x1, 5, z1, brick[0], brick[1], brick[2], 0, true);
        w.box(x0, 0, z0 + 2, x0 + 2, 5, gl, brick[0], brick[1], brick[2], 0, true); w.box(x0, 0, gr, x0 + 2, 5, z1 - 2, brick[0], brick[1], brick[2], 0, true);
        w.box(x1 - 2, 0, z0 + 2, x1, 5, gl, brick[0], brick[1], brick[2], 0, true); w.box(x1 - 2, 0, gr, x1, 5, z1 - 2, brick[0], brick[1], brick[2], 0, true);
        double[][] b = {{x0 - 2, z0 - 2}, {x1 - 4, z0 - 2}, {x0 - 2, z1 - 4}, {x1 - 4, z1 - 4}};
        for (double[] p : b) w.box(p[0], 0, p[1], p[0] + 6, 8, p[1] + 6, .66, .4, .3, 0, true);
        w.rect(x0, z0, x1, z1, 0xFF8A6A50);
        shell(w, 68, 46, 92, 58, 6.5, new double[]{.93, .9, .8}, 0, 0, 0);
        w.box(70, 7, 48, 76, 10, 54, .95, .95, .9, 0, false); w.box(82, 7, 48, 88, 10, 54, .95, .95, .9, 0, false);
        shell(w, 74, 100, 86, 112, 7.5, new double[]{.95, .93, .88}, 1, 0, 0);
        w.box(77, 8, 103, 83, 11, 109, .95, .95, .9, 0, false);
        shell(w, 28, 48, 52, 58, 6, new double[]{.88, .75, .55}, 0, 0, 0);
        shell(w, 108, 100, 132, 110, 6, new double[]{.88, .75, .55}, 1, 0, 0);
        w.box(78.5, -0.2, 60, 81.5, 0.07, 98, .17, .33, .37, 3, false);
        for (int n = 0; n < 14; n++) tree(w, w.rf(26, 134), w.rf(62, 96));
        // outside old-town
        for (int a = 0; a < 3; a++) {
            double[] c1 = OLD[w.rnd.nextInt(OLD.length)], c2 = OLD[w.rnd.nextInt(OLD.length)];
            shell(w, 2, 6 + a * 12, 14, 16 + a * 12, 7, c1, 2, 0, 0);
            shell(w, 146, 6 + a * 12, 158, 16 + a * 12, 7, c2, 3, 0, 0);
            shell(w, 2, 104 + a * 17, 14, 114 + a * 17, 7, c2, 2, 0, 0);
            solidB(w, 146, 104 + a * 17, 158, 114 + a * 17, w.rf(10, 16), c1, 1);
        }
        for (double x = 24; x < 140; x += 24) { solidB(w, x, 4, x + 16, 30, w.rf(10, 16), OLD[w.rnd.nextInt(OLD.length)], 1); solidB(w, x, 130, x + 16, 156, w.rf(10, 16), OLD[w.rnd.nextInt(OLD.length)], 1); }
        jam(w, 0, 80, 4, 3, 1); jam(w, 0, 80, 128, 3, 1);
        for (double x = 4; x < 156; x += 20) { pole(w, x, 72); wireX(w, x, x + 20, 72); }
        spawnLine(w, 0, 6, 70, 0, 4); spawnLine(w, 1, 152, 70, 0, 4);
    }
}
