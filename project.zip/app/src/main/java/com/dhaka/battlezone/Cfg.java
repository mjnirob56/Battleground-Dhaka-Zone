package com.dhaka.battlezone;

import android.content.Context;
import android.content.SharedPreferences;

/** All saved settings, stats and costume choices. */
public class Cfg {
    public static SharedPreferences sp;

    // ---- settings ----
    public static float sens = 1.0f;       // camera sensitivity
    public static float sensAds = 0.6f;    // sensitivity while aiming
    public static int aimAssist = 40;      // 0..100
    public static int botLevel = 1;        // 0 easy, 1 normal, 2 hard
    public static boolean fpp = false;     // first person view
    public static int quality = 1;         // 0 low, 1 medium, 2 high
    public static int fpsCap = 60;         // 30 or 60
    public static float hudScale = 1.0f;
    public static boolean sound = true;
    public static float volume = 0.8f;
    public static int lang = 0;            // 0 English, 1 Bangla
    public static boolean invertY = false;
    public static boolean leftFire = true;
    public static int tdmLoadout = 0;
    public static String playerName = "Player";

    // ---- progress ----
    public static int taka = 500;
    public static int matches, wins, kills, deaths, bestRank = 99, headshots;

    // ---- costume ----
    public static int top = 0, topColor = 0;
    public static int bottom = 0, bottomColor = 2;
    public static int head = 0, headColor = 4;
    public static int shoeColor = 5;
    public static String owned = "";

    public static final int[] PAL = {0xD32F2F, 0x2E7D32, 0x1565C0, 0xFBC02D, 0xEEEEEE, 0x212121, 0xEF6C00, 0x6A1B9A, 0x00897B, 0xA1887F};
    public static final String[] TOPS = {"T-Shirt", "Panjabi", "BD Jersey", "Hoodie", "Tactical Vest"};
    public static final String[] BOTTOMS = {"Jeans", "Lungi", "Shorts", "Cargo"};
    public static final String[] HEADS = {"None", "Cap", "Gamchha", "Tupi", "Bandana"};
    public static final int[] TOP_PRICE = {0, 150, 250, 200, 300};
    public static final int[] BOTTOM_PRICE = {0, 120, 80, 180};
    public static final int[] HEAD_PRICE = {0, 60, 100, 90, 70};

    public static void load(Context c) {
        sp = c.getSharedPreferences("dbz", Context.MODE_PRIVATE);
        sens = sp.getFloat("sens", 1f);
        sensAds = sp.getFloat("sensAds", 0.6f);
        aimAssist = sp.getInt("aimAssist", 40);
        botLevel = sp.getInt("botLevel", 1);
        fpp = sp.getBoolean("fpp", false);
        quality = sp.getInt("quality", 1);
        fpsCap = sp.getInt("fpsCap", 60);
        hudScale = sp.getFloat("hudScale", 1f);
        sound = sp.getBoolean("sound", true);
        volume = sp.getFloat("volume", 0.8f);
        lang = sp.getInt("lang", 0);
        invertY = sp.getBoolean("invertY", false);
        leftFire = sp.getBoolean("leftFire", true);
        tdmLoadout = sp.getInt("tdmLoadout", 0);
        playerName = sp.getString("name", "Player");
        taka = sp.getInt("taka", 500);
        matches = sp.getInt("matches", 0);
        wins = sp.getInt("wins", 0);
        kills = sp.getInt("kills", 0);
        deaths = sp.getInt("deaths", 0);
        bestRank = sp.getInt("bestRank", 99);
        headshots = sp.getInt("headshots", 0);
        top = sp.getInt("top", 0);
        topColor = sp.getInt("topColor", 0);
        bottom = sp.getInt("bottom", 0);
        bottomColor = sp.getInt("bottomColor", 2);
        head = sp.getInt("head", 0);
        headColor = sp.getInt("headColor", 4);
        shoeColor = sp.getInt("shoeColor", 5);
        owned = sp.getString("owned", "");
    }

    public static void save() {
        if (sp == null) return;
        sp.edit()
                .putFloat("sens", sens).putFloat("sensAds", sensAds).putInt("aimAssist", aimAssist)
                .putInt("botLevel", botLevel).putBoolean("fpp", fpp).putInt("quality", quality)
                .putInt("fpsCap", fpsCap).putFloat("hudScale", hudScale).putBoolean("sound", sound)
                .putFloat("volume", volume).putInt("lang", lang).putBoolean("invertY", invertY)
                .putBoolean("leftFire", leftFire).putInt("tdmLoadout", tdmLoadout)
                .putString("name", playerName).putInt("taka", taka)
                .putInt("matches", matches).putInt("wins", wins).putInt("kills", kills)
                .putInt("deaths", deaths).putInt("bestRank", bestRank).putInt("headshots", headshots)
                .putInt("top", top).putInt("topColor", topColor).putInt("bottom", bottom)
                .putInt("bottomColor", bottomColor).putInt("head", head).putInt("headColor", headColor)
                .putInt("shoeColor", shoeColor).putString("owned", owned)
                .apply();
    }

    public static boolean has(String key, int price) {
        return price == 0 || (","+owned+",").contains("," + key + ",");
    }

    public static boolean buy(String key, int price) {
        if (has(key, price)) return true;
        if (taka < price) return false;
        taka -= price;
        owned = owned.isEmpty() ? key : owned + "," + key;
        save();
        return true;
    }

    public static float pr(int c) { return ((c >> 16) & 255) / 255f; }
    public static float pg(int c) { return ((c >> 8) & 255) / 255f; }
    public static float pb(int c) { return (c & 255) / 255f; }
}
