package com.dhaka.battlezone;

/** Simple box-built vehicle models. Local +X is forward. Part: cx,cy,cz,sx,sy,sz,colorMode
 * colorMode: 0 body, 1 dark, 2 glass, 3 accent(red), 4 grey, 5 yellow */
public class VehModel {
    public static final float[][][] PARTS = {
        // 0 CNG
        {{0, 0.75f, 0, 2.4f, 0.9f, 1.2f, 0}, {-0.2f, 1.5f, 0, 1.9f, 0.12f, 1.3f, 1}, {1.0f, 0.3f, 0, 0.55f, 0.6f, 0.15f, 1},
         {-0.8f, 0.3f, 0.62f, 0.6f, 0.6f, 0.15f, 1}, {-0.8f, 0.3f, -0.62f, 0.6f, 0.6f, 0.15f, 1}, {0.4f, 1.1f, 0, 0.1f, 0.6f, 1.1f, 2}},
        // 1 Rickshaw
        {{0, 0.55f, 0, 1.6f, 0.18f, 0.75f, 0}, {-0.35f, 1.4f, 0, 1.05f, 0.12f, 0.95f, 3}, {-0.35f, 0.95f, 0, 0.7f, 0.5f, 0.7f, 3},
         {-0.6f, 0.36f, 0.45f, 0.72f, 0.72f, 0.07f, 1}, {-0.6f, 0.36f, -0.45f, 0.72f, 0.72f, 0.07f, 1}, {0.9f, 0.3f, 0, 0.6f, 0.6f, 0.07f, 1}},
        // 2 Bus
        {{0, 1.9f, 0, 9.4f, 2.6f, 2.5f, 0}, {0, 2.65f, 0, 9.45f, 0.9f, 2.52f, 2}, {0, 0.5f, 0, 9.0f, 0.6f, 2.4f, 1},
         {3.0f, 0.55f, 1.3f, 1.0f, 1.1f, 0.3f, 1}, {3.0f, 0.55f, -1.3f, 1.0f, 1.1f, 0.3f, 1},
         {-3.0f, 0.55f, 1.3f, 1.0f, 1.1f, 0.3f, 1}, {-3.0f, 0.55f, -1.3f, 1.0f, 1.1f, 0.3f, 1}},
        // 3 Car
        {{0, 0.65f, 0, 4.3f, 0.8f, 1.8f, 0}, {-0.2f, 1.3f, 0, 2.2f, 0.6f, 1.6f, 2},
         {1.4f, 0.3f, 0.9f, 0.7f, 0.6f, 0.2f, 1}, {1.4f, 0.3f, -0.9f, 0.7f, 0.6f, 0.2f, 1},
         {-1.4f, 0.3f, 0.9f, 0.7f, 0.6f, 0.2f, 1}, {-1.4f, 0.3f, -0.9f, 0.7f, 0.6f, 0.2f, 1}},
        // 4 Truck
        {{2.4f, 1.4f, 0, 2.0f, 1.8f, 2.3f, 0}, {3.0f, 1.9f, 0, 0.2f, 0.8f, 2.0f, 2}, {-1.0f, 2.0f, 0, 5.0f, 2.6f, 2.4f, 4},
         {-0.2f, 0.6f, 0, 7.0f, 0.4f, 2.2f, 1}, {2.4f, 0.5f, 1.1f, 1.0f, 1.0f, 0.3f, 1}, {2.4f, 0.5f, -1.1f, 1.0f, 1.0f, 0.3f, 1},
         {-2.2f, 0.5f, 1.1f, 1.0f, 1.0f, 0.3f, 1}, {-2.2f, 0.5f, -1.1f, 1.0f, 1.0f, 0.3f, 1}},
    };
    public static final float[] LEN = {2.6f, 2.4f, 9.5f, 4.4f, 7.2f};
    public static final float[] WID = {1.4f, 1.2f, 2.6f, 1.9f, 2.5f};
    public static final float[] HGT = {1.6f, 1.7f, 3.2f, 1.9f, 3.4f};
    public static final float[] SPEED = {8f, 3.5f, 7f, 11f, 8f};

    public static void color(int mode, float br, float bg, float bb, float[] out) {
        switch (mode) {
            case 0: out[0] = br; out[1] = bg; out[2] = bb; break;
            case 1: out[0] = 0.08f; out[1] = 0.08f; out[2] = 0.09f; break;
            case 2: out[0] = 0.32f; out[1] = 0.46f; out[2] = 0.52f; break;
            case 3: out[0] = 0.75f; out[1] = 0.12f; out[2] = 0.12f; break;
            case 4: out[0] = 0.7f; out[1] = 0.7f; out[2] = 0.68f; break;
            default: out[0] = 0.95f; out[1] = 0.8f; out[2] = 0.15f; break;
        }
    }

    public static float[] bodyColor(int type, java.util.Random r) {
        switch (type) {
            case 0: return r.nextBoolean() ? new float[]{0.1f, 0.55f, 0.25f} : new float[]{0.15f, 0.4f, 0.8f};
            case 1: float[][] c = {{0.9f, 0.2f, 0.2f}, {0.2f, 0.6f, 0.9f}, {0.95f, 0.75f, 0.1f}, {0.2f, 0.75f, 0.35f}, {0.85f, 0.3f, 0.7f}};
                return c[r.nextInt(c.length)];
            case 2: float[][] b = {{0.85f, 0.15f, 0.15f}, {0.95f, 0.7f, 0.1f}, {0.15f, 0.45f, 0.8f}, {0.2f, 0.65f, 0.3f}};
                return b[r.nextInt(b.length)];
            case 3: float[][] k = {{0.92f, 0.92f, 0.9f}, {0.12f, 0.12f, 0.14f}, {0.7f, 0.7f, 0.72f}, {0.95f, 0.78f, 0.1f}};
                return k[r.nextInt(k.length)];
            default: return r.nextBoolean() ? new float[]{0.15f, 0.3f, 0.6f} : new float[]{0.9f, 0.5f, 0.1f};
        }
    }
}
