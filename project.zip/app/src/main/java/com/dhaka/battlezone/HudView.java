package com.dhaka.battlezone;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** In-match HUD + touch controls, drawn with Canvas on top of the GL view. */
public class HudView extends View {
    static final int B_FIRE = 1, B_FIRE2 = 2, B_ADS = 3, B_JUMP = 4, B_CROUCH = 5, B_PRONE = 6, B_RELOAD = 7, B_GREN = 8,
        B_PICK = 9, B_PAUSE = 10, B_SLOT = 20, B_HEAL = 30;

    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF rf = new RectF();
    final Path path = new Path();
    float d;
    Shader vig;
    boolean bigMap = false;
    final int[] role = new int[12];      // 0 none 1 joystick 2 look 3 button
    final int[] roleBtn = new int[12];
    final float[] lastX = new float[12], lastY = new float[12];
    float joyOx, joyOy, joyCx, joyCy;
    int joyPid = -1;
    final float[][] btn = {
        {B_FIRE, 0.88f, 0.66f, 44}, {B_FIRE2, 0.07f, 0.36f, 32}, {B_ADS, 0.76f, 0.80f, 28}, {B_JUMP, 0.95f, 0.40f, 26},
        {B_CROUCH, 0.86f, 0.44f, 24}, {B_PRONE, 0.76f, 0.47f, 22}, {B_RELOAD, 0.69f, 0.88f, 24}, {B_GREN, 0.70f, 0.64f, 24},
        {B_PICK, 0.60f, 0.62f, 30}, {B_PAUSE, 0.96f, 0.08f, 16},
    };
    final String[] label = {"", "FIRE", "FIRE", "AIM", "JUMP", "CROUCH", "PRONE", "RELOAD", "BOMB", "PICK", "II"};

    public HudView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        tp.setTypeface(Typeface.DEFAULT_BOLD);
        setFocusable(false);
    }

    float R(float dp) { return dp * d * Cfg.hudScale; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        vig = new RadialGradient(w / 2f, h / 2f, (float) Math.sqrt(w * w + h * h) * 0.55f,
            new int[]{0x00000000, 0x00000000, 0x55000000}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    // ================================================================== touch
    float[] findBtn(float x, float y) {
        Fighter me = Game.me;
        boolean air = me != null && me.st < 3;
        for (float[] b : btn) {
            int id = (int) b[0];
            if (id == B_FIRE2 && !Cfg.leftFire) continue;
            if (id == B_PICK && Game.nearPick.isEmpty()) continue;
            if (air && id != B_JUMP && id != B_PAUSE) continue;
            float cx = b[1] * getWidth(), cy = b[2] * getHeight(), r = R(b[3]) * 1.15f;
            if (id == B_JUMP && air) { cx = 0.85f * getWidth(); cy = 0.55f * getHeight(); r = R(46); }
            if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) return b;
        }
        return null;
    }

    int hitSlot(float x, float y) {
        if (Game.me == null || Game.me.st < 3) return -1;
        float W = getWidth(), H = getHeight();
        for (int k = 0; k < 4; k++) {
            float cx = W * (0.395f + k * 0.07f), cy = H * 0.88f;
            if (Math.abs(x - cx) < W * 0.033f && Math.abs(y - cy) < H * 0.05f) return k;
        }
        for (int k = 0; k < 5; k++) {
            float cx = W * (0.40f + k * 0.06f), cy = H * 0.19f;
            if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < R(20) * R(20)) return 10 + k;
        }
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (Game.state != Game.PLAY || Game.me == null) return false;
        int a = e.getActionMasked(), idx = e.getActionIndex();
        float W = getWidth(), H = getHeight();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int id = e.getPointerId(idx);
            if (id >= 12) return true;
            float x = e.getX(idx), y = e.getY(idx);
            lastX[id] = x; lastY[id] = y;
            if (bigMap) { bigMap = false; role[id] = 0; return true; }
            float[] b = findBtn(x, y);
            int sl = hitSlot(x, y);
            if (b != null) {
                role[id] = 3; roleBtn[id] = (int) b[0];
                press((int) b[0], true);
            } else if (sl >= 0) {
                role[id] = 0;
                if (sl < 4) Input.evSlot = sl; else Input.evHeal = sl - 10;
            } else if (x < R(8) + mapSize() + R(6) && y < R(8) + mapSize() + R(6) && x > R(6) && y > R(6)) {
                bigMap = true; role[id] = 0;
            } else if (x < W * 0.45f && y > H * 0.30f && joyPid < 0) {
                role[id] = 1; joyPid = id; joyOx = x; joyOy = y; joyCx = x; joyCy = y;
            } else role[id] = 2;
        } else if (a == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                if (id >= 12) continue;
                float x = e.getX(i), y = e.getY(i);
                if (role[id] == 1) {
                    float rad = R(55);
                    float dx = x - joyOx, dy = y - joyOy, l = (float) Math.sqrt(dx * dx + dy * dy);
                    if (l > rad) { dx = dx / l * rad; dy = dy / l * rad; }
                    joyCx = joyOx + dx; joyCy = joyOy + dy;
                    Input.moveX = dx / rad; Input.moveY = -dy / rad;
                } else if (role[id] == 2 || (role[id] == 3 && (roleBtn[id] == B_FIRE || roleBtn[id] == B_FIRE2))) {
                    Input.addLook(x - lastX[id], y - lastY[id]);
                }
                lastX[id] = x; lastY[id] = y;
            }
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) {
            int id = e.getPointerId(idx);
            if (a == MotionEvent.ACTION_CANCEL) { Input.clear(); joyPid = -1; for (int i = 0; i < 12; i++) role[i] = 0; return true; }
            if (id >= 12) return true;
            if (role[id] == 1) { Input.moveX = 0; Input.moveY = 0; joyPid = -1; }
            if (role[id] == 3) press(roleBtn[id], false);
            role[id] = 0;
        }
        return true;
    }

    void press(int id, boolean down) {
        switch (id) {
            case B_FIRE: Input.fire = down; break;
            case B_FIRE2: Input.fire2 = down; break;
            default:
                if (!down) return;
                if (id == B_ADS) Input.evAds = true;
                else if (id == B_JUMP) Input.evJump = true;
                else if (id == B_CROUCH) Input.evCrouch = true;
                else if (id == B_PRONE) Input.evProne = true;
                else if (id == B_RELOAD) Input.evReload = true;
                else if (id == B_GREN) Input.evGren = true;
                else if (id == B_PICK) Input.evPick = true;
                else if (id == B_PAUSE) { if (MainActivity.instance != null) MainActivity.instance.showPause(); }
        }
    }

    float mapSize() { return Math.min(R(150), getHeight() * 0.36f); }

    // ================================================================== drawing
    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align al) {
        tp.setTextSize(size); tp.setColor(color); tp.setTextAlign(al);
        c.drawText(s, x, y, tp);
    }

    void box(Canvas c, float l, float t, float r, float b, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(color);
        rf.set(l, t, r, b);
        c.drawRoundRect(rf, R(4), R(4), p);
    }

    void circleBtn(Canvas c, float cx, float cy, float r, String s, boolean active) {
        p.setStyle(Paint.Style.FILL); p.setColor(active ? 0x88FFFFFF : 0x55000000);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(2)); p.setColor(0xAAFFFFFF);
        c.drawCircle(cx, cy, r, p);
        text(c, s, cx, cy + r * 0.12f, Math.min(r * 0.42f, R(13)), 0xFFFFFFFF, Paint.Align.CENTER);
    }

    String clock(float s) { int t = Math.max(0, (int) s); return (t / 60) + ":" + (t % 60 < 10 ? "0" : "") + (t % 60); }

    @Override
    protected void onDraw(Canvas c) {
        if (Game.state == Game.PLAY && Game.me != null) {
            try { drawHud(c); } catch (Throwable t) { }
        }
        postInvalidateDelayed(33);
    }

    void drawHud(Canvas c) {
        float W = getWidth(), H = getHeight();
        Fighter me = Game.me;
        boolean air = me.st < 3;
        float cx = W / 2, cy = H / 2;

        if (vig != null) { p.setStyle(Paint.Style.FILL); p.setShader(vig); c.drawRect(0, 0, W, H, p); p.setShader(null); }

        // zone damage tint
        if (Game.mode == 0 && me.st == 3 && me.alive && !Game.inZone(me.x, me.z, 0)) {
            p.setStyle(Paint.Style.FILL); p.setColor(0x302255FF); c.drawRect(0, 0, W, H, p);
            text(c, "OUTSIDE THE SAFE ZONE!", cx, H * 0.33f, R(15), 0xFF66AAFF, Paint.Align.CENTER);
        }
        // damage direction
        for (float[] dd : Game.dmgDirs) {
            float age = Game.matchTime - dd[2];
            if (age > 1.6f) continue;
            float rel = (float) Math.atan2(dd[0] - me.x, -(dd[1] - me.z)) - Game.camYaw;
            float deg = (float) Math.toDegrees(rel) - 90f;
            float rr = H * 0.30f;
            rf.set(cx - rr, cy - rr, cx + rr, cy + rr);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(9)); p.setColor(((int) (255 * (1f - age / 1.6f)) << 24) | 0xFF2222);
            c.drawArc(rf, deg - 14, 28, false, p);
        }
        // crosshair / scope
        if (!air && me.alive) {
            float zoom = me.ads ? Game.adsZoom(me) : 1f;
            if (me.ads && zoom >= 3f) {
                float rr = H * 0.46f, wid = Math.max(W, H);
                p.setStyle(Paint.Style.STROKE); p.setColor(0xFF000000); p.setStrokeWidth(wid);
                c.drawCircle(cx, cy, rr + wid / 2, p);
                p.setStrokeWidth(R(1)); p.setColor(0xFF000000);
                c.drawLine(cx - rr, cy, cx + rr, cy, p); c.drawLine(cx, cy - rr, cx, cy + rr, p);
            } else if (me.cur != 3) {
                float gap = R(me.ads ? 3 : 7) + (me.speedNow > 1 ? R(5) : 0) + me.recoilAcc * R(120);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(2)); p.setColor(0xDDFFFFFF);
                float l = R(9);
                c.drawLine(cx - gap - l, cy, cx - gap, cy, p); c.drawLine(cx + gap, cy, cx + gap + l, cy, p);
                c.drawLine(cx, cy - gap - l, cx, cy - gap, p); c.drawLine(cx, cy + gap, cx, cy + gap + l, p);
            }
            if (Game.hitMarkerT > 0) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(2.5f)); p.setColor(Game.hitHead ? 0xFFFF3030 : 0xFFFFFFFF);
                float o = R(7), q = R(15);
                c.drawLine(cx - q, cy - q, cx - o, cy - o, p); c.drawLine(cx + q, cy - q, cx + o, cy - o, p);
                c.drawLine(cx - q, cy + q, cx - o, cy + o, p); c.drawLine(cx + q, cy + q, cx + o, cy + o, p);
            }
        }
        // name tags
        try {
            Tag[] tg = Game.tags.toArray(new Tag[0]);
            for (Tag t : tg) {
                text(c, t.name, t.sx * W, t.sy * H, R(11), t.enemy ? 0xFFFF6A5A : 0xFF7CFF8A, Paint.Align.CENTER);
            }
        } catch (Throwable t) { }

        drawMinimap(c, 0, 0, false);

        // top info
        float bw = R(150);
        box(c, cx - bw / 2, R(4), cx + bw / 2, R(26), 0x99000000);
        if (Game.mode == 0) {
            int alive = 0; for (Fighter f : Game.fs) if (f.alive) alive++;
            text(c, "ALIVE " + alive + "   KILLS " + me.kills, cx, R(20), R(13), 0xFFFFFFFF, Paint.Align.CENTER);
            String z = Game.zr > 600 ? "" : (Game.zShrink ? "ZONE SHRINKING " : "ZONE CLOSES IN ") + clock(Game.zTimer);
            if (Game.planeOn || Game.zr <= 600 || true) {
                box(c, cx - bw / 2, R(28), cx + bw / 2, R(48), 0x88203060);
                text(c, Game.planeOn ? "PLANE ON ITS WAY" : (Game.zPhase == 0 && !Game.zShrink ? "ZONE ACTIVE IN " + clock(Game.zTimer) : z), cx, R(42), R(11), 0xFFAADDFF, Paint.Align.CENTER);
            }
        } else {
            text(c, "YOU " + Game.scoreA + " : " + Game.scoreB + " ENEMY   " + clock(Game.tdmTime), cx, R(20), R(13), 0xFFFFFFFF, Paint.Align.CENTER);
        }
        // compass
        float deg = ((float) Math.toDegrees(Game.camYaw) % 360f + 360f) % 360f;
        String[] card = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        text(c, card[((int) ((deg + 22.5f) / 45f)) % 8] + " " + (int) deg + "°", cx, R(62), R(11), 0xCCFFFFFF, Paint.Align.CENTER);

        // kill feed
        float fy = R(30);
        int shown = 0;
        for (int i = Game.feed.size() - 1; i >= 0 && shown < 5; i--, shown++) {
            Object[] o = Game.feed.get(i);
            text(c, (String) o[0], W - R(8), fy, R(11), 0xFFFFFFFF, Paint.Align.RIGHT);
            fy += R(15);
        }
        // toast
        if (Game.toastT > 0 && !Game.toast.isEmpty()) {
            float al = Math.min(1f, Game.toastT);
            box(c, cx - W * 0.3f, H * 0.22f, cx + W * 0.3f, H * 0.22f + R(26), ((int) (120 * al) << 24));
            text(c, Game.toast, cx, H * 0.22f + R(18), R(13), ((int) (255 * al) << 24) | 0xFFFFFF, Paint.Align.CENTER);
        }
        if (!me.alive && Game.mode == 1) text(c, "RESPAWNING...", cx, cy, R(20), 0xFFFFFFFF, Paint.Align.CENTER);

        // joystick
        float jx = joyPid >= 0 ? joyOx : W * 0.13f, jy = joyPid >= 0 ? joyOy : H * 0.76f;
        p.setStyle(Paint.Style.FILL); p.setColor(0x33FFFFFF); c.drawCircle(jx, jy, R(55), p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(2)); p.setColor(0x66FFFFFF); c.drawCircle(jx, jy, R(55), p);
        p.setStyle(Paint.Style.FILL); p.setColor(0x88FFFFFF);
        c.drawCircle(joyPid >= 0 ? joyCx : jx, joyPid >= 0 ? joyCy : jy, R(24), p);

        // buttons
        for (float[] b : btn) {
            int id = (int) b[0];
            if (id == B_FIRE2 && !Cfg.leftFire) continue;
            if (id == B_PICK && Game.nearPick.isEmpty()) continue;
            if (air && id != B_JUMP && id != B_PAUSE) continue;
            float bx = b[1] * W, by = b[2] * H, br = R(b[3]);
            String lb = label[id];
            boolean act = false;
            if (id == B_ADS) act = me.ads;
            if (id == B_CROUCH) act = me.stance == 1;
            if (id == B_PRONE) act = me.stance == 2;
            if (id == B_FIRE) act = Input.fire;
            if (id == B_JUMP && air) { bx = 0.85f * W; by = 0.55f * H; br = R(46); lb = me.st == 0 ? "JUMP!" : (me.st == 1 ? "CHUTE" : "JUMP"); }
            if (id == B_JUMP && air && me.st == 2) continue;
            circleBtn(c, bx, by, br, lb, act);
            if (id == B_PICK) text(c, Game.nearPick, bx, by - br - R(6), R(12), 0xFFFFE070, Paint.Align.CENTER);
        }
        if (air) { text(c, "Alt " + (int) me.y + "m", W * 0.85f, H * 0.40f, R(13), 0xFFFFFFFF, Paint.Align.CENTER); }

        if (!air) drawBottom(c, me, W, H);
        if (bigMap) drawMinimap(c, 0, 0, true);
    }

    void drawBottom(Canvas c, Fighter me, float W, float H) {
        // weapon slots
        for (int k = 0; k < 4; k++) {
            float cx = W * (0.395f + k * 0.07f), cy = H * 0.88f;
            com.dhaka.battlezone.W.Gun g = k == 3 ? com.dhaka.battlezone.W.TAWA : me.slot[k];
            boolean cur = me.cur == k;
            box(c, cx - W * 0.032f, cy - H * 0.05f, cx + W * 0.032f, cy + H * 0.05f, cur ? 0xAAFFFFFF : 0x77000000);
            String nm = g == null ? "-" : (g.name.length() > 8 ? g.name.substring(0, 8) : g.name);
            text(c, nm, cx, cy - H * 0.005f, R(8.5f), cur ? 0xFF000000 : 0xFFFFFFFF, Paint.Align.CENTER);
            if (g != null && k < 3) text(c, me.mag[k] + "", cx, cy + H * 0.035f, R(9), cur ? 0xFF000000 : 0xFFFFD060, Paint.Align.CENTER);
            if (g == null || k == 3) text(c, "" + (k + 1), cx, cy + H * 0.035f, R(8), 0x99FFFFFF, Paint.Align.CENTER);
        }
        // ammo
        com.dhaka.battlezone.W.Gun g = me.gun();
        if (g.cls != 6) text(c, me.mag[me.cur] + " / " + me.reserve[g.ammo] + "  " + com.dhaka.battlezone.W.AMMO[g.ammo], W * 0.5f, H * 0.80f, R(14), 0xFFFFFFFF, Paint.Align.CENTER);
        // health
        float hw = W * 0.30f, hx = W * 0.5f - hw / 2, hy = H * 0.945f, hh = H * 0.032f;
        box(c, hx, hy, hx + hw, hy + hh, 0x99000000);
        float hp = Math.max(0, me.hp) / 100f;
        box(c, hx, hy, hx + hw * hp, hy + hh, hp > 0.35f ? 0xFF4CD964 : 0xFFE53935);
        if (me.boost > 0) box(c, hx, hy - H * 0.012f, hx + hw * me.boost / 100f, hy - H * 0.002f, 0xFF40C4FF);
        text(c, (int) me.hp + "", W * 0.5f, hy + hh * 0.85f, R(11), 0xFFFFFFFF, Paint.Align.CENTER);
        text(c, "VEST " + me.armor + (me.armor > 0 ? " (" + (int) me.armorDur + ")" : "") + "   HELM " + me.helmet + (me.scope > 0 ? "   SCOPE " + (int) com.dhaka.battlezone.W.SCOPE_ZOOM[me.scope] + "x" : ""),
            W * 0.5f, hy - H * 0.02f, R(10), 0xDDFFFFFF, Paint.Align.CENTER);
        // grenades
        text(c, "BOMB " + me.gren, W * 0.70f, H * 0.64f + R(36), R(10), 0xFFFFFFFF, Paint.Align.CENTER);
        // heal row
        String[] hs = {"BAND", "AID", "KIT", "DRINK", "PILL"};
        for (int k = 0; k < 5; k++) {
            float hxx = W * (0.40f + k * 0.06f), hyy = H * 0.19f;
            p.setStyle(Paint.Style.FILL); p.setColor(me.heals[k] > 0 ? 0x88206020 : 0x55000000);
            c.drawCircle(hxx, hyy, R(20), p);
            text(c, hs[k], hxx, hyy - R(1), R(8), 0xFFFFFFFF, Paint.Align.CENTER);
            text(c, "x" + me.heals[k], hxx, hyy + R(9), R(9), 0xFFFFE070, Paint.Align.CENTER);
        }
        // timers
        if (me.reloadT > 0 || me.useT > 0) {
            float tot = me.reloadT > 0 ? g.reload : com.dhaka.battlezone.W.HEAL_TIME[Math.max(0, me.useKind)];
            float cur = me.reloadT > 0 ? me.reloadT : me.useT;
            float fr = 1f - cur / Math.max(0.1f, tot);
            box(c, W * 0.40f, H * 0.62f, W * 0.60f, H * 0.62f + R(8), 0x88000000);
            box(c, W * 0.40f, H * 0.62f, W * 0.40f + W * 0.2f * fr, H * 0.62f + R(8), 0xFFFFC107);
            text(c, me.reloadT > 0 ? "RELOADING" : "USING " + com.dhaka.battlezone.W.HEAL[me.useKind].toUpperCase(), W * 0.5f, H * 0.62f - R(3), R(11), 0xFFFFFFFF, Paint.Align.CENTER);
        }
    }

    void drawMinimap(Canvas c, float x, float y, boolean big) {
        Bitmap bm = Game.minimap;
        World w = Game.world;
        if (bm == null || w == null) return;
        float S = big ? getHeight() * 0.9f : mapSize();
        float l = big ? (getWidth() - S) / 2 : R(8), t = big ? getHeight() * 0.05f : R(8);
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF000000); p.setAlpha(255);
        rf.set(l - R(2), t - R(2), l + S + R(2), t + S + R(2));
        c.drawRoundRect(rf, R(3), R(3), p);
        rf.set(l, t, l + S, t + S);
        p.setAlpha(big ? 255 : 215);
        c.drawBitmap(bm, null, rf, p);
        p.setAlpha(255);
        float k = S / w.size;
        c.save();
        c.clipRect(l, t, l + S, t + S);
        if (Game.mode == 0) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(R(2));
            p.setColor(0xFF2E7BFF); c.drawCircle(l + Game.zx * k, t + Game.zz * k, Game.zr * k, p);
            if (Game.zr > Game.zTr + 1) { p.setColor(0xFFFFFFFF); p.setStrokeWidth(R(1.3f)); c.drawCircle(l + Game.zTx * k, t + Game.zTz * k, Game.zTr * k, p); }
            if (Game.planeOn) {
                p.setColor(0xFFFFAA00); p.setStrokeWidth(R(2));
                c.drawLine(l, t + Game.planeZ * k, l + S, t + Game.planeZ * k, p);
                p.setStyle(Paint.Style.FILL); c.drawCircle(l + Game.planeX * k, t + Game.planeZ * k, R(4), p);
            }
        } else {
            for (Fighter f : Game.fs) {
                if (f == Game.me || !f.alive || f.team != Game.me.team) continue;
                p.setStyle(Paint.Style.FILL); p.setColor(0xFF4CD964); c.drawCircle(l + f.x * k, t + f.z * k, R(3), p);
            }
        }
        Fighter me = Game.me;
        float px = l + me.x * k, py = t + me.z * k;
        c.save();
        c.rotate((float) Math.toDegrees(Game.camYaw), px, py);
        path.reset();
        path.moveTo(px, py - R(7)); path.lineTo(px - R(5), py + R(5)); path.lineTo(px + R(5), py + R(5)); path.close();
        p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFEB3B); c.drawPath(path, p);
        c.restore();
        c.restore();
        if (big) text(c, "TAP TO CLOSE", getWidth() / 2f, t + S + R(14), R(11), 0xFFFFFFFF, Paint.Align.CENTER);
    }
}
