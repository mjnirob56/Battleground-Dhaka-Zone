package com.dhaka.battlezone;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** All menu pages, built in code (lobby, play, wardrobe, career, settings, pause, result). */
public class Menus {
    final MainActivity act;
    final FrameLayout layer;
    int wardTab = 0;
    static final int PANEL = 0xDD0E1216, GREEN = 0xFF00875A, RED = 0xFFD32F2F, GREY = 0xFF3A424A, GOLD = 0xFFFFC107;

    Menus(MainActivity a, FrameLayout l) { act = a; layer = l; }

    int dp(float v) { return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f); }

    GradientDrawable bg(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(r));
        return g;
    }

    Button btn(String t, int color, View.OnClickListener l) {
        Button b = new Button(act);
        b.setText(t); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(bg(color, 8));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        lp.topMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    TextView tv(String t, float sp, int color, boolean bold) {
        TextView v = new TextView(act);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return v;
    }

    LinearLayout col(int w) {
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(10), dp(12), dp(10));
        l.setBackground(bg(PANEL, 12));
        return l;
    }

    void clear() { layer.removeAllViews(); layer.setBackgroundColor(0); layer.setClickable(false); }

    void put(View v, int w, int gravity) {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w <= 0 ? ViewGroup.LayoutParams.WRAP_CONTENT : dp(w), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = gravity;
        lp.setMargins(dp(14), dp(14), dp(14), dp(14));
        layer.addView(v, lp);
    }

    void toast(String s) { Toast.makeText(act, s, Toast.LENGTH_SHORT).show(); }

    // ================================================================= home
    void home() {
        clear();
        act.setHud(false);
        LinearLayout left = col(0);
        left.addView(tv("DHAKA", 26, Color.WHITE, true));
        left.addView(tv("BATTLE ZONE", 18, 0xFF2ECC71, true));
        left.addView(btn(Lang.t("play"), GREEN, v -> play()));
        left.addView(btn(Lang.t("wardrobe"), GREY, v -> wardrobe()));
        left.addView(btn(Lang.t("stats"), GREY, v -> stats()));
        left.addView(btn(Lang.t("settings"), GREY, v -> settings(false)));
        left.addView(btn(Lang.t("quit"), RED, v -> act.finish()));
        put(left, 220, Gravity.START | Gravity.CENTER_VERTICAL);

        LinearLayout right = col(0);
        right.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView face = new ImageView(act);
        if (Game.faceBmp != null) face.setImageBitmap(Game.faceBmp);
        face.setScaleType(ImageView.ScaleType.CENTER_CROP);
        face.setBackground(bg(GREY, 40));
        face.setClipToOutline(true);
        right.addView(face, new LinearLayout.LayoutParams(dp(84), dp(84)));
        TextView name = tv(Cfg.playerName + "  \u270E", 17, Color.WHITE, true);
        name.setOnClickListener(v -> editName());
        name.setPadding(0, dp(8), 0, dp(4));
        right.addView(name);
        right.addView(tv(Lang.t("taka") + ": \u09F3" + Cfg.taka, 15, GOLD, true));
        right.addView(tv(Lang.t("matches") + " " + Cfg.matches + "   " + Lang.t("wins") + " " + Cfg.wins, 12, 0xFFCCCCCC, false));
        put(right, 200, Gravity.END | Gravity.TOP);
    }

    void editName() {
        final EditText et = new EditText(act);
        et.setText(Cfg.playerName); et.setInputType(InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(act).setTitle("Name").setView(et)
            .setPositiveButton("OK", (d, w) -> {
                String s = et.getText().toString().trim();
                if (!s.isEmpty()) { Cfg.playerName = s.length() > 14 ? s.substring(0, 14) : s; Cfg.save(); home(); }
            }).setNegativeButton("Cancel", null).show();
    }

    // ================================================================= play
    void play() {
        clear();
        LinearLayout c = col(0);
        c.addView(tv(Lang.t("play"), 20, Color.WHITE, true));
        c.addView(btn(Lang.t("br"), GREEN, v -> act.startGame(0, 0)));
        c.addView(btn(Lang.t("tdm1"), 0xFF1565C0, v -> act.startGame(1, 1)));
        c.addView(btn(Lang.t("tdm2"), 0xFF1565C0, v -> act.startGame(1, 2)));
        c.addView(btn(Lang.t("tdm3"), 0xFF1565C0, v -> act.startGame(1, 3)));
        c.addView(btn(Lang.t("back"), GREY, v -> home()));
        put(c, 300, Gravity.START | Gravity.CENTER_VERTICAL);

        LinearLayout r = col(0);
        r.addView(tv(Lang.t("loadout"), 15, Color.WHITE, true));
        final String[] names = {"AR-4", "AR-47", "Vector SMG", "PS-12 Pump", "DM-14 Marksman"};
        final Button[] bs = new Button[5];
        for (int i = 0; i < 5; i++) {
            final int k = i;
            bs[i] = btn(names[i], Cfg.tdmLoadout == i ? GREEN : GREY, null);
            bs[i].setOnClickListener(v -> {
                Cfg.tdmLoadout = k; Cfg.save();
                for (int j = 0; j < 5; j++) bs[j].setBackground(bg(Cfg.tdmLoadout == j ? GREEN : GREY, 8));
            });
            r.addView(bs[i]);
        }
        put(r, 220, Gravity.END | Gravity.CENTER_VERTICAL);
    }

    // ================================================================= loading
    void loading() {
        clear();
        ImageView iv = new ImageView(act);
        iv.setImageResource(R.drawable.promo);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        layer.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        TextView t = tv(Lang.t("loading"), 18, Color.WHITE, true);
        t.setBackground(bg(0xAA000000, 8));
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        put(t, 0, Gravity.START | Gravity.BOTTOM);
        layer.setClickable(true);
    }

    // ================================================================= wardrobe
    void wardrobe() {
        clear();
        LinearLayout c = col(0);
        c.addView(tv(Lang.t("wardrobe") + "   \u09F3" + Cfg.taka, 18, GOLD, true));
        LinearLayout tabs = new LinearLayout(act);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = {Lang.t("top"), Lang.t("bottom"), Lang.t("head"), Lang.t("color")};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            Button b = btn(tn[i], wardTab == i ? GREEN : GREY, v -> { wardTab = k; wardrobe(); });
            b.setTextSize(11);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.rightMargin = dp(3);
            b.setLayoutParams(lp);
            tabs.addView(b);
        }
        c.addView(tabs);
        ScrollView sv = new ScrollView(act);
        LinearLayout list = new LinearLayout(act);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        if (wardTab == 0) options(list, Cfg.TOPS, Cfg.TOP_PRICE, "t", Cfg.top, i -> Cfg.top = i);
        else if (wardTab == 1) options(list, Cfg.BOTTOMS, Cfg.BOTTOM_PRICE, "b", Cfg.bottom, i -> Cfg.bottom = i);
        else if (wardTab == 2) options(list, Cfg.HEADS, Cfg.HEAD_PRICE, "h", Cfg.head, i -> Cfg.head = i);
        else {
            list.addView(tv("Top", 12, 0xFFCCCCCC, false));
            list.addView(swatches(Cfg.topColor, i -> Cfg.topColor = i));
            list.addView(tv("Bottom", 12, 0xFFCCCCCC, false));
            list.addView(swatches(Cfg.bottomColor, i -> Cfg.bottomColor = i));
            list.addView(tv("Headwear", 12, 0xFFCCCCCC, false));
            list.addView(swatches(Cfg.headColor, i -> Cfg.headColor = i));
            list.addView(tv("Shoes", 12, 0xFFCCCCCC, false));
            list.addView(swatches(Cfg.shoeColor, i -> Cfg.shoeColor = i));
        }
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        c.addView(sv, slp);
        c.addView(btn(Lang.t("back"), GREY, v -> { Cfg.save(); home(); }));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.START;
        lp.setMargins(dp(10), dp(10), dp(10), dp(10));
        layer.addView(c, lp);
        TextView hint = tv("Your face is on the character. Costumes change the body.", 12, Color.WHITE, false);
        hint.setBackground(bg(0x88000000, 8)); hint.setPadding(dp(8), dp(4), dp(8), dp(4));
        put(hint, 0, Gravity.END | Gravity.BOTTOM);
    }

    interface IntSet { void set(int i); }

    void options(LinearLayout list, String[] names, int[] prices, String key, int selected, IntSet setter) {
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            boolean has = Cfg.has(key + i, prices[i]);
            String label = names[i] + (has ? (selected == i ? "   \u2714" : "") : "   \uD83D\uDD12 \u09F3" + prices[i]);
            list.addView(btn(label, selected == i ? GREEN : (has ? GREY : 0xFF5A4A1A), v -> {
                if (!Cfg.buy(key + k, prices[k])) { toast("Not enough Taka! Play matches to earn more."); return; }
                setter.set(k); Cfg.save(); wardrobe();
            }));
        }
    }

    View swatches(int selected, IntSet setter) {
        LinearLayout row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Cfg.PAL.length; i++) {
            final int k = i;
            View v = new View(act);
            GradientDrawable g = bg(0xFF000000 | Cfg.PAL[i], 6);
            if (i == selected) g.setStroke(dp(3), Color.WHITE);
            v.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(20), dp(26));
            lp.setMargins(dp(2), dp(4), dp(2), dp(8));
            v.setLayoutParams(lp);
            v.setOnClickListener(x -> { setter.set(k); Cfg.save(); wardrobe(); });
            row.addView(v);
        }
        return row;
    }

    // ================================================================= stats
    void stats() {
        clear();
        LinearLayout c = col(0);
        c.addView(tv(Lang.t("stats"), 20, Color.WHITE, true));
        c.addView(tv(Cfg.playerName, 16, 0xFF2ECC71, true));
        c.addView(tv(Lang.t("matches") + ": " + Cfg.matches, 15, Color.WHITE, false));
        c.addView(tv(Lang.t("wins") + ": " + Cfg.wins, 15, Color.WHITE, false));
        c.addView(tv(Lang.t("kills") + ": " + Cfg.kills, 15, Color.WHITE, false));
        c.addView(tv(Lang.t("deaths") + ": " + Cfg.deaths, 15, Color.WHITE, false));
        c.addView(tv(Lang.t("best") + ": " + (Cfg.bestRank > 30 ? "-" : "#" + Cfg.bestRank), 15, Color.WHITE, false));
        c.addView(tv(Lang.t("taka") + ": \u09F3" + Cfg.taka, 15, GOLD, true));
        c.addView(btn(Lang.t("back"), GREY, v -> home()));
        put(c, 260, Gravity.CENTER);
    }

    // ================================================================= settings
    interface SeekCb { void on(int v); }

    View seekRow(String label, int max, int cur, SeekCb cb) {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(0, dp(4), 0, dp(4));
        final TextView t = tv(label + ": " + cur, 13, Color.WHITE, false);
        r.addView(t);
        SeekBar sb = new SeekBar(act);
        sb.setMax(max); sb.setProgress(cur);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { t.setText(label + ": " + p); cb.on(p); Cfg.save(); }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        r.addView(sb);
        return r;
    }

    void settings(boolean fromPause) {
        clear();
        LinearLayout c = col(0);
        c.addView(tv(Lang.t("settings"), 20, Color.WHITE, true));
        ScrollView sv = new ScrollView(act);
        LinearLayout l = new LinearLayout(act);
        l.setOrientation(LinearLayout.VERTICAL);
        sv.addView(l);
        l.addView(seekRow(Lang.t("sens"), 200, (int) (Cfg.sens * 100), v -> Cfg.sens = Math.max(0.1f, v / 100f)));
        l.addView(seekRow(Lang.t("sensads"), 200, (int) (Cfg.sensAds * 100), v -> Cfg.sensAds = Math.max(0.1f, v / 100f)));
        l.addView(seekRow(Lang.t("assist"), 100, Cfg.aimAssist, v -> Cfg.aimAssist = v));
        l.addView(seekRow(Lang.t("hud"), 150, (int) (Cfg.hudScale * 100), v -> Cfg.hudScale = Math.max(0.6f, v / 100f)));
        l.addView(seekRow(Lang.t("volume"), 100, (int) (Cfg.volume * 100), v -> Cfg.volume = v / 100f));
        l.addView(toggle(Lang.t("fpp"), Cfg.fpp, v -> Cfg.fpp = v));
        l.addView(toggle(Lang.t("sound"), Cfg.sound, v -> Cfg.sound = v));
        l.addView(toggle(Lang.t("invert"), Cfg.invertY, v -> Cfg.invertY = v));
        l.addView(toggle(Lang.t("leftfire"), Cfg.leftFire, v -> Cfg.leftFire = v));
        final String[] ql = {"Low", "Medium", "High"};
        final Button qb = btn(Lang.t("quality") + ": " + ql[Cfg.quality], GREY, null);
        qb.setOnClickListener(v -> { Cfg.quality = (Cfg.quality + 1) % 3; Cfg.save(); qb.setText(Lang.t("quality") + ": " + ql[Cfg.quality]); });
        l.addView(qb);
        final Button fb = btn(Lang.t("fps") + ": " + Cfg.fpsCap, GREY, null);
        fb.setOnClickListener(v -> { Cfg.fpsCap = Cfg.fpsCap == 60 ? 30 : 60; Cfg.save(); fb.setText(Lang.t("fps") + ": " + Cfg.fpsCap); });
        l.addView(fb);
        final String[] bl = {"Easy", "Normal", "Hard"};
        final Button bb = btn(Lang.t("bots") + ": " + bl[Cfg.botLevel], GREY, null);
        bb.setOnClickListener(v -> { Cfg.botLevel = (Cfg.botLevel + 1) % 3; Cfg.save(); bb.setText(Lang.t("bots") + ": " + bl[Cfg.botLevel]); });
        l.addView(bb);
        l.addView(btn(Lang.t("lang") + ": " + (Cfg.lang == 0 ? "English" : "\u09AC\u09BE\u0982\u09B2\u09BE"), GREY, v -> { Cfg.lang = 1 - Cfg.lang; Cfg.save(); settings(fromPause); }));
        c.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        c.addView(btn(Lang.t("back"), GREY, v -> { Cfg.save(); if (fromPause) pause(); else home(); }));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(380), ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.setMargins(dp(10), dp(10), dp(10), dp(10));
        layer.addView(c, lp);
    }

    interface BoolSet { void set(boolean v); }

    Button toggle(String label, boolean cur, BoolSet s) {
        final Button b = btn(label + ": " + (cur ? "ON" : "OFF"), cur ? GREEN : GREY, null);
        final boolean[] st = {cur};
        b.setOnClickListener(v -> {
            st[0] = !st[0]; s.set(st[0]); Cfg.save();
            b.setText(label + ": " + (st[0] ? "ON" : "OFF")); b.setBackground(bg(st[0] ? GREEN : GREY, 8));
        });
        return b;
    }

    // ================================================================= pause / result
    void pause() {
        clear();
        act.setHud(false);
        layer.setBackgroundColor(0x88000000);
        layer.setClickable(true);
        LinearLayout c = col(0);
        c.addView(tv("PAUSED", 20, Color.WHITE, true));
        c.addView(btn(Lang.t("resume"), GREEN, v -> act.resumeGame()));
        c.addView(btn(Lang.t("settings"), GREY, v -> settings(true)));
        c.addView(btn(Lang.t("leave"), RED, v -> act.leaveMatch()));
        put(c, 260, Gravity.CENTER);
    }

    void result() {
        clear();
        act.setHud(false);
        layer.setBackgroundColor(0x99000000);
        layer.setClickable(true);
        LinearLayout c = col(0);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.addView(tv(Game.resWin ? Lang.t("win") : Lang.t("lose"), 22, Game.resWin ? GOLD : Color.WHITE, true));
        if (Game.resMode == 0) c.addView(tv(Lang.t("rank") + " #" + Game.resRank + " / 30", 16, Color.WHITE, true));
        c.addView(tv(Lang.t("kills") + ": " + Game.resKills + "    " + Lang.t("damage") + ": " + Game.resDamage, 14, Color.WHITE, false));
        c.addView(tv(Lang.t("time") + ": " + (Game.resTime / 60) + "m " + (Game.resTime % 60) + "s", 14, Color.WHITE, false));
        c.addView(tv("+ \u09F3" + Game.resTaka, 20, GOLD, true));
        c.addView(btn(Lang.t("again"), GREEN, v -> act.startGame(Game.resMode, Game.mapId)));
        c.addView(btn(Lang.t("lobby"), GREY, v -> act.toLobby()));
        put(c, 300, Gravity.CENTER);
    }
}
