package com.dhaka.battlezone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** OpenGL ES 2.0 renderer: sky, procedural-material world, smooth characters, shadows, effects. */
public class Renderer implements GLSurfaceView.Renderer {
    static final String VS =
        "uniform mat4 uMVP; uniform mat4 uModel; uniform mat4 uRot;\n" +
        "attribute vec3 aPos; attribute vec3 aNor; attribute vec3 aCol; attribute float aMat; attribute vec2 aUV;\n" +
        "varying vec3 vCol; varying vec3 vNor; varying vec3 vWorld; varying float vMat; varying vec2 vUV;\n" +
        "void main(){ vec4 w = uModel * vec4(aPos,1.0); vWorld = w.xyz; vNor = (uRot * vec4(aNor,0.0)).xyz;\n" +
        " vCol = aCol; vMat = aMat; vUV = aUV; gl_Position = uMVP * vec4(aPos,1.0); }\n";

    static final String FS =
        "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
        "uniform vec3 uTint; uniform vec3 uSun; uniform vec3 uFog; uniform vec2 uFogRange; uniform vec3 uCam;\n" +
        "uniform sampler2D uTex; uniform sampler2D uSign; uniform sampler2D uShadow;\n" +
        "uniform float uTime; uniform float uEmis; uniform float uAlpha; uniform float uLite;\n" +
        "varying vec3 vCol; varying vec3 vNor; varying vec3 vWorld; varying float vMat; varying vec2 vUV;\n" +
        "float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }\n" +
        "float noise(vec2 p){\n" +
        " vec2 i = floor(p); vec2 f = fract(p); f = f*f*(3.0-2.0*f);\n" +
        " float a = hash(i); float b = hash(i+vec2(1.0,0.0)); float c = hash(i+vec2(0.0,1.0)); float d = hash(i+vec2(1.0,1.0));\n" +
        " return mix(mix(a,b,f.x), mix(c,d,f.x), f.y);\n" +
        "}\n" +
        "void main(){\n" +
        " vec3 n = normalize(vNor);\n" +
        " vec3 L = normalize(uSun);\n" +
        " vec3 V = normalize(uCam - vWorld);\n" +
        " float dist = length(vWorld - uCam);\n" +
        " float fogf = clamp((dist - uFogRange.x) / (uFogRange.y - uFogRange.x), 0.0, 1.0);\n" +
        " if (vMat > 5.5 && vMat < 6.5) {\n" +
        "  float sa = texture2D(uShadow, vUV).a * uAlpha * (1.0 - fogf);\n" +
        "  gl_FragColor = vec4(0.0, 0.0, 0.04, sa);\n" +
        "  return;\n" +
        " }\n" +
        " vec3 base = vCol * uTint;\n" +
        " float spec = 0.0;\n" +
        " vec2 xz = vWorld.xz;\n" +
        " if (vMat > 4.5 && vMat < 5.5) {\n" +
        "  base = texture2D(uTex, vUV).rgb * uTint;\n" +
        " } else if (vMat > 6.5 && vMat < 7.5) {\n" +
        "  base = texture2D(uSign, vUV).rgb;\n" +
        " } else if (vMat > 0.5 && vMat < 1.5) {\n" +
        "  if (abs(n.y) < 0.5) {\n" +
        "   float along = vWorld.x + vWorld.z;\n" +
        "   float cu = along / 3.0; float cv = vWorld.y / 3.2;\n" +
        "   vec2 cell = vec2(floor(cu), floor(cv));\n" +
        "   vec2 f = vec2(fract(cu), fract(cv));\n" +
        "   float up = step(3.0, vWorld.y);\n" +
        "   float inWin = step(0.2, f.x) * step(f.x, 0.72) * step(0.3, f.y) * step(f.y, 0.82) * up;\n" +
        "   float inFrame = step(0.13, f.x) * step(f.x, 0.79) * step(0.23, f.y) * step(f.y, 0.89) * up;\n" +
        "   float hh = hash(cell);\n" +
        "   vec3 glass = mix(vec3(0.13,0.18,0.25), vec3(0.42,0.52,0.62), hh * 0.7);\n" +
        "   if (hash(cell + 7.3) > 0.72) glass = vec3(0.55,0.36,0.30) * (0.6 + 0.4 * hh);\n" +
        "   base = mix(base, base * 1.18 + 0.04, inFrame);\n" +
        "   base = mix(base, glass, inWin * 0.92);\n" +
        "   spec += inWin * pow(max(dot(reflect(-L, n), V), 0.0), 18.0) * 0.5;\n" +
        "   base *= 1.0 - 0.18 * step(f.y, 0.07);\n" +
        "   if (uLite < 0.5) {\n" +
        "    base *= 0.80 + 0.35 * noise(vec2(along * 0.35, vWorld.y * 0.25));\n" +
        "    base *= 0.90 + 0.14 * noise(vec2(along * 2.2, vWorld.y * 0.12));\n" +
        "   }\n" +
        "   base *= mix(0.55, 1.0, smoothstep(0.0, 2.4, vWorld.y));\n" +
        "  } else if (n.y > 0.5) {\n" +
        "   float s = 0.5 + 0.5 * sin((vWorld.x + vWorld.z) * 8.0);\n" +
        "   base *= 0.86 + 0.14 * s;\n" +
        "   if (uLite < 0.5) base = mix(base, vec3(0.45,0.25,0.18), smoothstep(0.55, 0.8, noise(xz * 0.6)) * 0.45);\n" +
        "  }\n" +
        " } else if (vMat > 1.5 && vMat < 2.5) {\n" +
        "  if (abs(n.y) < 0.5) {\n" +
        "   float along = vWorld.x + vWorld.z;\n" +
        "   float v = fract(vWorld.y / 3.6); float band = step(0.22, v) * step(v, 0.86);\n" +
        "   float mull = step(fract(along / 1.7), 0.05);\n" +
        "   float gn = 0.5;\n" +
        "   if (uLite < 0.5) gn = noise(vec2(along * 0.15, vWorld.y * 0.08));\n" +
        "   vec3 gcol = mix(vec3(0.26,0.43,0.54), vec3(0.62,0.74,0.82), gn);\n" +
        "   base = mix(base, gcol, band * 0.9);\n" +
        "   base *= 1.0 - 0.35 * mull * band;\n" +
        "   spec += band * pow(max(dot(reflect(-L, n), V), 0.0), 24.0) * 0.8;\n" +
        "   base *= mix(0.7, 1.0, smoothstep(0.0, 3.0, vWorld.y));\n" +
        "  }\n" +
        " } else if (vMat > 2.5 && vMat < 3.5) {\n" +
        "  if (uLite < 0.5) {\n" +
        "  vec3 nn = normalize(vec3(cos(xz.x * 0.7 + uTime * 0.9) * 0.10 + cos(xz.y * 0.37 + uTime * 0.5) * 0.06, 1.0, cos(xz.y * 0.9 - uTime * 0.7) * 0.10));\n" +
        "  float fres = pow(1.0 - max(dot(V, nn), 0.0), 3.0);\n" +
        "  base = mix(vec3(0.14,0.20,0.18), vec3(0.62,0.72,0.78), clamp(fres * 0.85 + 0.12, 0.0, 1.0));\n" +
        "  vec3 H = normalize(V + L);\n" +
        "  spec += pow(max(dot(nn, H), 0.0), 90.0) * 1.3;\n" +
        "  n = nn;\n" +
        "  } else { base = vec3(0.30,0.38,0.38); }\n" +
        " } else if (vMat > 3.5 && vMat < 4.5) {\n" +
        "  if (uLite < 0.5) {\n" +
        "  float nz = noise(xz * 1.4); float sp = hash(floor(xz * 16.0));\n" +
        "  base *= 0.78 + 0.32 * nz + 0.14 * (sp - 0.5);\n" +
        "  float cr = abs(noise(xz * 0.3) - 0.5);\n" +
        "  base *= 1.0 - 0.45 * (1.0 - smoothstep(0.0, 0.015, cr));\n" +
        "  base *= 1.0 - 0.28 * smoothstep(0.60, 0.85, noise(xz * 0.1));\n" +
        "  } else { base *= 0.88; }\n" +
        " } else if (vMat > 7.5 && vMat < 8.5) {\n" +
        "  if (uLite < 0.5) base *= 0.75 + 0.4 * noise(xz * 0.25) + 0.15 * noise(xz * 1.8); else base *= 0.92;\n" +
        " } else if (vMat > 8.5 && vMat < 9.5) {\n" +
        "  if (uLite < 0.5) base = mix(vec3(0.20,0.38,0.14), vec3(0.38,0.52,0.20), noise(xz * 0.45)) * (0.85 + 0.25 * hash(floor(xz * 9.0))); else base = vec3(0.27,0.44,0.17);\n" +
        " } else if (vMat > 9.5 && vMat < 10.5) {\n" +
        "  if (uLite < 0.5) base *= 0.70 + 0.55 * noise(xz * 1.1 + vWorld.y * 1.6);\n" +
        "  base *= 0.8 + 0.3 * n.y;\n" +
        " } else if (vMat > 10.5 && vMat < 11.5) {\n" +
        "  float seam = max(step(fract(xz.x / 1.5), 0.04), step(fract(xz.y / 1.5), 0.04));\n" +
        "  float cn = 1.0;\n" +
        "  if (uLite < 0.5) cn = 0.85 + 0.25 * noise(xz * 3.0);\n" +
        "  base *= cn * (1.0 - 0.25 * seam);\n" +
        " }\n" +
        " float ndl = max(dot(n, L), 0.0);\n" +
        " vec3 sunCol = vec3(1.0, 0.92, 0.78);\n" +
        " vec3 amb = mix(vec3(0.34,0.30,0.27), vec3(0.50,0.58,0.72), n.y * 0.5 + 0.5);\n" +
        " vec3 col = base * (amb * 0.95 + sunCol * ndl * 0.9) + sunCol * spec;\n" +
        " col += base * uEmis;\n" +
        " col = vec3(1.0) - exp(-col * 1.7);\n" +
        " float lum = dot(col, vec3(0.30, 0.59, 0.11));\n" +
        " col = mix(vec3(lum), col, 1.12);\n" +
        " col = mix(col, uFog, fogf);\n" +
        " gl_FragColor = vec4(col, 1.0);\n" +
        "}\n";

    static final String SKY_VS =
        "attribute vec2 aP; varying vec2 vP;\n" +
        "void main(){ vP = aP; gl_Position = vec4(aP, 0.9999, 1.0); }\n";
    static final String SKY_FS =
        "precision mediump float;\n" +
        "varying vec2 vP;\n" +
        "uniform vec3 uFwd; uniform vec3 uRight; uniform vec3 uUp; uniform vec2 uTan; uniform vec3 uSun;\n" +
        "uniform vec3 uHor; uniform vec3 uZen; uniform float uTime;\n" +
        "void main(){\n" +
        " vec3 d = normalize(uFwd + uRight * (vP.x * uTan.x) + uUp * (vP.y * uTan.y));\n" +
        " float h = clamp(d.y, 0.0, 1.0);\n" +
        " vec3 col = mix(uHor, uZen, pow(h, 0.45));\n" +
        " if (d.y < 0.0) col = uHor;\n" +
        " float sd = max(dot(d, normalize(uSun)), 0.0);\n" +
        " col += vec3(1.0, 0.85, 0.6) * pow(sd, 10.0) * 0.30 + vec3(1.0, 0.95, 0.8) * pow(sd, 300.0) * 2.0;\n" +
        " vec2 cp = d.xz / (d.y + 0.2) * 1.3 + vec2(uTime * 0.01, 0.0);\n" +
        " float cl = sin(cp.x * 2.1) * sin(cp.y * 1.7 + 1.0) + 0.5 * sin(cp.x * 4.3 + cp.y * 2.9);\n" +
        " cl = smoothstep(0.35, 1.3, cl) * smoothstep(0.02, 0.3, d.y);\n" +
        " col = mix(col, vec3(0.97), cl * 0.55);\n" +
        " gl_FragColor = vec4(col, 1.0);\n" +
        "}\n";

    static class Xf {
        float[] m = new float[16], r = new float[16];
        void id() { Matrix.setIdentityM(m, 0); Matrix.setIdentityM(r, 0); }
        void set(Xf o) { System.arraycopy(o.m, 0, m, 0, 16); System.arraycopy(o.r, 0, r, 0, 16); }
        void tr(float x, float y, float z) { Matrix.translateM(m, 0, x, y, z); }
        void ry(float deg) { Matrix.rotateM(m, 0, deg, 0, 1, 0); Matrix.rotateM(r, 0, deg, 0, 1, 0); }
        void rx(float deg) { Matrix.rotateM(m, 0, deg, 1, 0, 0); Matrix.rotateM(r, 0, deg, 1, 0, 0); }
    }

    // programs & locations
    int prog, aPos, aNor, aCol, aMat, aUV;
    int uMVP, uModel, uRot, uTint, uSun, uFog, uFogRange, uCam, uTex, uSign, uShadow, uTime, uEmis, uAlpha, uLite;
    int skyProg, aP, sUFwd, sURight, sUUp, sUTan, sUSun, sUHor, sUZen, sUTime;
    // meshes
    int cubeVbo, sphereVbo, headVbo, cylVbo, quadVbo, skyVbo;
    int sphereN, cylN;
    int texWhite, texFace, texSign, texBlob, texRect;
    int attrVbo = -1;
    float[] proj = new float[16], view = new float[16], vp = new float[16], tmp = new float[16], mvp = new float[16], ident = new float[16];
    long lastNs = 0;
    float clock = 0;
    float skinR = 0.8f, skinG = 0.55f, skinB = 0.45f;
    final Xf xr = new Xf(), xh = new Xf(), xt = new Xf(), xa = new Xf(), xl = new Xf(), xk = new Xf(), xd = new Xf(), a3 = new Xf(), a1 = new Xf();
    float fogNear = 110, fogFar = 260;
    float camx, camy, camz, fwx, fwy, fwz;
    static final float HOR_R = 0.80f, HOR_G = 0.80f, HOR_B = 0.75f;
    boolean errShown = false;

    // ---------------------------------------------------------------- setup
    int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0 && Game.glError == null) Game.glError = "Shader compile error:\n" + GLES20.glGetShaderInfoLog(s);
        return s;
    }

    int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0 && Game.glError == null) Game.glError = "Shader link error:\n" + GLES20.glGetProgramInfoLog(p);
        return p;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        prog = program(VS, FS);
        GLES20.glUseProgram(prog);
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aNor = GLES20.glGetAttribLocation(prog, "aNor");
        aCol = GLES20.glGetAttribLocation(prog, "aCol"); aMat = GLES20.glGetAttribLocation(prog, "aMat");
        aUV = GLES20.glGetAttribLocation(prog, "aUV");
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP"); uModel = GLES20.glGetUniformLocation(prog, "uModel");
        uRot = GLES20.glGetUniformLocation(prog, "uRot"); uTint = GLES20.glGetUniformLocation(prog, "uTint");
        uSun = GLES20.glGetUniformLocation(prog, "uSun"); uFog = GLES20.glGetUniformLocation(prog, "uFog");
        uFogRange = GLES20.glGetUniformLocation(prog, "uFogRange"); uCam = GLES20.glGetUniformLocation(prog, "uCam");
        uTex = GLES20.glGetUniformLocation(prog, "uTex"); uSign = GLES20.glGetUniformLocation(prog, "uSign");
        uShadow = GLES20.glGetUniformLocation(prog, "uShadow"); uTime = GLES20.glGetUniformLocation(prog, "uTime");
        uEmis = GLES20.glGetUniformLocation(prog, "uEmis"); uAlpha = GLES20.glGetUniformLocation(prog, "uAlpha");
        uLite = GLES20.glGetUniformLocation(prog, "uLite");
        GLES20.glUniform1i(uTex, 0); GLES20.glUniform1i(uSign, 1); GLES20.glUniform1i(uShadow, 2);
        GLES20.glUniform1f(uAlpha, 0.3f);

        skyProg = program(SKY_VS, SKY_FS);
        aP = GLES20.glGetAttribLocation(skyProg, "aP");
        sUFwd = GLES20.glGetUniformLocation(skyProg, "uFwd"); sURight = GLES20.glGetUniformLocation(skyProg, "uRight");
        sUUp = GLES20.glGetUniformLocation(skyProg, "uUp"); sUTan = GLES20.glGetUniformLocation(skyProg, "uTan");
        sUSun = GLES20.glGetUniformLocation(skyProg, "uSun"); sUHor = GLES20.glGetUniformLocation(skyProg, "uHor");
        sUZen = GLES20.glGetUniformLocation(skyProg, "uZen"); sUTime = GLES20.glGetUniformLocation(skyProg, "uTime");

        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        Matrix.setIdentityM(ident, 0);
        attrVbo = -1;
        enableAttribs();
        cubeVbo = makeCube();
        makeSphere();
        makeCyl();
        makeQuad();
        float[] sq = {-1, -1, 1, -1, -1, 1, 1, 1};
        skyVbo = upload(sq, 8);

        int[] t = new int[5];
        GLES20.glGenTextures(5, t, 0);
        texWhite = t[0]; texFace = t[1]; texSign = t[2]; texBlob = t[3]; texRect = t[4];
        Bitmap w1 = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        w1.eraseColor(0xFFFFFFFF);
        setTex(texWhite, w1);
        setTex(texFace, buildAtlas());
        setTex(texSign, buildSigns());
        setTex(texBlob, softTex(false));
        setTex(texRect, softTex(true));
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texSign);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texBlob);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        if (Game.menuWorld != null) Game.menuWorld.vbo = null;
        if (Game.world != null) Game.world.vbo = null;
        lastNs = 0;
    }

    void enableAttribs() {
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glEnableVertexAttribArray(aNor);
        GLES20.glEnableVertexAttribArray(aCol); GLES20.glEnableVertexAttribArray(aMat);
        GLES20.glEnableVertexAttribArray(aUV);
    }

    void setTex(int id, Bitmap b) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
    }

    Bitmap buildAtlas() {
        Bitmap atlas = Bitmap.createBitmap(256, 128, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(atlas);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        int skin = 0xFFC8946F;
        if (Game.faceBmp != null) {
            Bitmap f = Game.faceBmp;
            c.drawBitmap(f, new Rect(0, 0, f.getWidth(), f.getHeight()), new Rect(0, 0, 128, 128), p);
            skin = f.getPixel(f.getWidth() / 2, (int) (f.getHeight() * 0.62f)) | 0xFF000000;
        }
        skinR = ((skin >> 16) & 255) / 255f; skinG = ((skin >> 8) & 255) / 255f; skinB = (skin & 255) / 255f;
        p.setColor(skin);
        c.drawRect(128, 0, 256, 128, p);
        p.setColor(0xFF161312);
        c.drawRect(128, 0, 256, 52, p);
        return atlas;
    }

    Bitmap buildSigns() {
        Bitmap b = Bitmap.createBitmap(512, 256, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        String[] txt = {"\u09A2\u09BE\u0995\u09BE \u09AB\u09BE\u09B0\u09CD\u09AE\u09C7\u09B8\u09BF", "\u09B0\u09B9\u09BF\u09AE \u09B8\u09CD\u099F\u09CB\u09B0", "\u09B9\u09CB\u099F\u09C7\u09B2 \u09B8\u09C1\u09B2\u09A4\u09BE\u09A8",
            "\u09AE\u09CB\u09AC\u09BE\u0987\u09B2 \u09AC\u09BE\u099C\u09BE\u09B0", "\u09AC\u09BF\u09B0\u09BF\u09AF\u09BC\u09BE\u09A8\u09BF \u09B9\u09BE\u0989\u09B8", "\u09B8\u09CB\u09A8\u09BE\u09B2\u09C0 \u09AC\u09CD\u09AF\u09BE\u0982\u0995",
            "\u099A\u09BE \u2022 \u09A8\u09BE\u09B8\u09CD\u09A4\u09BE", "\u0995\u09BE\u099A\u09CD\u099A\u09BF \u09AD\u09BE\u0987", "\u0995\u09BE\u09AA\u09DC\u09C7\u09B0 \u09A6\u09CB\u0995\u09BE\u09A8",
            "\u099C\u09C7\u09A8\u09BE\u09B0\u09C7\u09B2 \u09B8\u09CD\u099F\u09CB\u09B0", "\u09A2\u09BE\u0995\u09BE \u0995\u09CD\u09B2\u09BF\u09A8\u09BF\u0995", "\u09AE\u09BF\u09B7\u09CD\u099F\u09BF \u0998\u09B0",
            "\u09B8\u09A6\u09B0\u0998\u09BE\u099F", "\u09AC\u0987 \u09AE\u09BE\u09B0\u09CD\u0995\u09C7\u099F", "\u0987\u09B2\u09C7\u0995\u099F\u09CD\u09B0\u09A8\u09BF\u0995\u09CD\u09B8", "\u09AB\u09C1\u09B2 \u2022 \u09AB\u09B2"};
        int[] bg = {0xFF1B7F4B, 0xFFC62828, 0xFF1565C0, 0xFFEF6C00, 0xFF8E1B1B, 0xFF0D2A5E, 0xFF5D4037, 0xFF7B1F2B,
            0xFF6A1B9A, 0xFF00796B, 0xFFF5F5F5, 0xFFD81B60, 0xFF1E88E5, 0xFF6B7A1E, 0xFF111111, 0xFF2E7D32};
        int[] fg = {0xFFFFFFFF, 0xFFFFF59D, 0xFFFFFFFF, 0xFF1B1B1B, 0xFFFFE082, 0xFFFFD54F, 0xFFFFFFFF, 0xFFFFD54F,
            0xFFFFFFFF, 0xFFFFFFFF, 0xFF1B7F4B, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFEB3B, 0xFFFFFFFF};
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        for (int i = 0; i < 16; i++) {
            int cx = (i % 4) * 128, cy = (i / 4) * 64;
            p.setColor(bg[i]);
            c.drawRect(cx, cy, cx + 128, cy + 64, p);
            p.setColor(0x55FFFFFF);
            c.drawRect(cx + 3, cy + 3, cx + 125, cy + 5, p);
            c.drawRect(cx + 3, cy + 59, cx + 125, cy + 61, p);
            p.setColor(fg[i]);
            float size = 30f;
            p.setTextSize(size);
            while (p.measureText(txt[i]) > 116f && size > 10f) { size -= 1.5f; p.setTextSize(size); }
            c.drawText(txt[i], cx + 64, cy + 32 + size * 0.34f, p);
        }
        return b;
    }

    Bitmap softTex(boolean rect) {
        int n = 64;
        Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        int[] px = new int[n * n];
        for (int y = 0; y < n; y++)
            for (int x = 0; x < n; x++) {
                float u = (x + 0.5f) / n, v = (y + 0.5f) / n, a;
                if (rect) {
                    float e = Math.min(Math.min(u, 1 - u), Math.min(v, 1 - v));
                    a = Math.min(1f, e / 0.22f);
                    a = a * a * (3 - 2 * a);
                } else {
                    float dx = u - 0.5f, dy = v - 0.5f;
                    float r = (float) Math.sqrt(dx * dx + dy * dy) * 2f;
                    a = Math.max(0f, 1f - r);
                    a = a * a * (3 - 2 * a);
                }
                px[y * n + x] = ((int) (a * 255) << 24);
            }
        b.setPixels(px, 0, n, 0, 0, n, n);
        return b;
    }

    // ---------------------------------------------------------------- meshes
    int makeCube() {
        float[][] n = {{0, 1, 0}, {0, -1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
        float[] v = new float[36 * 12];
        int k = 0;
        for (int f = 0; f < 6; f++) {
            float nx = n[f][0], ny = n[f][1], nz = n[f][2];
            float ax, ay, az, bx, by, bz;
            if (f < 2) { ax = 1; ay = 0; az = 0; bx = 0; by = 0; bz = 1; }
            else if (f < 4) { ax = 0; ay = 0; az = 1; bx = 0; by = 1; bz = 0; }
            else { ax = 1; ay = 0; az = 0; bx = 0; by = 1; bz = 0; }
            float[][] q = {{-1, -1}, {1, -1}, {1, 1}, {-1, -1}, {1, 1}, {-1, 1}};
            for (int i = 0; i < 6; i++) {
                float s = q[i][0], t = q[i][1];
                v[k++] = nx * 0.5f + ax * s * 0.5f + bx * t * 0.5f;
                v[k++] = ny * 0.5f + ay * s * 0.5f + by * t * 0.5f;
                v[k++] = nz * 0.5f + az * s * 0.5f + bz * t * 0.5f;
                v[k++] = nx; v[k++] = ny; v[k++] = nz;
                v[k++] = 1; v[k++] = 1; v[k++] = 1;
                v[k++] = 0; v[k++] = 0; v[k++] = 0;
            }
        }
        return upload(v, v.length);
    }

    float[] sv(float[] a, int i, float x, float y, float z, float nx, float ny, float nz, float u, float w, float mat) {
        a[i] = x; a[i + 1] = y; a[i + 2] = z; a[i + 3] = nx; a[i + 4] = ny; a[i + 5] = nz;
        a[i + 6] = 1; a[i + 7] = 1; a[i + 8] = 1; a[i + 9] = mat; a[i + 10] = u; a[i + 11] = w;
        return a;
    }

    /** Smooth unit sphere (diameter 1). headVbo = same sphere with the face photo projected on the front. */
    void makeSphere() {
        int seg = 10, rings = 7;
        float[] v = new float[seg * rings * 6 * 12];
        float[] h = new float[seg * rings * 6 * 12];
        int k = 0;
        for (int i = 0; i < rings; i++) {
            double t0 = Math.PI * i / rings, t1 = Math.PI * (i + 1) / rings;
            for (int j = 0; j < seg; j++) {
                double p0 = 2 * Math.PI * j / seg, p1 = 2 * Math.PI * (j + 1) / seg;
                double[][] q = {{t0, p0}, {t0, p1}, {t1, p1}, {t0, p0}, {t1, p1}, {t1, p0}};
                for (double[] a : q) {
                    float x = (float) (0.5 * Math.sin(a[0]) * Math.cos(a[1])), y = (float) (0.5 * Math.cos(a[0])), z = (float) (0.5 * Math.sin(a[0]) * Math.sin(a[1]));
                    sv(v, k, x, y, z, x * 2, y * 2, z * 2, 0, 0, 0);
                    float u, w;
                    if (z <= 0.02f) { u = 0.25f - 0.5f * x; w = 0.5f - y; }
                    else { u = 0.75f; w = 0.5f - y; }
                    sv(h, k, x, y, z, x * 2, y * 2, z * 2, u, w, 5);
                    k += 12;
                }
            }
        }
        sphereN = k / 12;
        sphereVbo = upload(v, k);
        headVbo = upload(h, k);
    }

    /** Cylinder along Z, radius 0.5, length 1. */
    void makeCyl() {
        int seg = 14;
        float[] v = new float[seg * 12 * 12];
        int k = 0;
        for (int j = 0; j < seg; j++) {
            double p0 = 2 * Math.PI * j / seg, p1 = 2 * Math.PI * (j + 1) / seg;
            float x0 = (float) (0.5 * Math.cos(p0)), y0 = (float) (0.5 * Math.sin(p0)), x1 = (float) (0.5 * Math.cos(p1)), y1 = (float) (0.5 * Math.sin(p1));
            float[][] side = {{x0, y0, -0.5f, x0 * 2, y0 * 2}, {x1, y1, -0.5f, x1 * 2, y1 * 2}, {x1, y1, 0.5f, x1 * 2, y1 * 2},
                {x0, y0, -0.5f, x0 * 2, y0 * 2}, {x1, y1, 0.5f, x1 * 2, y1 * 2}, {x0, y0, 0.5f, x0 * 2, y0 * 2}};
            for (float[] s : side) { sv(v, k, s[0], s[1], s[2], s[3], s[4], 0, 0, 0, 0); k += 12; }
            sv(v, k, 0, 0, 0.5f, 0, 0, 1, 0, 0, 0); k += 12; sv(v, k, x0, y0, 0.5f, 0, 0, 1, 0, 0, 0); k += 12; sv(v, k, x1, y1, 0.5f, 0, 0, 1, 0, 0, 0); k += 12;
            sv(v, k, 0, 0, -0.5f, 0, 0, -1, 0, 0, 0); k += 12; sv(v, k, x0, y0, -0.5f, 0, 0, -1, 0, 0, 0); k += 12; sv(v, k, x1, y1, -0.5f, 0, 0, -1, 0, 0, 0); k += 12;
        }
        cylN = k / 12;
        cylVbo = upload(v, k);
    }

    void makeQuad() {
        float[] v = new float[6 * 12];
        float[][] q = {{-.5f, -.5f, 0, 0}, {.5f, -.5f, 1, 0}, {.5f, .5f, 1, 1}, {-.5f, -.5f, 0, 0}, {.5f, .5f, 1, 1}, {-.5f, .5f, 0, 1}};
        for (int i = 0; i < 6; i++) sv(v, i * 12, q[i][0], 0, q[i][1], 0, 1, 0, q[i][2], q[i][3], 6);
        quadVbo = upload(v, v.length);
    }

    int upload(float[] arr, int n) {
        int[] id = new int[1];
        GLES20.glGenBuffers(1, id, 0);
        FloatBuffer fb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(arr, 0, n).position(0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, id[0]);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 4, fb, GLES20.GL_STATIC_DRAW);
        attrVbo = -1;
        return id[0];
    }

    void uploadWorld(World w) {
        w.vbo = new int[w.cv.length];
        for (int i = 0; i < w.cv.length; i++) if (w.cv[i] != null && w.cvn[i] > 0) w.vbo[i] = upload(w.cv[i], w.cvn[i]);
        w.signVbo = w.svn > 0 ? upload(w.sv, w.svn) : 0;
        w.shadowVbo = w.shvn > 0 ? upload(w.shv, w.shvn) : 0;
    }

    void bindMesh(int vbo) {
        if (attrVbo == vbo) return;
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 48, 0);
        GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 48, 12);
        GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 48, 24);
        GLES20.glVertexAttribPointer(aMat, 1, GLES20.GL_FLOAT, false, 48, 36);
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 48, 40);
        attrVbo = vbo;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        Game.aspect = width / (float) Math.max(1, height);
    }

    // ---------------------------------------------------------------- frame
    @Override
    public void onDrawFrame(GL10 gl) {
        try {
            frame();
        } catch (Throwable t) {
            if (Game.glError == null) Game.glError = "Render error: " + t;
        }
    }

    void frame() {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : (now - lastNs) / 1e9f;
        lastNs = now;
        if (dt > 0.1f) dt = 0.1f;
        clock += dt;
        Game.ensureMenu();
        if (Game.pendingMode >= 0) {
            int m = Game.pendingMode, mp = Game.pendingMap;
            Game.pendingMode = -1;
            try { Game.startMatch(m, mp); } catch (Throwable t) {
                Game.loading = false; Game.state = Game.MENU; Game.world = Game.menuWorld;
                if (Game.glError == null) Game.glError = "Match start error: " + t;
            }
        }
        World w = Game.world;
        if (w == null) return;
        if (w.vbo == null) uploadWorld(w);
        boolean play = Game.state == Game.PLAY || Game.state == Game.RESULT;
        if (Game.state == Game.PLAY) Game.update(dt);
        float fov;
        if (play) {
            camx = Game.camX; camy = Game.camY; camz = Game.camZ;
            float yaw = Game.camYaw, pit = Game.camPitch;
            fwx = (float) (Math.sin(yaw) * Math.cos(pit)); fwy = (float) Math.sin(pit); fwz = (float) (-Math.cos(yaw) * Math.cos(pit));
            fov = Game.fov;
        } else {
            Game.preview.byaw += dt * 0.7f;
            Game.costume(Game.preview, true);
            camx = 80; camy = 1.25f; camz = 54.2f;
            fwx = 0; fwy = 0.03f; fwz = -1;
            fov = 42f;
        }
        fogFar = Cfg.quality == 0 ? 170 : (Cfg.quality == 1 ? 260 : 340);
        fogNear = Cfg.quality == 0 ? 60 : (Cfg.quality == 1 ? 90 : 130);
        GLES20.glClearColor(HOR_R, HOR_G, HOR_B, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.perspectiveM(proj, 0, fov, Game.aspect, 0.12f, 450f);
        Matrix.setLookAtM(view, 0, camx, camy, camz, camx + fwx, camy + fwy, camz + fwz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        drawSky(fov);

        GLES20.glUseProgram(prog);
        enableAttribs();
        attrVbo = -1;
        GLES20.glUniform3f(uSun, 0.4f, 0.8f, 0.35f);
        GLES20.glUniform3f(uFog, HOR_R, HOR_G, HOR_B);
        GLES20.glUniform2f(uFogRange, fogNear, fogFar);
        GLES20.glUniform3f(uCam, camx, camy, camz);
        GLES20.glUniform1f(uTime, clock);
        GLES20.glUniform1f(uLite, Cfg.quality == 0 ? 1f : 0f);
        GLES20.glUniform1i(uTex, 0); GLES20.glUniform1i(uSign, 1); GLES20.glUniform1i(uShadow, 2);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);

        drawWorld(w);
        drawTraffic(w);
        if (play) {
            drawPickups();
            for (int i = 0; i < Game.fs.size(); i++) {
                Fighter f = Game.fs.get(i);
                if (f == Game.me && f.alive && (Cfg.fpp && f.st == 3)) continue;
                if (f.st == 0) continue;
                float dx = f.x - camx, dz = f.z - camz;
                if (dx * dx + dz * dz > fogFar * fogFar) continue;
                if (f != Game.me && dx * dx + dz * dz > 40f * 40f) drawFighterFar(f, !f.alive);
                else drawFighter(f, !f.alive);
            }
            drawBullets();
            drawEffects();
            if (Game.mode == 0) { drawZone(); if (Game.planeOn) drawPlane(); }
        } else {
            drawFighter(Game.preview, false);
        }
        drawShadows(w, play);
        if (play && Cfg.fpp && Game.me.alive && Game.me.st == 3) drawViewModel(Game.me);

        long spent = System.nanoTime() - now;
        long target = 1000000000L / Math.max(20, Cfg.fpsCap);
        if (spent < target) {
            try { Thread.sleep((target - spent) / 1000000L); } catch (InterruptedException e) { }
        }
    }

    void drawSky(float fov) {
        GLES20.glUseProgram(skyProg);
        float rx = -fwz, rz = fwx, rl = (float) Math.sqrt(rx * rx + rz * rz);
        if (rl < 1e-5f) { rx = 1; rz = 0; rl = 1; }
        rx /= rl; rz /= rl;
        // up = right x forward, right = (rx,0,rz)
        float ux = -rz * fwy, uy = rz * fwx - rx * fwz, uz = rx * fwy;
        float th = (float) Math.tan(Math.toRadians(fov) * 0.5);
        GLES20.glUniform3f(sUFwd, fwx, fwy, fwz);
        GLES20.glUniform3f(sURight, rx, 0, rz);
        GLES20.glUniform3f(sUUp, ux, uy, uz);
        GLES20.glUniform2f(sUTan, th * Game.aspect, th);
        GLES20.glUniform3f(sUSun, 0.4f, 0.8f, 0.35f);
        GLES20.glUniform3f(sUHor, HOR_R, HOR_G, HOR_B);
        GLES20.glUniform3f(sUZen, 0.40f, 0.56f, 0.80f);
        GLES20.glUniform1f(sUTime, clock);
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, skyVbo);
        GLES20.glEnableVertexAttribArray(aP);
        GLES20.glVertexAttribPointer(aP, 2, GLES20.GL_FLOAT, false, 8, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        attrVbo = -1;
    }

    // ---------------------------------------------------------------- draw helpers
    void setTint(float r, float g, float b, float emis) {
        GLES20.glUniform3f(uTint, r, g, b);
        GLES20.glUniform1f(uEmis, emis);
    }

    void draw(Xf x, int vbo, int count, float sx, float sy, float sz, float r, float g, float b, float emis) {
        bindMesh(vbo);
        System.arraycopy(x.m, 0, tmp, 0, 16);
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        Matrix.multiplyMM(mvp, 0, vp, 0, tmp, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, tmp, 0);
        GLES20.glUniformMatrix4fv(uRot, 1, false, x.r, 0);
        setTint(r, g, b, emis);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count);
    }

    void cube(Xf x, float sx, float sy, float sz, float r, float g, float b, float emis) { draw(x, cubeVbo, 36, sx, sy, sz, r, g, b, emis); }

    void box(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, cubeVbo, 36, sx, sy, sz, r, g, b, 0f);
    }

    void boxE(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, cubeVbo, 36, sx, sy, sz, r, g, b, 1f);
    }

    void ell(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, sphereVbo, sphereN, sx, sy, sz, r, g, b, 0f);
    }

    void ellE(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, sphereVbo, sphereN, sx, sy, sz, r, g, b, 1f);
    }

    void cyl(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, cylVbo, cylN, sx, sy, sz, r, g, b, 0f);
    }

    void cylE(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base); a3.tr(cx, cy, cz); draw(a3, cylVbo, cylN, sx, sy, sz, r, g, b, 1f);
    }

    void drawWorld(World w) {
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, ident, 0);
        GLES20.glUniformMatrix4fv(uRot, 1, false, ident, 0);
        setTint(1, 1, 1, 0);
        float range = fogFar + 100f;
        for (int i = 0; i < w.cv.length; i++) {
            if (w.vbo[i] == 0 || w.cvn[i] == 0) continue;
            if (i < w.cv.length - 1) {
                float cx = ((i % w.chunksN) + 0.5f) * World.CH, cz = ((i / w.chunksN) + 0.5f) * World.CH;
                float dx = cx - camx, dz = cz - camz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d > range) continue;
                if (d > 100f && (dx * fwx + dz * fwz) / d < -0.35f) continue;
            }
            bindMesh(w.vbo[i]);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, w.cvn[i] / 12);
        }
        if (w.signVbo != 0) {
            bindMesh(w.signVbo);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, w.svn / 12);
        }
    }

    void drawTraffic(World w) {
        float[] col = new float[3];
        for (int i = 0; i < w.traffic.size(); i++) {
            Vehicle v = w.traffic.get(i);
            float dx = v.x() - camx, dz = v.z() - camz;
            float d2 = dx * dx + dz * dz;
            if (d2 > 110f * 110f) continue;
            boolean near = d2 < 45f * 45f;
            xr.id();
            xr.tr(v.x(), 0, v.z());
            float ang = v.axis == 0 ? (v.dir > 0 ? 0 : 180) : (v.dir > 0 ? -90 : 90);
            xr.ry(ang);
            for (float[] p : VehModel.PARTS[v.type]) {
                int mode = (int) p[6];
                if (!near && mode != 0 && mode != 2) continue;
                VehModel.color(mode, v.cr, v.cg, v.cb, col);
                if (mode == 6) cyl(xr, p[0], p[1], p[2], p[3], p[4], p[5], col[0], col[1], col[2]);
                else if (mode == 7 || mode == 8) boxE(xr, p[0], p[1], p[2], p[3], p[4], p[5], col[0], col[1], col[2]);
                else box(xr, p[0], p[1], p[2], p[3], p[4], p[5], col[0], col[1], col[2]);
            }
        }
        if (w.hasTrain) {
            xr.id();
            xr.tr(w.trainX, w.trainY + 1.7f, w.trainPos);
            cube(xr, 3.2f, 3.0f, 36f, 0.88f, 0.9f, 0.92f, 0f);
            box(xr, 0, 0.3f, 0, 3.22f, 0.8f, 34f, 0.12f, 0.17f, 0.22f);
            box(xr, 0, -0.9f, 0, 3.24f, 0.4f, 36f, 0.0f, 0.5f, 0.3f);
            boxE(xr, 0, 0.1f, w.trainDir > 0 ? 18.05f : -18.05f, 1.2f, 0.4f, 0.1f, 1f, 0.95f, 0.8f);
        }
    }

    void drawPickups() {
        for (int i = 0; i < Game.pickups.size(); i++) {
            Pickup p = Game.pickups.get(i);
            if (!p.alive) continue;
            float dx = p.x - camx, dz = p.z - camz;
            float pd2 = dx * dx + dz * dz;
            if (pd2 > 55f * 55f) continue;
            float bob = (float) Math.sin(clock * 2f + p.x) * 0.08f;
            xr.id();
            xr.tr(p.x, p.y + 0.55f + bob, p.z);
            xr.ry(clock * 40f);
            if (pd2 > 14f * 14f) {
                float fr = p.kind == W.K_GUN ? 0.7f : (p.kind == W.K_AMMO ? 0.95f : (p.kind == W.K_HEAL ? 0.95f : 0.35f));
                float fg = p.kind == W.K_GUN ? 0.7f : (p.kind == W.K_AMMO ? 0.8f : (p.kind == W.K_HEAL ? 0.95f : 0.45f));
                float fb = p.kind == W.K_GUN ? 0.75f : (p.kind == W.K_AMMO ? 0.15f : (p.kind == W.K_HEAL ? 0.95f : 0.5f));
                cube(xr, p.kind == W.K_GUN ? 0.12f : 0.3f, 0.2f, p.kind == W.K_GUN ? 0.8f : 0.3f, fr, fg, fb, 0f);
                xr.id();
                xr.tr(p.x, p.y + 1.25f + bob, p.z);
                cube(xr, 0.12f, 0.12f, 0.12f, p.kind == W.K_GUN ? 1f : 0.4f, p.kind == W.K_GUN ? 0.3f : 0.9f, 0.3f, 1f);
                continue;
            }
            switch (p.kind) {
                case W.K_GUN: drawGun(xr, W.G[p.id]); break;
                case W.K_AMMO: box(xr, 0, 0, 0, 0.3f, 0.2f, 0.3f, 0.95f, 0.8f, 0.15f); box(xr, 0, 0.11f, 0, 0.22f, 0.03f, 0.22f, 0.3f, 0.3f, 0.25f); break;
                case W.K_HEAL: box(xr, 0, 0, 0, 0.32f, 0.22f, 0.28f, 0.95f, 0.95f, 0.95f); box(xr, 0, 0.12f, 0, 0.2f, 0.04f, 0.06f, 0.85f, 0.1f, 0.1f); box(xr, 0, 0.12f, 0, 0.06f, 0.04f, 0.2f, 0.85f, 0.1f, 0.1f); break;
                case W.K_ARMOR: ell(xr, 0, 0, 0, 0.42f, 0.46f, 0.2f, 0.35f, 0.45f, 0.7f); break;
                case W.K_HELMET: ell(xr, 0, 0, 0, 0.36f, 0.26f, 0.36f, 0.3f, 0.5f, 0.3f); break;
                case W.K_GREN: ell(xr, 0, 0, 0, 0.2f, 0.26f, 0.2f, 0.2f, 0.35f, 0.2f); box(xr, 0, 0.16f, 0, 0.05f, 0.06f, 0.05f, 0.6f, 0.6f, 0.6f); break;
                default: cyl(xr, 0, 0, 0, 0.14f, 0.14f, 0.34f, 0.12f, 0.12f, 0.16f); break;
            }
            xr.id();
            xr.tr(p.x, p.y + 1.25f + bob, p.z);
            xr.ry(clock * 90f);
            float mr = p.kind == W.K_GUN ? 1f : (p.kind == W.K_AMMO ? 1f : (p.kind == W.K_HEAL ? 0.2f : 0.3f));
            float mg = p.kind == W.K_GUN ? 0.3f : (p.kind == W.K_AMMO ? 0.8f : (p.kind == W.K_HEAL ? 1f : 0.6f));
            float mb = p.kind == W.K_GUN ? 0.2f : (p.kind == W.K_AMMO ? 0.2f : (p.kind == W.K_HEAL ? 0.4f : 1f));
            cube(xr, 0.12f, 0.12f, 0.12f, mr, mg, mb, 1f);
        }
    }

    void drawBullets() {
        for (int i = 0; i < Game.bullets.size(); i++) {
            Bullet b = Game.bullets.get(i);
            if (b.dist < 4f) continue;
            float hz = (float) Math.sqrt(b.vx * b.vx + b.vz * b.vz);
            float yaw = (float) Math.atan2(b.vx, -b.vz), pit = (float) Math.atan2(b.vy, hz);
            xr.id();
            xr.tr(b.x, b.y, b.z);
            xr.ry((float) Math.toDegrees(-yaw));
            xr.rx((float) Math.toDegrees(pit));
            cube(xr, 0.04f, 0.04f, 1.4f, 1f, 0.9f, 0.45f, 1f);
        }
        for (int i = 0; i < Game.grens.size(); i++) {
            Gren g = Game.grens.get(i);
            xr.id();
            xr.tr(g.x, g.y, g.z);
            ell(xr, 0, 0, 0, 0.2f, 0.25f, 0.2f, 0.2f, 0.3f, 0.2f);
        }
    }

    void drawEffects() {
        for (int i = 0; i < Game.parts.size(); i++) {
            Part p = Game.parts.get(i);
            xr.id();
            xr.tr(p.x, p.y, p.z);
            if (p.glow) ellE(xr, 0, 0, 0, p.size, p.size, p.size, p.r, p.g, p.b);
            else ell(xr, 0, 0, 0, p.size, p.size, p.size, p.r, p.g, p.b);
        }
    }

    void drawZone() {
        if (Game.zr > 700) return;
        int n = 110;
        float seg = (float) (2 * Math.PI * Game.zr / n) + 0.6f;
        for (int k = 0; k < n; k++) {
            float a = (float) (2 * Math.PI * k / n);
            float x = Game.zx + (float) Math.cos(a) * Game.zr, z = Game.zz + (float) Math.sin(a) * Game.zr;
            float dx = x - camx, dz = z - camz;
            if (dx * dx + dz * dz > 330f * 330f) continue;
            xr.id();
            xr.tr(x, 40f, z);
            xr.ry((float) Math.toDegrees(-a));
            cube(xr, 0.3f, 90f, seg, 0.15f, 0.35f, 1f, 0.9f);
        }
    }

    void drawPlane() {
        xr.id();
        xr.tr(Game.planeX, Game.planeY, Game.planeZ);
        xr.ry(-90f);
        cyl(xr, 0, 0, 0, 4.2f, 4.2f, 24f, 0.92f, 0.92f, 0.94f);
        ell(xr, 0, 0, -12f, 4.2f, 4.2f, 4f, 0.92f, 0.92f, 0.94f);
        box(xr, 0, -0.2f, -1f, 26f, 0.4f, 5f, 0.85f, 0.85f, 0.88f);
        box(xr, 0, 2.6f, 10.5f, 0.4f, 5f, 4f, 0.0f, 0.5f, 0.3f);
        box(xr, 0, 0.5f, 10.5f, 9f, 0.3f, 3f, 0.85f, 0.85f, 0.88f);
        box(xr, 0, 0.5f, -10.6f, 3.9f, 1.4f, 2f, 0.1f, 0.15f, 0.2f);
        cyl(xr, 6f, -0.8f, -1f, 1.5f, 1.5f, 3f, 0.4f, 0.4f, 0.42f);
        cyl(xr, -6f, -0.8f, -1f, 1.5f, 1.5f, 3f, 0.4f, 0.4f, 0.42f);
    }

    // ---------------------------------------------------------------- shadows (alpha pass)
    void shadowBlob(float x, float y, float z, float sx, float sz, float alpha) {
        xr.id();
        xr.tr(x, y + 0.09f, z);
        System.arraycopy(xr.m, 0, tmp, 0, 16);
        Matrix.scaleM(tmp, 0, sx, 1f, sz);
        Matrix.multiplyMM(mvp, 0, vp, 0, tmp, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, tmp, 0);
        GLES20.glUniformMatrix4fv(uRot, 1, false, ident, 0);
        GLES20.glUniform1f(uAlpha, alpha);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
    }

    void drawShadows(World w, boolean play) {
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glDepthMask(false);
        setTint(1, 1, 1, 0);
        if (w.shadowVbo != 0) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texRect);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            bindMesh(w.shadowVbo);
            GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0);
            GLES20.glUniformMatrix4fv(uModel, 1, false, ident, 0);
            GLES20.glUniformMatrix4fv(uRot, 1, false, ident, 0);
            GLES20.glUniform1f(uAlpha, 0.30f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, w.shvn / 12);
        }
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texBlob);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        bindMesh(quadVbo);
        if (play) {
            for (int i = 0; i < Game.fs.size(); i++) {
                Fighter f = Game.fs.get(i);
                if (!f.alive || f.st != 3) continue;
                if (f == Game.me && Cfg.fpp) continue;
                float dx = f.x - camx, dz = f.z - camz;
                if (dx * dx + dz * dz > 120f * 120f) continue;
                shadowBlob(f.x - 0.25f, f.y, f.z - 0.22f, 1.5f, 1.5f, 0.55f);
            }
            for (int i = 0; i < Game.pickups.size(); i++) {
                Pickup p = Game.pickups.get(i);
                if (!p.alive) continue;
                float dx = p.x - camx, dz = p.z - camz;
                if (dx * dx + dz * dz > 35f * 35f) continue;
                shadowBlob(p.x, p.y, p.z, 0.8f, 0.8f, 0.35f);
            }
        } else {
            shadowBlob(Game.preview.x - 0.25f, 0f, Game.preview.z - 0.22f, 1.6f, 1.6f, 0.6f);
        }
        for (int i = 0; i < w.traffic.size(); i++) {
            Vehicle v = w.traffic.get(i);
            float dx = v.x() - camx, dz = v.z() - camz;
            if (dx * dx + dz * dz > 120f * 120f) continue;
            shadowBlob(v.x() - 0.4f, 0f, v.z() - 0.35f, v.hx * 2.5f, v.hz * 2.5f, 0.5f);
        }
        GLES20.glDepthMask(true);
        GLES20.glDisable(GLES20.GL_BLEND);
    }

    // ---------------------------------------------------------------- weapons
    void drawGun(Xf b, W.Gun g) {
        float r = g.cr, gg = g.cg, bl = g.cb;
        float dr = r * 0.55f, dg = gg * 0.55f, db = bl * 0.55f;
        switch (g.cls) {
            case 0: {      // pistol
                box(b, 0, 0.03f, -0.10f, 0.045f, 0.055f, 0.22f, r, gg, bl);
                box(b, 0, -0.01f, -0.05f, 0.04f, 0.04f, 0.14f, dr, dg, db);
                a1.set(b); a1.tr(0, -0.07f, 0.0f); a1.rx(-14f); box(a1, 0, 0, 0, 0.04f, 0.11f, 0.05f, 0.12f, 0.1f, 0.1f);
                break;
            }
            case 1: {      // SMG
                box(b, 0, 0.0f, -0.05f, 0.06f, 0.09f, 0.30f, r, gg, bl);
                cyl(b, 0, 0.01f, -0.28f, 0.03f, 0.03f, 0.18f, 0.08f, 0.08f, 0.08f);
                box(b, 0, -0.14f, -0.10f, 0.04f, 0.17f, 0.05f, dr, dg, db);
                a1.set(b); a1.tr(0, -0.08f, 0.06f); a1.rx(-12f); box(a1, 0, 0, 0, 0.04f, 0.11f, 0.05f, 0.1f, 0.1f, 0.1f);
                box(b, 0, 0.0f, 0.2f, 0.03f, 0.05f, 0.2f, dr, dg, db);
                box(b, 0, 0.06f, -0.08f, 0.03f, 0.03f, 0.14f, 0.1f, 0.1f, 0.1f);
                break;
            }
            case 4: {      // shotgun
                box(b, 0, 0.0f, -0.05f, 0.07f, 0.10f, 0.32f, dr, dg, db);
                cyl(b, 0, 0.03f, -0.52f, 0.04f, 0.04f, 0.70f, 0.1f, 0.1f, 0.1f);
                cyl(b, 0, -0.01f, -0.45f, 0.055f, 0.055f, 0.30f, r, gg, bl);
                box(b, 0, -0.04f, 0.26f, 0.06f, 0.12f, 0.30f, r, gg, bl);
                break;
            }
            default: {     // rifles, marksman, sniper, LMG
                float L = g.len;
                box(b, 0, 0.0f, -0.08f, 0.07f, 0.10f, 0.36f, r, gg, bl);
                box(b, 0, -0.005f, -0.42f, 0.075f, 0.08f, 0.30f, dr, dg, db);
                cyl(b, 0, 0.02f, -(0.55f + L) * 0.5f - 0.05f, g.cls == 5 ? 0.04f : 0.028f, g.cls == 5 ? 0.04f : 0.028f, L - 0.5f, 0.07f, 0.07f, 0.08f);
                box(b, 0, -0.03f, 0.26f, 0.05f, 0.12f, 0.28f, dr, dg, db);
                a1.set(b); a1.tr(0, -0.09f, 0.04f); a1.rx(-14f); box(a1, 0, 0, 0, 0.04f, 0.12f, 0.05f, 0.1f, 0.1f, 0.1f);
                a1.set(b); a1.tr(0, -0.14f, -0.16f); a1.rx(g.cls == 2 && g.name.startsWith("AR-47") ? 14f : -6f);
                if (g.cls == 5) box(a1, 0, -0.03f, 0, 0.11f, 0.13f, 0.13f, 0.12f, 0.12f, 0.12f);
                else box(a1, 0, 0, 0, 0.05f, 0.17f, 0.07f, 0.1f, 0.1f, 0.1f);
                if (g.cls == 3) {
                    cyl(b, 0, 0.1f, -0.12f, 0.06f, 0.06f, g.zoom >= 4 ? 0.34f : 0.26f, 0.08f, 0.08f, 0.1f);
                    cylE(b, 0, 0.1f, -0.30f, 0.045f, 0.045f, 0.01f, 0.3f, 0.5f, 0.9f);
                } else {
                    box(b, 0, 0.075f, -0.10f, 0.03f, 0.04f, 0.12f, 0.1f, 0.1f, 0.1f);
                    box(b, 0, 0.075f, -(L - 0.1f), 0.02f, 0.04f, 0.03f, 0.1f, 0.1f, 0.1f);
                }
                if (g.cls == 5) {
                    box(b, 0.04f, -0.12f, -0.62f, 0.02f, 0.18f, 0.02f, 0.1f, 0.1f, 0.1f);
                    box(b, -0.04f, -0.12f, -0.62f, 0.02f, 0.18f, 0.02f, 0.1f, 0.1f, 0.1f);
                }
                break;
            }
        }
    }

    // ---------------------------------------------------------------- characters
    float rad(float deg) { return (float) Math.toRadians(deg); }

    void drawFighter(Fighter f, boolean dead) {
        float tr = Cfg.pr(Cfg.PAL[f.topCol]), tg = Cfg.pg(Cfg.PAL[f.topCol]), tb = Cfg.pb(Cfg.PAL[f.topCol]);
        float br = Cfg.pr(Cfg.PAL[f.bottomCol]), bg = Cfg.pg(Cfg.PAL[f.bottomCol]), bb = Cfg.pb(Cfg.PAL[f.bottomCol]);
        float sr = Cfg.pr(Cfg.PAL[f.shoeCol]), sg = Cfg.pg(Cfg.PAL[f.shoeCol]), sb = Cfg.pb(Cfg.PAL[f.shoeCol]);
        float hr = Cfg.pr(Cfg.PAL[f.headCol]), hg = Cfg.pg(Cfg.PAL[f.headCol]), hb = Cfg.pb(Cfg.PAL[f.headCol]);
        if (f.top == 2) { tr = 0.0f; tg = 0.42f; tb = 0.3f; }
        if (f.top == 4) { tr *= 0.8f; tg *= 0.8f; tb *= 0.8f; }
        float sk = skinR, sg2 = skinG, sb2 = skinB;

        xr.id();
        xr.tr(f.x, f.y, f.z);
        xr.ry((float) Math.toDegrees(-f.byaw));
        float hipY = 0.95f, lean = 0f, thighL = 0f, thighR = 0f, shinL = 0f, shinR = 0f, bob = 0f;
        float walkAmt = 0f;
        if (dead) { xr.tr(0, 0.2f, 0); xr.rx(90f); }
        else if (f.st == 1) { xr.tr(0, 0.95f, 0); xr.rx(-85f); thighL = 10; thighR = -10; }
        else if (f.stance == 2) { xr.tr(0, 0.2f, 0); xr.rx(-80f); thighL = 4; thighR = -4; }
        else if (f.stance == 1) {
            hipY = 0.58f; lean = -12f; thighL = thighR = 70f; shinL = shinR = 105f;
            walkAmt = Math.min(1f, f.speedNow / 2.5f);
            float s = (float) Math.sin(f.walk) * 14f * walkAmt;
            thighL += s; thighR -= s;
        } else {
            walkAmt = Math.min(1f, f.speedNow / 4.5f);
            float s = (float) Math.sin(f.walk) * 38f * walkAmt;
            thighL = s; thighR = -s;
            shinL = Math.max(0f, -thighL) * 1.1f + 4f * walkAmt;
            shinR = Math.max(0f, -thighR) * 1.1f + 4f * walkAmt;
            bob = Math.abs((float) Math.sin(f.walk)) * 0.035f * walkAmt;
            if (f.sprint) lean = -9f;
        }
        Matrix.scaleM(xr.m, 0, 0.94f, 0.94f, 0.94f);
        xh.set(xr); xh.tr(0, hipY + bob, 0);
        xt.set(xh); xt.rx(lean);

        boolean longTop = f.top == 1 || f.top == 3 || f.top == 4;
        // pelvis + legs
        ell(xh, 0, 0.0f, 0, 0.42f, 0.26f, 0.27f, f.bottom == 1 ? br : br, f.bottom == 1 ? bg : bg, f.bottom == 1 ? bb : bb);
        for (int s = -1; s <= 1; s += 2) {
            float ta = s < 0 ? thighL : thighR, ka = s < 0 ? shinL : shinR;
            xl.set(xh); xl.tr(s * 0.12f, -0.02f, 0); xl.rx(ta);
            boolean bare = f.bottom == 1;
            float cr = bare ? sk * 0.95f : br, cg = bare ? sg2 * 0.95f : bg, cb = bare ? sb2 * 0.95f : bb;
            ell(xl, 0, -0.21f, 0, 0.19f, 0.46f, 0.21f, cr, cg, cb);
            xk.set(xl); xk.tr(0, -0.42f, 0); xk.rx(-ka);
            boolean shinSkin = bare || f.bottom == 2;
            ell(xk, 0, -0.20f, 0, 0.15f, 0.44f, 0.17f, shinSkin ? sk * 0.95f : br, shinSkin ? sg2 * 0.95f : bg, shinSkin ? sb2 * 0.95f : bb);
            ell(xk, 0, -0.42f, -0.06f, 0.15f, 0.09f, 0.30f, sr, sg, sb);
            if (f.bottom == 3) box(xl, s * 0.1f, -0.2f, -0.1f, 0.05f, 0.18f, 0.18f, br * 0.8f, bg * 0.8f, bb * 0.8f);
        }
        if (f.bottom == 1) {                  // lungi
            ell(xh, 0, -0.17f, 0, 0.5f, 0.66f, 0.34f, br, bg, bb);
            box(xh, 0, -0.30f, -0.171f, 0.46f, 0.04f, 0.01f, br * 0.6f, bg * 0.6f, bb * 0.6f);
        }
        // torso
        ell(xt, 0, 0.27f, 0, 0.50f, 0.60f, 0.29f, tr, tg, tb);
        if (f.top == 1) ell(xt, 0, -0.2f, 0, 0.52f, 0.62f, 0.33f, tr, tg, tb);                      // panjabi skirt
        if (f.top == 2) { box(xt, 0, 0.36f, -0.145f, 0.16f, 0.16f, 0.02f, 0.85f, 0.1f, 0.1f); box(xt, 0, 0.55f, -0.1f, 0.16f, 0.05f, 0.12f, 0.95f, 0.95f, 0.95f); }
        if (f.top == 3) { ell(xt, 0, 0.52f, 0.12f, 0.34f, 0.2f, 0.2f, tr * 0.85f, tg * 0.85f, tb * 0.85f); box(xt, 0, 0.12f, -0.15f, 0.28f, 0.1f, 0.02f, tr * 0.8f, tg * 0.8f, tb * 0.8f); }
        if (f.top == 4) { ell(xt, 0, 0.3f, 0, 0.54f, 0.5f, 0.33f, 0.2f, 0.22f, 0.18f); for (int i = -1; i <= 1; i++) box(xt, i * 0.14f, 0.2f, -0.17f, 0.1f, 0.12f, 0.06f, 0.16f, 0.18f, 0.14f); }
        if (f.armor > 0 && f.top != 4) {
            float a = f.armor == 1 ? 0.45f : (f.armor == 2 ? 0.55f : 0.2f);
            ell(xt, 0, 0.3f, 0, 0.53f, 0.46f, 0.33f, a, a * 1.05f, a * 0.9f);
        }
        ell(xt, 0, 0.27f, 0.2f, 0.36f, 0.42f, 0.18f, 0.2f, 0.26f, 0.2f);                           // backpack
        ell(xt, 0, 0.58f, 0, 0.12f, 0.14f, 0.12f, sk * 0.9f, sg2 * 0.9f, sb2 * 0.9f);              // neck
        // head
        xd.set(xt); xd.tr(0, 0.66f, 0);
        if (!dead) {
            float hy = (float) Math.toDegrees(-Game.turnDiff(f.byaw, f.yaw));
            hy = Math.max(-55f, Math.min(55f, hy));
            xd.ry(hy);
            xd.rx((float) Math.toDegrees(f.pitch) * 0.6f);
        }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texFace);
        a3.set(xd); a3.tr(0, 0.11f, 0);
        draw(a3, headVbo, sphereN, 0.34f, 0.42f, 0.36f, 1f, 1f, 1f, 0f);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        switch (f.head) {
            case 1: ell(xd, 0, 0.27f, 0, 0.37f, 0.18f, 0.39f, hr, hg, hb); box(xd, 0, 0.2f, -0.2f, 0.28f, 0.03f, 0.16f, hr, hg, hb); break;
            case 2: ell(xd, 0, 0.22f, 0, 0.37f, 0.12f, 0.38f, 0.8f, 0.1f, 0.1f); ell(xd, 0, 0.1f, 0.19f, 0.12f, 0.3f, 0.06f, 0.8f, 0.1f, 0.1f); break;
            case 3: ell(xd, 0, 0.28f, 0, 0.30f, 0.15f, 0.30f, hr, hg, hb); break;
            case 4: ell(xd, 0, 0.2f, 0, 0.36f, 0.08f, 0.37f, hr, hg, hb); ell(xd, 0, 0.14f, 0.2f, 0.1f, 0.14f, 0.06f, hr, hg, hb); break;
            default: break;
        }
        if (f.helmet > 0) {
            float c = f.helmet == 1 ? 0.35f : (f.helmet == 2 ? 0.5f : 0.14f);
            ell(xd, 0, 0.25f, 0, 0.40f, 0.24f, 0.42f, c * 0.8f, c, c * 0.8f);
        }
        // arms + gun
        boolean melee = f.cur == 3;
        W.Gun g = f.gun();
        boolean pistol = g.cls == 0;
        xa.set(xt); xa.tr(0, 0.45f, 0);
        float aim = (float) Math.toDegrees(f.pitch) * 0.9f + (f.sprint ? -25f : 0f);
        if (dead || f.st == 1) aim = 0;
        xa.rx(aim);
        float rs = melee ? 120f : (pistol ? 80f : 62f), re = melee ? 30f : (pistol ? 10f : 38f);
        float ls = melee ? 10f : (pistol ? 80f : 76f), le = melee ? 10f : (pistol ? 10f : 28f);
        float ryR = melee ? 0f : 16f, ryL = melee ? 0f : (pistol ? -16f : -34f);
        if (f.sprint && !melee) { rs = 45f; re = 70f; ls = 50f; le = 65f; }
        if (dead) { rs = 20f; re = 10f; ls = 20f; le = 10f; }
        float sleeve = longTop ? 0.58f : (f.top == 0 || f.top == 2 ? 0.30f : 0.58f);
        for (int s = -1; s <= 1; s += 2) {
            float sa = s > 0 ? rs : ls, ea = s > 0 ? re : le, yy = s > 0 ? ryR : ryL;
            xl.set(xa); xl.tr(s * 0.27f, 0, 0); xl.ry(yy); xl.rx(sa);
            ell(xl, 0, -0.15f, 0, 0.13f, 0.32f, 0.13f, tr, tg, tb);
            xk.set(xl); xk.tr(0, -0.30f, 0); xk.rx(ea);
            boolean shirtFore = sleeve > 0.5f;
            ell(xk, 0, -0.14f, 0, 0.11f, 0.29f, 0.11f, shirtFore ? tr : sk, shirtFore ? tg : sg2, shirtFore ? tb : sb2);
            ell(xk, 0, -0.30f, 0, 0.10f, 0.10f, 0.10f, sk, sg2, sb2);
        }
        if (!dead && f.st != 1) {
            a1.set(xa); a1.tr(0.12f, -0.09f, -0.46f);
            xl.set(a1);
            if (melee) {
                xl.set(xa); xl.tr(0.2f, -0.35f, -0.62f); xl.rx(20f);
                cyl(xl, 0, 0, 0, 0.30f, 0.30f, 0.03f, 0.12f, 0.12f, 0.14f);
                box(xl, 0, -0.2f, 0, 0.04f, 0.22f, 0.04f, 0.2f, 0.15f, 0.1f);
            } else {
                drawGun(xl, g);
                if (f.flash > 0) { xk.set(xl); xk.tr(0, 0.02f, -g.len - 0.1f); ellE(xk, 0, 0, 0, 0.2f, 0.2f, 0.22f, 1f, 0.85f, 0.3f); }
            }
        }
        if (f.st == 2) {
            xl.set(xr); xl.tr(0, 5.8f, 0);
            ell(xl, 0, 0, 0, 5f, 2.2f, 5f, 0.95f, 0.45f, 0.1f);
            box(xr, 0, 3.4f, 0, 0.03f, 4.6f, 0.03f, 0.2f, 0.2f, 0.2f);
        }
        if (f.protectT > 0 && !dead) { ellE(xr, 0, 0.95f, 0, 1.1f, 2.1f, 1.1f, 0.2f, 0.4f, 0.8f); }
    }

    /** Cheap version of a character for distant players (about 7 draw calls). */
    void drawFighterFar(Fighter f, boolean dead) {
        float tr = Cfg.pr(Cfg.PAL[f.topCol]), tg = Cfg.pg(Cfg.PAL[f.topCol]), tb = Cfg.pb(Cfg.PAL[f.topCol]);
        float br = Cfg.pr(Cfg.PAL[f.bottomCol]), bg = Cfg.pg(Cfg.PAL[f.bottomCol]), bb = Cfg.pb(Cfg.PAL[f.bottomCol]);
        if (f.top == 2) { tr = 0.0f; tg = 0.42f; tb = 0.3f; }
        xr.id();
        xr.tr(f.x, f.y, f.z);
        xr.ry((float) Math.toDegrees(-f.byaw));
        if (dead) { xr.tr(0, 0.2f, 0); xr.rx(90f); }
        else if (f.stance == 2) { xr.tr(0, 0.2f, 0); xr.rx(-80f); }
        else if (f.st == 1) { xr.tr(0, 0.95f, 0); xr.rx(-85f); }
        float sc = f.stance == 1 && !dead ? 0.78f : 0.94f;
        Matrix.scaleM(xr.m, 0, 0.94f, sc, 0.94f);
        float sw = (float) Math.sin(f.walk) * Math.min(1f, f.speedNow / 4.5f) * 0.12f;
        ell(xr, -0.11f, 0.47f, sw, 0.19f, 0.94f, 0.21f, br, bg, bb);
        ell(xr, 0.11f, 0.47f, -sw, 0.19f, 0.94f, 0.21f, br, bg, bb);
        ell(xr, 0, 1.22f, 0, 0.50f, 0.62f, 0.29f, tr, tg, tb);
        ell(xr, 0, 1.76f, 0, 0.34f, 0.42f, 0.36f, skinR, skinG, skinB);
        if (!dead && f.st != 1) {
            W.Gun g = f.gun();
            if (f.cur == 3) box(xr, 0.28f, 1.25f, -0.4f, 0.1f, 0.1f, 0.4f, 0.15f, 0.15f, 0.17f);
            else box(xr, 0.13f, 1.28f, -0.45f, 0.07f, 0.1f, Math.max(0.3f, g.len), g.cr, g.cg, g.cb);
        }
    }

    void drawViewModel(Fighter f) {
        if (f.cur == 3) return;
        W.Gun g = f.gun();
        xr.id();
        xr.tr(Game.camX, Game.camY, Game.camZ);
        xr.ry((float) Math.toDegrees(-Game.camYaw));
        xr.rx((float) Math.toDegrees(Game.camPitch));
        if (f.ads) xr.tr(0.0f, -0.13f, -0.3f); else xr.tr(0.2f, -0.2f, -0.3f);
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        drawGun(xr, g);
        float skr = skinR, skg = skinG, skb = skinB;
        ell(xr, 0.0f, -0.12f, -0.15f, 0.09f, 0.09f, 0.2f, skr, skg, skb);
        ell(xr, 0.0f, -0.06f, 0.0f, 0.09f, 0.09f, 0.14f, skr, skg, skb);
        if (f.flash > 0) ellE(xr, 0, 0, -g.len - 0.1f, 0.18f, 0.18f, 0.2f, 1f, 0.85f, 0.3f);
    }
}
