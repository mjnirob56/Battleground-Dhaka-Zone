package com.dhaka.battlezone;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** OpenGL ES 2.0 renderer: static chunked world, box-built characters, vehicles, effects. */
public class Renderer implements GLSurfaceView.Renderer {
    static final String VS =
        "uniform mat4 uMVP; uniform mat4 uModel; uniform mat4 uRot;\n" +
        "attribute vec3 aPos; attribute vec3 aNor; attribute vec3 aCol; attribute float aMat; attribute vec2 aUV;\n" +
        "varying vec3 vCol; varying vec3 vNor; varying vec3 vWorld; varying float vMat; varying vec2 vUV;\n" +
        "void main(){ vec4 w = uModel * vec4(aPos,1.0); vWorld = w.xyz; vNor = (uRot * vec4(aNor,0.0)).xyz;\n" +
        " vCol = aCol; vMat = aMat; vUV = aUV; gl_Position = uMVP * vec4(aPos,1.0); }\n";
    static final String FS =
        "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
        "uniform vec3 uTint; uniform vec3 uSun; uniform vec3 uFog; uniform vec2 uFogRange; uniform vec3 uCam;\n" +
        "uniform sampler2D uTex; uniform float uTime; uniform float uEmis;\n" +
        "varying vec3 vCol; varying vec3 vNor; varying vec3 vWorld; varying float vMat; varying vec2 vUV;\n" +
        "void main(){\n" +
        " vec3 n = normalize(vNor);\n" +
        " vec3 base = vCol * uTint;\n" +
        " if (vMat > 4.5) { base = texture2D(uTex, vUV).rgb * uTint; }\n" +
        " else if (vMat > 0.5 && vMat < 1.5 && abs(n.y) < 0.5) {\n" +
        "  float u = fract((vWorld.x + vWorld.z) / 3.0); float v = fract(vWorld.y / 3.2);\n" +
        "  float win = step(0.2,u)*step(u,0.7)*step(0.35,v)*step(v,0.8);\n" +
        "  base = mix(base, vec3(0.16,0.20,0.27), win*0.85); }\n" +
        " else if (vMat > 1.5 && vMat < 2.5 && abs(n.y) < 0.5) {\n" +
        "  float v = fract(vWorld.y / 3.6); float band = step(0.25,v)*step(v,0.85);\n" +
        "  base = mix(base, vec3(0.28,0.46,0.56), band*0.8); }\n" +
        " else if (vMat > 2.5 && vMat < 3.5) {\n" +
        "  float s = sin(vWorld.x*0.3+uTime)*sin(vWorld.z*0.25+uTime*0.7); base = base*(0.9+0.1*s); }\n" +
        " float diff = max(dot(n, normalize(uSun)), 0.0);\n" +
        " vec3 col = base * (0.55 + 0.5*diff);\n" +
        " float d = length(vWorld - uCam);\n" +
        " float f = clamp((d - uFogRange.x)/(uFogRange.y - uFogRange.x), 0.0, 1.0);\n" +
        " col = mix(col, uFog, f);\n" +
        " gl_FragColor = vec4(col + base*uEmis, 1.0);\n" +
        "}\n";

    static class Xf {
        float[] m = new float[16], r = new float[16];
        void id() { Matrix.setIdentityM(m, 0); Matrix.setIdentityM(r, 0); }
        void set(Xf o) { System.arraycopy(o.m, 0, m, 0, 16); System.arraycopy(o.r, 0, r, 0, 16); }
        void tr(float x, float y, float z) { Matrix.translateM(m, 0, x, y, z); }
        void ry(float deg) { Matrix.rotateM(m, 0, deg, 0, 1, 0); Matrix.rotateM(r, 0, deg, 0, 1, 0); }
        void rx(float deg) { Matrix.rotateM(m, 0, deg, 1, 0, 0); Matrix.rotateM(r, 0, deg, 1, 0, 0); }
    }

    int prog, aPos, aNor, aCol, aMat, aUV;
    int uMVP, uModel, uRot, uTint, uSun, uFog, uFogRange, uCam, uTex, uTime, uEmis;
    int cubeVbo, headVbo, texFace, texWhite, curVbo = -1;
    float[] proj = new float[16], view = new float[16], vp = new float[16], tmp = new float[16], mvp = new float[16], ident = new float[16];
    long lastNs = 0;
    float clock = 0;
    float skinR = 0.8f, skinG = 0.55f, skinB = 0.45f;
    final Xf root = new Xf(), a1 = new Xf(), a2 = new Xf(), a3 = new Xf();
    float fogNear = 110, fogFar = 260;
    float camx, camy, camz, fwx, fwy, fwz;

    // ---------------------------------------------------------------- setup
    int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        int vs = compile(GLES20.GL_VERTEX_SHADER, VS), fs = compile(GLES20.GL_FRAGMENT_SHADER, FS);
        prog = GLES20.glCreateProgram();
        GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs);
        GLES20.glLinkProgram(prog);
        GLES20.glUseProgram(prog);
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aNor = GLES20.glGetAttribLocation(prog, "aNor");
        aCol = GLES20.glGetAttribLocation(prog, "aCol"); aMat = GLES20.glGetAttribLocation(prog, "aMat");
        aUV = GLES20.glGetAttribLocation(prog, "aUV");
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP"); uModel = GLES20.glGetUniformLocation(prog, "uModel");
        uRot = GLES20.glGetUniformLocation(prog, "uRot"); uTint = GLES20.glGetUniformLocation(prog, "uTint");
        uSun = GLES20.glGetUniformLocation(prog, "uSun"); uFog = GLES20.glGetUniformLocation(prog, "uFog");
        uFogRange = GLES20.glGetUniformLocation(prog, "uFogRange"); uCam = GLES20.glGetUniformLocation(prog, "uCam");
        uTex = GLES20.glGetUniformLocation(prog, "uTex"); uTime = GLES20.glGetUniformLocation(prog, "uTime");
        uEmis = GLES20.glGetUniformLocation(prog, "uEmis");
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glEnableVertexAttribArray(aNor);
        GLES20.glEnableVertexAttribArray(aCol); GLES20.glEnableVertexAttribArray(aMat);
        GLES20.glEnableVertexAttribArray(aUV);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        Matrix.setIdentityM(ident, 0);
        curVbo = -1;
        cubeVbo = makeCube(false);
        headVbo = makeCube(true);
        // textures
        int[] t = new int[2];
        GLES20.glGenTextures(2, t, 0);
        texWhite = t[0]; texFace = t[1];
        Bitmap w1 = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        w1.eraseColor(0xFFFFFFFF);
        setTex(texWhite, w1);
        setTex(texFace, buildAtlas());
        if (Game.menuWorld != null) Game.menuWorld.vbo = null;
        if (Game.world != null) Game.world.vbo = null;
        lastNs = 0;
    }

    void setTex(int id, Bitmap b) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
    }

    Bitmap buildAtlas() {
        Bitmap atlas = Bitmap.createBitmap(256, 128, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(atlas);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        int skin = 0xFFC8946F;
        if (Game.faceBmp != null) {
            Bitmap f = Game.faceBmp;
            c.drawBitmap(f, new android.graphics.Rect(0, 0, f.getWidth(), f.getHeight()), new android.graphics.Rect(0, 0, 128, 128), p);
            skin = f.getPixel(f.getWidth() / 2, (int) (f.getHeight() * 0.62f)) | 0xFF000000;
        }
        skinR = ((skin >> 16) & 255) / 255f; skinG = ((skin >> 8) & 255) / 255f; skinB = (skin & 255) / 255f;
        p.setColor(skin);
        c.drawRect(128, 0, 256, 128, p);
        p.setColor(0xFF161312);
        c.drawRect(128, 0, 256, 52, p);
        return atlas;
    }

    /** Unit cube. If head==true the UVs map the front face to the face photo and the rest to hair/skin. */
    int makeCube(boolean head) {
        float[][] n = {{0, 1, 0}, {0, -1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
        float[] v = new float[36 * 12];
        int k = 0;
        for (int f = 0; f < 6; f++) {
            float nx = n[f][0], ny = n[f][1], nz = n[f][2];
            float ax, ay, az, bx, by, bz;   // tangent axes
            if (f < 2) { ax = 1; ay = 0; az = 0; bx = 0; by = 0; bz = 1; }
            else if (f < 4) { ax = 0; ay = 0; az = 1; bx = 0; by = 1; bz = 0; }
            else { ax = 1; ay = 0; az = 0; bx = 0; by = 1; bz = 0; }
            float[][] q = {{-1, -1}, {1, -1}, {1, 1}, {-1, -1}, {1, 1}, {-1, 1}};
            for (int i = 0; i < 6; i++) {
                float s = q[i][0], t = q[i][1];
                float px = nx * 0.5f + ax * s * 0.5f + bx * t * 0.5f;
                float py = ny * 0.5f + ay * s * 0.5f + by * t * 0.5f;
                float pz = nz * 0.5f + az * s * 0.5f + bz * t * 0.5f;
                float u = 0.75f, w = 0.5f - py;
                float mat = 0;
                if (head) {
                    mat = 5;
                    if (f == 5) { u = 0.5f * (0.5f - px); w = 0.5f - py; }   // front (-Z): the face
                    else if (f == 0) { u = 0.75f; w = 0.1f; }
                    else { u = 0.75f; w = 0.5f - py; }
                }
                v[k++] = px; v[k++] = py; v[k++] = pz;
                v[k++] = nx; v[k++] = ny; v[k++] = nz;
                v[k++] = 1; v[k++] = 1; v[k++] = 1;
                v[k++] = mat; v[k++] = u; v[k++] = w;
            }
        }
        return upload(v, v.length);
    }

    int upload(float[] arr, int n) {
        int[] id = new int[1];
        GLES20.glGenBuffers(1, id, 0);
        FloatBuffer fb = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(arr, 0, n).position(0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, id[0]);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 4, fb, GLES20.GL_STATIC_DRAW);
        curVbo = id[0];
        return id[0];
    }

    void uploadWorld(World w) {
        w.vbo = new int[w.cv.length];
        for (int i = 0; i < w.cv.length; i++) if (w.cv[i] != null && w.cvn[i] > 0) w.vbo[i] = upload(w.cv[i], w.cvn[i]);
    }

    void bind(int vbo) {
        if (curVbo != vbo) { GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo); curVbo = vbo; }
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 48, 0);
        GLES20.glVertexAttribPointer(aNor, 3, GLES20.GL_FLOAT, false, 48, 12);
        GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 48, 24);
        GLES20.glVertexAttribPointer(aMat, 1, GLES20.GL_FLOAT, false, 48, 36);
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 48, 40);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        Game.aspect = width / (float) Math.max(1, height);
    }

    // ---------------------------------------------------------------- frame
    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : (now - lastNs) / 1e9f;
        lastNs = now;
        if (dt > 0.1f) dt = 0.1f;
        clock += dt;
        Game.ensureMenu();
        if (Game.pendingMode >= 0) {
            int m = Game.pendingMode, mp = Game.pendingMap;
            Game.pendingMode = -1;
            try { Game.startMatch(m, mp); } catch (Throwable t) { Game.loading = false; Game.state = Game.MENU; Game.world = Game.menuWorld; }
        }
        World w = Game.world;
        if (w == null) return;
        if (w.vbo == null) uploadWorld(w);
        boolean play = Game.state == Game.PLAY || Game.state == Game.RESULT;
        if (Game.state == Game.PLAY) Game.update(dt);
        float fov;
        if (play) {
            camx = Game.camX; camy = Game.camY; camz = Game.camZ;
            float yaw = Game.camYaw, pit = Game.camPitch;
            fwx = (float) (Math.sin(yaw) * Math.cos(pit)); fwy = (float) Math.sin(pit); fwz = (float) (-Math.cos(yaw) * Math.cos(pit));
            fov = Game.fov;
        } else {
            Game.preview.byaw += dt * 0.7f;
            Game.costume(Game.preview, true);
            camx = 80; camy = 1.25f; camz = 54.2f;
            fwx = 0; fwy = 0.03f; fwz = -1;
            fov = 42f;
        }
        fogFar = Cfg.quality == 0 ? 170 : (Cfg.quality == 1 ? 260 : 340);
        fogNear = Cfg.quality == 0 ? 70 : (Cfg.quality == 1 ? 110 : 150);
        float fr = 0.74f, fg = 0.76f, fb = 0.73f;
        GLES20.glClearColor(fr, fg, fb, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.perspectiveM(proj, 0, fov, Game.aspect, 0.12f, 450f);
        Matrix.setLookAtM(view, 0, camx, camy, camz, camx + fwx, camy + fwy, camz + fwz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        GLES20.glUseProgram(prog);
        GLES20.glUniform3f(uSun, 0.4f, 0.8f, 0.35f);
        GLES20.glUniform3f(uFog, fr, fg, fb);
        GLES20.glUniform2f(uFogRange, fogNear, fogFar);
        GLES20.glUniform3f(uCam, camx, camy, camz);
        GLES20.glUniform1f(uTime, clock);
        GLES20.glUniform1i(uTex, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);

        drawWorld(w);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        drawTraffic(w);
        if (play) {
            drawPickups();
            drawBullets();
            drawEffects();
            if (Game.mode == 0) { drawZone(); if (Game.planeOn) drawPlane(); }
            for (int i = 0; i < Game.fs.size(); i++) {
                Fighter f = Game.fs.get(i);
                if (f == Game.me && f.alive && (Cfg.fpp && f.st == 3)) continue;
                if (f.st == 0) continue;
                float dx = f.x - camx, dz = f.z - camz;
                if (dx * dx + dz * dz > fogFar * fogFar) continue;
                drawFighter(f, !f.alive);
            }
            if (Cfg.fpp && Game.me.alive && Game.me.st == 3) drawViewModel(Game.me);
        } else {
            drawFighter(Game.preview, false);
        }
        // frame cap
        long spent = System.nanoTime() - now;
        long target = 1000000000L / Math.max(20, Cfg.fpsCap);
        if (spent < target) {
            try { Thread.sleep((target - spent) / 1000000L); } catch (InterruptedException e) { }
        }
    }

    // ---------------------------------------------------------------- drawing helpers
    void setTint(float r, float g, float b, float emis) {
        GLES20.glUniform3f(uTint, r, g, b);
        GLES20.glUniform1f(uEmis, emis);
    }

    void cube(Xf x, float sx, float sy, float sz, float r, float g, float b, float emis) {
        System.arraycopy(x.m, 0, tmp, 0, 16);
        Matrix.scaleM(tmp, 0, sx, sy, sz);
        Matrix.multiplyMM(mvp, 0, vp, 0, tmp, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, tmp, 0);
        GLES20.glUniformMatrix4fv(uRot, 1, false, x.r, 0);
        setTint(r, g, b, emis);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36);
    }

    /** cube positioned (cx,cy,cz) relative to base transform */
    void part(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base);
        a3.tr(cx, cy, cz);
        cube(a3, sx, sy, sz, r, g, b, 0f);
    }

    void partE(Xf base, float cx, float cy, float cz, float sx, float sy, float sz, float r, float g, float b) {
        a3.set(base);
        a3.tr(cx, cy, cz);
        cube(a3, sx, sy, sz, r, g, b, 1f);
    }

    void drawWorld(World w) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0);
        GLES20.glUniformMatrix4fv(uModel, 1, false, ident, 0);
        GLES20.glUniformMatrix4fv(uRot, 1, false, ident, 0);
        setTint(1, 1, 1, 0);
        float range = fogFar + 100f;
        for (int i = 0; i < w.cv.length; i++) {
            if (w.vbo[i] == 0 || w.cvn[i] == 0) continue;
            if (i < w.cv.length - 1) {
                float cx = ((i % w.chunksN) + 0.5f) * World.CH, cz = ((i / w.chunksN) + 0.5f) * World.CH;
                float dx = cx - camx, dz = cz - camz;
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                if (d > range) continue;
                if (d > 100f && (dx * fwx + dz * fwz) / d < -0.35f) continue;   // behind us
            }
            bind(w.vbo[i]);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, w.cvn[i] / 12);
        }
    }

    void drawTraffic(World w) {
        bind(cubeVbo);
        float[] col = new float[3];
        for (int i = 0; i < w.traffic.size(); i++) {
            Vehicle v = w.traffic.get(i);
            float dx = v.x() - camx, dz = v.z() - camz;
            if (dx * dx + dz * dz > 150f * 150f) continue;
            root.id();
            root.tr(v.x(), 0, v.z());
            float ang = v.axis == 0 ? (v.dir > 0 ? 0 : 180) : (v.dir > 0 ? -90 : 90);
            root.ry(ang);
            for (float[] p : VehModel.PARTS[v.type]) {
                VehModel.color((int) p[6], v.cr, v.cg, v.cb, col);
                a1.set(root);
                a1.tr(p[0], p[1], p[2]);
                cube(a1, p[3], p[4], p[5], col[0], col[1], col[2], 0f);
            }
        }
        if (w.hasTrain) {
            root.id();
            root.tr(w.trainX, w.trainY + 1.7f, w.trainPos);
            cube(root, 3.2f, 3.0f, 36f, 0.88f, 0.9f, 0.92f, 0f);
            a1.set(root); a1.tr(0, 0.3f, 0);
            cube(a1, 3.22f, 0.8f, 34f, 0.12f, 0.17f, 0.22f, 0f);
            a1.set(root); a1.tr(0, -0.9f, 0);
            cube(a1, 3.24f, 0.4f, 36f, 0.0f, 0.5f, 0.3f, 0f);
        }
    }

    void drawPickups() {
        bind(cubeVbo);
        for (int i = 0; i < Game.pickups.size(); i++) {
            Pickup p = Game.pickups.get(i);
            if (!p.alive) continue;
            float dx = p.x - camx, dz = p.z - camz;
            if (dx * dx + dz * dz > 55f * 55f) continue;
            float bob = (float) Math.sin(clock * 2f + p.x) * 0.08f;
            root.id();
            root.tr(p.x, p.y + 0.35f + bob, p.z);
            root.ry(clock * 40f);
            float r, g, b, sx = 0.3f, sy = 0.3f, sz = 0.3f;
            switch (p.kind) {
                case W.K_GUN: r = 0.75f; g = 0.75f; b = 0.8f; sx = 0.12f; sy = 0.12f; sz = 0.8f; break;
                case W.K_AMMO: r = 0.95f; g = 0.8f; b = 0.15f; sx = 0.3f; sy = 0.2f; sz = 0.3f; break;
                case W.K_HEAL: r = 0.95f; g = 0.95f; b = 0.95f; sx = 0.3f; sy = 0.22f; sz = 0.3f; break;
                case W.K_ARMOR: r = 0.35f; g = 0.45f; b = 0.7f; sx = 0.4f; sy = 0.45f; sz = 0.2f; break;
                case W.K_HELMET: r = 0.3f; g = 0.5f; b = 0.3f; sx = 0.35f; sy = 0.25f; sz = 0.35f; break;
                case W.K_GREN: r = 0.2f; g = 0.35f; b = 0.2f; sx = 0.2f; sy = 0.25f; sz = 0.2f; break;
                default: r = 0.15f; g = 0.15f; b = 0.2f; sx = 0.25f; sy = 0.25f; sz = 0.25f; break;
            }
            cube(root, sx, sy, sz, r, g, b, 0f);
            if (p.kind == W.K_HEAL) { a1.set(root); a1.tr(0, 0.12f, 0); cube(a1, 0.18f, 0.06f, 0.06f, 0.85f, 0.1f, 0.1f, 0f); }
            // floating marker
            root.id();
            root.tr(p.x, p.y + 1.1f + bob, p.z);
            root.ry(clock * 90f);
            float mr = p.kind == W.K_GUN ? 1f : (p.kind == W.K_AMMO ? 1f : (p.kind == W.K_HEAL ? 0.2f : 0.3f));
            float mg = p.kind == W.K_GUN ? 0.3f : (p.kind == W.K_AMMO ? 0.8f : (p.kind == W.K_HEAL ? 1f : 0.6f));
            float mb = p.kind == W.K_GUN ? 0.2f : (p.kind == W.K_AMMO ? 0.2f : (p.kind == W.K_HEAL ? 0.4f : 1f));
            cube(root, 0.14f, 0.14f, 0.14f, mr, mg, mb, 1f);
        }
    }

    void drawBullets() {
        bind(cubeVbo);
        for (int i = 0; i < Game.bullets.size(); i++) {
            Bullet b = Game.bullets.get(i);
            if (b.dist < 4f) continue;
            float hz = (float) Math.sqrt(b.vx * b.vx + b.vz * b.vz);
            float yaw = (float) Math.atan2(b.vx, -b.vz), pit = (float) Math.atan2(b.vy, hz);
            root.id();
            root.tr(b.x, b.y, b.z);
            root.ry((float) Math.toDegrees(-yaw));
            root.rx((float) Math.toDegrees(pit));
            cube(root, 0.05f, 0.05f, 1.2f, 1f, 0.9f, 0.4f, 1f);
        }
        for (int i = 0; i < Game.grens.size(); i++) {
            Gren g = Game.grens.get(i);
            root.id();
            root.tr(g.x, g.y, g.z);
            cube(root, 0.2f, 0.25f, 0.2f, 0.2f, 0.3f, 0.2f, 0f);
        }
    }

    void drawEffects() {
        bind(cubeVbo);
        for (int i = 0; i < Game.parts.size(); i++) {
            Part p = Game.parts.get(i);
            root.id();
            root.tr(p.x, p.y, p.z);
            cube(root, p.size, p.size, p.size, p.r, p.g, p.b, p.glow ? 1f : 0f);
        }
    }

    void drawZone() {
        if (Game.zr > 700) return;
        bind(cubeVbo);
        int n = 110;
        float seg = (float) (2 * Math.PI * Game.zr / n) + 0.6f;
        for (int k = 0; k < n; k++) {
            float a = (float) (2 * Math.PI * k / n);
            float x = Game.zx + (float) Math.cos(a) * Game.zr, z = Game.zz + (float) Math.sin(a) * Game.zr;
            float dx = x - camx, dz = z - camz;
            if (dx * dx + dz * dz > 330f * 330f) continue;
            root.id();
            root.tr(x, 40f, z);
            root.ry((float) Math.toDegrees(-a));
            cube(root, 0.3f, 90f, seg, 0.15f, 0.35f, 1f, 0.9f);
        }
    }

    void drawPlane() {
        bind(cubeVbo);
        root.id();
        root.tr(Game.planeX, Game.planeY, Game.planeZ);
        root.ry(-90f);
        cube(root, 4f, 4f, 22f, 0.92f, 0.92f, 0.94f, 0f);
        a1.set(root); a1.tr(0, 0, -1f);
        cube(a1, 26f, 0.4f, 5f, 0.85f, 0.85f, 0.88f, 0f);
        a1.set(root); a1.tr(0, 2.5f, 10f);
        cube(a1, 0.4f, 5f, 4f, 0.0f, 0.5f, 0.3f, 0f);
        a1.set(root); a1.tr(0, 0.4f, 10f);
        cube(a1, 9f, 0.3f, 3f, 0.85f, 0.85f, 0.88f, 0f);
        a1.set(root); a1.tr(0, 0.3f, -10.5f);
        cube(a1, 3.9f, 1.8f, 2f, 0.1f, 0.15f, 0.2f, 0f);
    }

    // ---------------------------------------------------------------- characters
    void drawGun(Xf base, W.Gun g, float lenScale) {
        part(base, 0, 0, -g.len * 0.5f, 0.07f, 0.1f, g.len, g.cr, g.cg, g.cb);
        part(base, 0, -0.1f, -g.len * 0.35f, 0.05f, 0.14f, 0.07f, g.cr * 0.7f, g.cg * 0.7f, g.cb * 0.7f);
        if (g.cls == 3 || g.cls == 2) part(base, 0, 0.08f, -g.len * 0.45f, 0.05f, 0.05f, 0.2f, 0.1f, 0.1f, 0.1f);
    }

    void drawFighter(Fighter f, boolean dead) {
        float tr = Cfg.pr(Cfg.PAL[f.topCol]), tg = Cfg.pg(Cfg.PAL[f.topCol]), tb = Cfg.pb(Cfg.PAL[f.topCol]);
        float br = Cfg.pr(Cfg.PAL[f.bottomCol]), bg = Cfg.pg(Cfg.PAL[f.bottomCol]), bb = Cfg.pb(Cfg.PAL[f.bottomCol]);
        float sr = Cfg.pr(Cfg.PAL[f.shoeCol]), sg = Cfg.pg(Cfg.PAL[f.shoeCol]), sb = Cfg.pb(Cfg.PAL[f.shoeCol]);
        float hr = Cfg.pr(Cfg.PAL[f.headCol]), hg = Cfg.pg(Cfg.PAL[f.headCol]), hb = Cfg.pb(Cfg.PAL[f.headCol]);
        if (f.top == 2) { tr = 0.0f; tg = 0.42f; tb = 0.3f; }
        if (f.top == 4) { tr *= 0.8f; tg *= 0.8f; tb *= 0.8f; }
        root.id();
        root.tr(f.x, f.y, f.z);
        root.ry((float) Math.toDegrees(-f.byaw));
        float swing = 0f;
        if (dead) { root.tr(0, 0.25f, 0); root.rx(90f); }
        else if (f.st == 1) { root.tr(0, 0.9f, 0); root.rx(-85f); }
        else if (f.stance == 2) { root.tr(0, 0.2f, 0); root.rx(-80f); }
        else {
            if (f.stance == 1) Matrix.scaleM(root.m, 0, 1f, 0.74f, 1f);
            swing = (float) Math.sin(f.walk) * Math.min(1f, f.speedNow / 4f) * 38f;
        }
        bind(cubeVbo);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        // legs
        for (int s = -1; s <= 1; s += 2) {
            a1.set(root); a1.tr(s * 0.14f, 0.9f, 0); a1.rx(s * swing);
            if (f.bottom == 1) {            // lungi: legs bare
                part(a1, 0, -0.45f, 0, 0.2f, 0.9f, 0.22f, skinR * 0.95f, skinG * 0.95f, skinB * 0.95f);
            } else if (f.bottom == 2) {     // shorts
                part(a1, 0, -0.2f, 0, 0.24f, 0.4f, 0.26f, br, bg, bb);
                part(a1, 0, -0.65f, 0, 0.2f, 0.5f, 0.22f, skinR * 0.95f, skinG * 0.95f, skinB * 0.95f);
            } else {                        // jeans / cargo
                part(a1, 0, -0.43f, 0, 0.24f, 0.86f, 0.26f, br, bg, bb);
                if (f.bottom == 3) part(a1, s * 0.13f, -0.35f, 0, 0.05f, 0.2f, 0.2f, br * 0.8f, bg * 0.8f, bb * 0.8f);
            }
            part(a1, 0, -0.92f, -0.04f, 0.23f, 0.1f, 0.32f, sr, sg, sb);
        }
        if (f.bottom == 1) part(root, 0, 0.78f, 0, 0.6f, 0.62f, 0.36f, br, bg, bb);
        else part(root, 0, 0.93f, 0, 0.5f, 0.2f, 0.28f, br, bg, bb);
        // torso
        part(root, 0, 1.22f, 0, 0.52f, 0.62f, 0.28f, tr, tg, tb);
        if (f.top == 1) part(root, 0, 0.78f, 0, 0.54f, 0.5f, 0.3f, tr, tg, tb);              // panjabi skirt
        if (f.top == 2) part(root, 0, 1.28f, -0.145f, 0.2f, 0.2f, 0.02f, 0.85f, 0.1f, 0.1f); // BD flag circle
        if (f.top == 3) part(root, 0, 1.52f, 0.2f, 0.36f, 0.2f, 0.16f, tr * 0.9f, tg * 0.9f, tb * 0.9f); // hood
        if (f.top == 4) part(root, 0, 1.28f, 0, 0.56f, 0.46f, 0.32f, 0.22f, 0.24f, 0.2f);   // vest
        if (f.armor > 0 && f.top != 4) {
            float a = f.armor == 1 ? 0.45f : (f.armor == 2 ? 0.55f : 0.22f);
            part(root, 0, 1.28f, 0, 0.55f, 0.42f, 0.31f, a, a * 1.05f, a * 0.9f);
        }
        part(root, 0, 1.28f, 0.23f, 0.36f, 0.42f, 0.18f, 0.2f, 0.26f, 0.2f);                 // backpack
        // neck + head
        part(root, 0, 1.55f, 0, 0.13f, 0.1f, 0.13f, skinR * 0.9f, skinG * 0.9f, skinB * 0.9f);
        bind(headVbo);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texFace);
        a2.set(root); a2.tr(0, 1.76f, 0);
        cube(a2, 0.34f, 0.42f, 0.34f, 1f, 1f, 1f, 0f);
        bind(cubeVbo);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        switch (f.head) {
            case 1: part(root, 0, 1.99f, 0, 0.37f, 0.1f, 0.37f, hr, hg, hb); part(root, 0, 1.94f, -0.26f, 0.3f, 0.03f, 0.18f, hr, hg, hb); break;
            case 2: part(root, 0, 1.9f, 0, 0.37f, 0.1f, 0.37f, 0.8f, 0.1f, 0.1f); part(root, 0, 1.84f, 0.2f, 0.12f, 0.3f, 0.06f, 0.8f, 0.1f, 0.1f); break;
            case 3: part(root, 0, 1.98f, 0, 0.35f, 0.12f, 0.35f, hr, hg, hb); break;
            case 4: part(root, 0, 1.88f, 0, 0.36f, 0.07f, 0.36f, hr, hg, hb); part(root, 0, 1.84f, 0.22f, 0.1f, 0.14f, 0.06f, hr, hg, hb); break;
            default: break;
        }
        if (f.helmet > 0) {
            float c = f.helmet == 1 ? 0.35f : (f.helmet == 2 ? 0.5f : 0.14f);
            part(root, 0, 1.98f, 0, 0.4f, 0.18f, 0.4f, c * 0.8f, c, c * 0.8f);
        }
        // arms + gun (aimed by pitch)
        a2.set(root); a2.tr(0, 1.47f, 0);
        float pit = (float) Math.toDegrees(f.pitch);
        a2.rx(pit * 0.9f);
        boolean melee = f.cur == 3;
        float sleeve = (f.top == 0 || f.top == 2) ? 0.28f : 0.58f;
        for (int s = -1; s <= 1; s += 2) {
            a1.set(a2); a1.tr(s * 0.37f, 0, 0);
            a1.rx(melee ? (s > 0 ? -110f : 5f) : -78f);
            if (!melee || s < 0) { a1.ry(s * (melee ? 0 : -9f)); }
            part(a1, 0, -sleeve / 2, 0, 0.17f, sleeve, 0.17f, tr, tg, tb);
            part(a1, 0, -sleeve - (0.6f - sleeve) / 2, 0, 0.15f, 0.6f - sleeve, 0.15f, skinR, skinG, skinB);
        }
        if (!dead && f.st != 1) {
            a1.set(a2); a1.tr(0.2f, -0.2f, -0.35f);
            if (melee) { a1.set(a2); a1.tr(0.37f, -0.55f, -0.5f); part(a1, 0, 0, 0, 0.04f, 0.04f, 0.3f, 0.2f, 0.2f, 0.2f); part(a1, 0, 0, -0.3f, 0.3f, 0.03f, 0.3f, 0.12f, 0.12f, 0.14f); }
            else {
                W.Gun g = f.gun();
                drawGun(a1, g, 1f);
                if (f.flash > 0) partE(a1, 0, 0, -g.len - 0.12f, 0.16f, 0.16f, 0.16f, 1f, 0.85f, 0.3f);
            }
        }
        if (f.st == 2) {
            a1.set(root); a1.tr(0, 5.8f, 0);
            cube(a1, 4.2f, 0.25f, 4.2f, 0.9f, 0.25f, 0.15f, 0f);
            a1.set(root); a1.tr(0, 3.6f, 0);
            cube(a1, 0.04f, 4.2f, 0.04f, 0.2f, 0.2f, 0.2f, 0f);
        }
        if (f.protectT > 0 && !dead) { a1.set(root); a1.tr(0, 0.9f, 0); cube(a1, 1.0f, 2.1f, 1.0f, 0.3f, 0.6f, 1f, 0.7f); }
    }

    void drawViewModel(Fighter f) {
        if (f.cur == 3) return;
        W.Gun g = f.gun();
        root.id();
        root.tr(Game.camX, Game.camY, Game.camZ);
        root.ry((float) Math.toDegrees(-Game.camYaw));
        root.rx((float) Math.toDegrees(Game.camPitch));
        if (f.ads) root.tr(0.0f, -0.13f, -0.35f); else root.tr(0.2f, -0.2f, -0.35f);
        bind(cubeVbo);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texWhite);
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT);
        drawGun(root, g, 1f);
        a1.set(root); a1.tr(0.0f, -0.12f, -0.1f);
        cube(a1, 0.09f, 0.09f, 0.3f, Game.me.armor > 0 ? 0.3f : 0.55f, 0.4f, 0.35f, 0f);
        if (f.flash > 0) partE(root, 0, 0, -g.len - 0.1f, 0.15f, 0.15f, 0.15f, 1f, 0.85f, 0.3f);
    }
}
